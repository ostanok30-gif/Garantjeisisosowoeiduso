import logging

# P5.36: dedicated logger so format errors land in the bot log instead of stdout.
logger = logging.getLogger(__name__)

RU_TEXTS = {
    "start_message": (
        "👋 <b>Добро пожаловать!</b>\n\n"
        "💼 <b>Надёжный сервис для безопасных сделок!</b>\n"
        "✨ <b>Автоматизировано, быстро и без лишних хлопот!</b>\n\n"
        "<blockquote>"
        "🔹 <b>Комиссия за услугу: <code>{commission}%</code></b>\n"
        "🔹 <b>Поддержка 24/7: @{support}</b>\n"
        "🔹 <b>Отзывы пользователей: {reviews}</b>\n"
        "</blockquote>\n\n"
        "💌 <b>Теперь ваши сделки под защитой!</b> 🛡️"
    ),
    "wallet_menu_message": "💰 <b>Мои реквизиты</b>\n\n<blockquote><b>Выберите реквизит из списка или добавьте новый:</b></blockquote>",
    "wallet_empty_placeholder": "⚪ Здесь ничего нет",
    "add_wallet_short_button": "👛 Добавить кошелек",
    "add_ton_row_button": "💼 Добавить TON",
    "add_card_row_button": "💳 Добавить карту",
    "add_stars_row_button": "⭐ Добавить получателя звёзд",
    "delete_requisite_button": "🗑",
    "requisite_detail_ton": "💼 TON-кошелёк:\n<code>{value}</code>",
    "requisite_detail_card": "💳 Карта:\n<code>{value}</code>",
    "requisite_detail_stars": "⭐ Получатель звёзд:\n<code>@{value}</code>",
    "wallet_card_button": "💳 Карта",
    "wallet_ton_button": "💼 Кошелёк TON",
    "stars_contact_button": "⭐ Получатель звёзд",
    "stars_contact_message": "<blockquote><b>Введите @username для получения звёзд (5-32 символа: латиница, цифры, подчёркивание).</b></blockquote>\n<i>Пример: @username</i>",
    "invalid_stars_username_message": "<blockquote><b>❌ Неверный формат юзернейма. Должно быть 5-32 символа (латиница, цифры, подчёркивание). Пример: @username</b></blockquote>",
    "stars_username_saved": "✅ Юзернейм для получения звёзд сохранён: <code>{username}</code>",
    "ask_name_for_card_message": "✅ <b>Карта добавлена!</b>\n\n<blockquote><b>Желаете ли вы добавить название для карты?</b></blockquote>",
    "ask_name_for_stars_message": "✅ <b>Юзернейм добавлен!</b>\n\n<blockquote><b>Желаете ли вы добавить название для реквизита?</b></blockquote>",
    "enter_name_for_card_message": "<b>Введите название для карты (от 5 букв, только русские или английские буквы):</b>",
    "enter_name_for_stars_message": "<b>Введите название для реквизита (от 5 букв, только русские или английские буквы):</b>",
    "enter_name_for_wallet_message": "<b>Введите название для кошелька (от 5 букв, только русские или английские буквы):</b>",
    "invalid_requisite_name_message": "<b>❌ Название: от 5 букв, только русские или английские буквы (без цифр и символов).</b>",
    "requisite_already_exists_message": (
        "❌ <b>Реквизит этого типа уже добавлен</b>\n\n"
        "<blockquote>"
        "Удалите существующий в разделе «Мои реквизиты» и добавьте новый."
        "</blockquote>"
    ),
    "creator_cannot_join_own_deal_message": "<blockquote><b>❌ Вы не можете присоединиться к своей сделке. Эта ссылка для покупателя.</b></blockquote>",
    "valute_stars": "звёзды",
    "no_stars_username_for_deal_message": "<blockquote><b>❌ Для сделки со звёздами укажите получателя звёзд в разделе «Мои реквизиты» → «Получатель звёзд».</b></blockquote>",
    "add_ton_wallet_message": (
        "👛 <b>Добавление кошелька (сеть TON)</b>\n\n"
        "<blockquote><b>Пришлите адрес кошелька сети TON (48 символов, начинается с EQ или UQ).</b></blockquote>\n"
        "<i>Подходит для приёма TON и USDT. Пример: UQAbc123...xyz</i>"
    ),
    "add_ton_wallet_message_with_current": (
        "💼 Ваш текущий кошелёк: <code>{current_wallet}</code>\n\n"
        "Отправьте новый адрес кошелька сети TON (48 символов, EQ или UQ)."
    ),
    "add_card_message": (
        "💳 <b>Добавление карты</b>\n"
        "<blockquote><b>Пришлите банк и номер карты (12-19 цифр) в формате: Банк - Номер</b></blockquote>\n"
        "<i>Пример: Сбербанк - 4276123456789012</i>"
    ),
    "add_card_message_with_current": (
        "💳 Ваши текущие реквизиты: <code>{current_card}</code>\n\n"
        "Отправьте реквизиты в формате: <code>Банк - Номер</code> (12-19 цифр)\n"
        "<i>Пример: Сбербанк - 4276123456789012</i>"
    ),
    "no_requisites_message": "<blockquote><b>❌ Сначала добавьте необходимые реквизиты перед созданием сделки.</b></blockquote>",
    "no_ton_wallet_for_deal_message": "<blockquote><b>❌ Перед созданием сделки привяжите свой TON-кошелёк. Один и тот же адрес используется для TON и USDT.</b></blockquote>",
    "no_card_for_deal_message": "<blockquote><b>❌ Для оплаты картой нужны привязанные реквизиты карты. Добавьте их в разделе «Добавить/изменить реквизиты».</b></blockquote>",
    "invalid_ton_wallet_message": "❌ Неверный формат кошелька!\n\nПопробуй еще раз 👇",
    "invalid_card_message": "❌ Неверный формат. Укажите банк и номер карты (12-19 цифр) в формате: <code>Банк - Номер</code>. Пример: Сбербанк - 4276123456789012",
    "deal_already_has_buyer_message": (
        "🚫 <b>Сделка уже занята</b>\n\n"
        "<blockquote>"
        "<b>К этой сделке уже присоединился другой покупатель.</b>\n"
        "Если хочешь — создай свою сделку через главное меню 👇"
        "</blockquote>"
    ),
    "choose_payment_method_message": "<blockquote><b>💰 Выберите валюту сделки 👇</b></blockquote>",
    "create_deal_message": (
        "💼 <b>Создание сделки</b>\n\n"
        "<blockquote><b>Введите сумму сделки в {valute} в формате <code>123.4</code> 👇</b></blockquote>"
    ),
    "wallet_added_ask_name_message": (
        "✅ <b>Кошелёк добавлен!</b>\n\n"
        "<blockquote><b>Желаете ли вы добавить название для кошелька?</b></blockquote>"
    ),
    "add_name_button": "➕ Добавить название",
    "skip_button": "Пропустить",
    "wallet_added_success_message": (
        "👛 Новый кошелёк успешно добавлен!\n\n"
        "Адрес: <code>{wallet_address}</code>"
    ),
    "change_lang_message": "<b>Выберите язык</b>",
    "change_lang_instruction_ru": "<blockquote><b>🇷🇺 → Выберите язык бота прежде чем начать пользоваться.</b></blockquote>",
    "change_lang_instruction_en": "<blockquote><b>🇺🇸 → Choose the bot's language before you start using it.</b></blockquote>",
    "lang_set_success_message": (
        "🎉 <b>Язык успешно установлен!</b>\n\n"
        "<blockquote>Нажмите на кнопку ниже чтобы перейти 👇 в главное меню.</blockquote>"
    ),
    "lang_rus_button": "🇷🇺 РУС",
    "lang_eng_button": "🇺🇸 ENG",
    "awaiting_description_message": (
        "💼 <b>Создание сделки</b>\n\n"
        "<blockquote><b>Укажите, что вы предлагаете в сделке. Например: <code>10 Персиков и Кепка</code> 👇</b></blockquote>"
    ),
    "wallet_updated": "🔗 {wallet_type} обновлен: <code>{details}</code>",
    "choose_deal_type_message": "<b>❔ Выберите тип сделки!</b>",
    "deal_created_message": (
        "💥 <b>Сделка успешно создана!</b>\n"
        "<b>Тип сделки: 🎁 Подарки</b>\n\n"
        "<b>Отдаёте:</b> <code>{description}</code>\n"
        "<b>Получаете:</b> <code>{amount} {valute}</code>\n\n"
        "<b>⛓️ Ссылка для покупателя:</b>\n"
        "<code>https://t.me/{bot_username}?start={deal_id}</code>"
    ),
    "cancel_deal_button": "🔴 Выйти из сделки",
    "deal_info_ton_message": (
        "<b>💼 Сделка</b> <code>{deal_id_short}</code>\n\n"
        "<i><b>👤 Вы покупатель.</b></i>\n\n"
        "<i><b>📌 Продавец:</b></i> <b>@{seller_username}</b> <b>(</b><code>{seller_id}</code><b>)</b>\n"
        "<i><b>• Сделок:</b></i> <code>{successful_deals}</code>\n"
        "<i><b>• Оценка:</b></i> <code>{seller_vouches_line}</code>\n\n"
        "<i><b>• Вы покупаете:</b></i> <code>{description}</code>\n"
        "<i><b>• К оплате:</b></i> <b>{amount} {valute}</b>\n\n"
        "<blockquote><b>💸 Оплата производится с внутреннего баланса бота. "
        "Если средств не хватает — пополните кошелёк.</b></blockquote>"
    ),
    "deal_info_sbp_message": (
        "<b>💼 Сделка</b> <code>{deal_id_short}</code>\n"
        "<b>Тип сделки: 🎁 Подарки</b>\n\n"
        "<i><b>👤 Вы покупатель, у вас есть 15 минут на оплату сделки!</b></i>\n\n"
        "<i><b>📌 Продавец:</b></i> <b>@{seller_username}</b> <b>(</b><code>{seller_id}</code><b>)</b>\n\n"
        "<i><b>• Количество сделок продавца:</b></i> <code>{successful_deals}</code>\n"
        "<i><b>• Сумма сделок продавца:</b></i> <code>{seller_total_usd}</code>\n"
        "<i><b>• Оценка продавца:</b></i> <code>{seller_vouches_line}</code>\n\n"
        "<i><b>• Вы покупаете:</b></i> <code>{description}</code>\n"
        "<i><b>• Вы отдаете:</b></i> <code>{amount} {valute}</code>\n\n"
        "<i><b>💳 Карта для оплаты:</b></i>\n"
        "<code>{card}</code>\n\n"
        "<b>💸 Сумма к оплате:</b>\n"
        "💎 <code>{amount}</code> <b>{valute}</b>\n\n"
        "<i><b>🚨 Комментарий к транзакции:</b></i> <code>{deal_id}</code>\n\n"
        "<blockquote><b>‼️ Пожалуйста, убедитесь что при оплате указываете обязательный комментарий (memo) и точную сумму!</b></blockquote>\n\n"
        "<b>Оплата подтвердится автоматически.</b>"
    ),
    "deal_info_stars_message": (
        "<b>💼 Сделка</b> <code>{deal_id_short}</code>\n"
        "<b>Тип сделки: 🎁 Подарки</b>\n\n"
        "<i><b>👤 Вы покупатель, у вас есть 15 минут на оплату сделки!</b></i>\n\n"
        "<i><b>📌 Продавец:</b></i> <b>@{seller_username}</b> <b>(</b><code>{seller_id}</code><b>)</b>\n\n"
        "<i><b>• Количество сделок продавца:</b></i> <code>{successful_deals}</code>\n"
        "<i><b>• Сумма сделок продавца:</b></i> <code>{seller_total_usd}</code>\n"
        "<i><b>• Оценка продавца:</b></i> <code>{seller_vouches_line}</code>\n\n"
        "<i><b>• Вы покупаете:</b></i> <code>{description}</code>\n"
        "<i><b>• Вы отдаете:</b></i> <code>{amount} Звёзд</code>\n\n"
        "<i><b>🌟 Оплата через Telegram Stars:</b></i>\n"
        "<b>Передайте звёзды сюда:</b> @{support_username}\n\n"
        "<b>💸 Сумма к оплате:</b>\n"
        "💎 <code>{amount}</code> <b>Звёзд</b>\n\n"
        "<blockquote><b>‼️ Укажите точную сумму при переводе. После оплаты ожидайте подтверждения от администратора.</b></blockquote>\n\n"
        "<b>Оплата подтвердится после проверки.</b>"
    ),
    "payment_confirmed_message": (
        "💥 <b>Транзакция по сделке</b> <code>{deal_id_short}</code> <b>найдена!</b>\n\n"
        "<b>Тип сделки: 🎁 Подарки</b>\n\n"
        "<b>👤 Продавец:</b> <b>@{seller_username}</b> <b>(</b><code>{seller_id}</code><b>)</b>\n\n"
        "<b>Получаете:</b> <code>{description}</code>\n"
        "<b>Отдаёте:</b> <code>{amount} {valute}</code>\n\n"
        "<blockquote><b>‼️ Сделка завершится после того как продавец передаст вам товар и вы это подтвердите.</b></blockquote>"
    ),
    "payment_confirmed_seller_message": (
        "💥 <b>Оплата получена по сделке</b> <code>{deal_id_short}</code>!\n\n"
        "<blockquote>‼️ <b>Передайте товар → @{buyer_username}</b> ‼️</blockquote>\n\n"
        "<b>Тип сделки:</b> 🎁 <b>Подарки</b>.\n"
        "<b>👤 Покупатель:</b> <b>@{buyer_username}</b> <b>(</b><code>{buyer_id}</code><b>)</b>\n\n"
        "<blockquote>‼️ <b>Передайте товар → @{buyer_username}</b> ‼️</blockquote>\n\n"
        "<b>Получаете:</b> <code>{amount} {valute}</code>\n"
        "<b>Отдаёте:</b> <code>{description}</code>\n\n"
        "<blockquote>‼️ <b>Передавайте товар только покупателю @{buyer_username}</b>\n"
        "<b>В случае передачи товара другому человеку возврат не будет осуществлен.</b>\n"
        "<b>Для получения гарантий, записывайте на видео момент передачи товара.</b></blockquote>"
    ),
    "payment_confirmed_seller_message_account": (
        "💥 <b>Оплата получена по сделке</b> <code>{deal_id_short}</code>!\n\n"
        "<blockquote>‼️ <b>Передавайте данные от аккаунта только @{buyer_username}</b> ‼️</blockquote>\n\n"
        "<b>Тип сделки:</b> 🆕 <b>Аккаунты</b>.\n"
        "<b>👤 Покупатель:</b> <b>@{buyer_username}</b> <b>(</b><code>{buyer_id}</code><b>)</b>\n\n"
        "<blockquote>‼️ <b>Передавайте данные от аккаунта только @{buyer_username}</b> ‼️</blockquote>\n\n"
        "<b>Получаете:</b> <code>{amount} {valute}</code>\n"
        "<b>Отдаёте:</b> <code>{description}</code>\n\n"
        "<blockquote><b>Передавайте данные от аккаунта только @{buyer_username}.</b>\n"
        "<b>В случае передачи другому человеку возврат не будет осуществлен.</b></blockquote>"
    ),
    "seller_confirm_sent_message": (
        "✅ <b>Вы подтвердили передачу подарка для сделки</b> <code>{deal_id_short}</code>\n\n"
        "<b>Ожидайте подтверждения получения от покупателя</b>\n\n"
        "<blockquote><b>Убедитесь, что передали подарок покупателю &#64;{buyer_username}, в противном случае покупатель не сможет увидеть и подтвердить передачу подарка, а вы в свою очередь не получите оплату</b></blockquote>"
    ),
    "seller_confirm_sent_notification": (
        "🚀 <b>Продавец подтвердил передачу товара по сделке</b> <code>{deal_id_short}!</code>\n\n"
        "<blockquote><b>Проверьте получили ли вы товар и подтвердите нажав кнопку ниже. 👆</b></blockquote>"
    ),
    "buyer_confirm_received_message": (
        "✅ <b>Успешная сделка!</b>\n\n"
        "<b>Вы подтвердили получение подарка.</b>\n\n"
        "<b>Сделка завершена!</b>"
    ),
    "buyer_rate_seller_message": (
        "✅ <b>Сделка завершена!</b>\n\n"
        "<blockquote><b>Поставь оценку продавцу:</b></blockquote>"
    ),
    "seller_rate_buyer_message": (
        "✅ <b>Сделка завершена!</b>\n\n"
        "<blockquote><b>Поставь оценку покупателю:</b></blockquote>"
    ),
    "vote_recorded_message": "✅ <b>Спасибо! Отзыв учтён.</b>",
    "vote_already_message": "❌ Вы уже оценили этого участника.",
    "seller_deal_completed_message": (
        "✅ <b>Сделка успешно завершена!</b>\n\n"
        "<blockquote>"
        "<b>Покупатель подтвердил получение товара.</b>\n"
        "<b>Деньги уже зачислены на твой внутренний баланс.</b>\n\n"
        "<i>Выводи через</i> <b>Кошелёк → Вывести</b> <i>(автовывод 1-2 минуты).</i>"
        "</blockquote>\n\n"
        "<b>Поставь оценку покупателю:</b>"
    ),
    "payout_stars_ton_only": "<blockquote><b>Выплата по звёздам только на TON. Обратитесь в поддержку.</b></blockquote>",
    "payout_wallet_chosen_minimum": "<b>Сумма вывода ниже минимально допустимой.</b>",
    "seller_notification_message": (
        "<b>👤 Пользователь</b> <b>@{buyer_username}</b> <b>(</b><code>{buyer_id}</code><b>)</b>\n"
        "<b>присоединился к вашей сделке</b> <code>{deal_id_short}</code>\n\n"
        "<i><b>• Количество сделок покупателя:</b></i> <code>{successful_deals}</code>\n"
        "<i><b>• Сумма сделок покупателя:</b></i> <code>{buyer_total_usd}</code>\n"
        "<i><b>• Оценка покупателя:</b></i> <code>{buyer_vouches_line}</code>\n\n"
        "<blockquote>‼️ <b>Убедитесь, что это тот же пользователь, с которым вы вели диалог ранее!</b></blockquote>\n\n"
        "<b>Не передавайте товар(ы) покупателю @{buyer_username} до получения сообщения от бота о подтверждении оплаты!</b>"
    ),
    "insufficient_balance_message": "❌ <b>Недостаточно средств на балансе.</b>",
    "pay_from_balance_stars_not_available": "<blockquote><b>Для сделки в звёздах оплата с баланса недоступна. Передайте звёзды в поддержку.</b></blockquote>",
    "admin_panel_message": "🔧 <b>Админ-панель</b>:",
    "admin_broadcast_message": "📢 Введите текст для рассылки всем пользователям:",
    "broadcast_success_message": (
        "📢 <b>Рассылка завершена.</b>\n"
        "✅ <b>Успешно отправлено:</b> <code>{success_count}</code>\n"
        "❌ <b>Ошибок:</b> <code>{fail_count}</code>"
    ),
    "admin_view_deals_message": "💳 Выберите сделку:",
    "admin_view_deal_message": (
        "<b>ℹ️ Информация о сделке #{deal_id_short}</b>\n\n"
        "👤 <b>Продавец:</b> <b>@{seller_username}</b> <b>(ID: </b><code>{seller_id}</code><b>)</b>\n"
        "✅ Успешных сделок: {seller_successful_deals}\n\n"
        "👤 <b>Покупатель:</b> <b>@{buyer_username}</b> <b>(ID: </b><code>{buyer_id}</code><b>)</b>\n"
        "✅ Успешных сделок: {buyer_successful_deals}\n\n"
        "➖➖➖➖➖➖➖➖➖➖\n\n"
        "📝 <b>Описание:</b>\n{description}\n\n"
        "💰 <b>Сумма:</b> {amount} {valute}\n"
        "💳 <b>Реквизиты для оплаты:</b>\n<code>{payment_details}</code>\n\n"
        "📊 <b>Статус:</b> {status}"
    ),
    "admin_confirm_no_buyer": "<blockquote><b>Сначала покупатель должен присоединиться к сделке.</b></blockquote>",
    "seller_confirm_no_buyer": "<blockquote><b>Покупатель не присоединился к сделке. Обратитесь в поддержку.</b></blockquote>",
    "admin_confirm_deal_message": (
        "✅ Оплата для сделки <b>#{deal_id_short}</b> подтверждена администратором.\n"
        "Продавец и покупатель уведомлены."
    ),
    "admin_cancel_deal_message": "❌ Сделка <b>#{deal_id_short}</b> была отменена администратором.",
    "deal_cancelled_notification": "❌ Сделка <b>#{deal_id_short}</b> была отменена администратором.",
    "admin_change_balance_message": "Введите ID пользователя и новый баланс в формате: <code>user_id баланс</code>",
    "admin_change_successful_deals_message": "Введите ID пользователя и количество успешных сделок в формате: <code>user_id количество</code>",
    "admin_change_valute_message": "<b>Введите новую валюту (например, TON, USD, EUR, RUB).</b>\n<i>Используется для отображения баланса пользователей:</i>",
    "admin_manage_admins_message": "Введите ID пользователя и действие (add/remove) в формате: <code>user_id действие</code>",
    "admin_added_message": "✅ Пользователь <code>{user_id}</code> добавлен в администраторы.",
    "admin_removed_message": "❌ Пользователь <code>{user_id}</code> удален из администраторов.",
    "admin_cannot_remove_self_message": "🚫 Вы не можете удалить себя из администраторов!",
    "admin_cannot_remove_super_admin_message": "🚫 Нельзя удалить суперадминистратора.",
    "invalid_action_message": "<blockquote><b>❌ Неверное действие. Используйте 'add' или 'remove'.</b></blockquote>",
    "admin_list_message": "👑 <b>Список администраторов</b>:\n\n{admin_list}",
    "unknown_callback_error": "❌ Неизвестное действие. Пожалуйста, выберите опцию из меню.",
    "lang_set_message": "✅ Язык изменен на Русский.",
    "menu_button": "🔙 Вернуться в меню",
    "back_to_menu_button": "🔙 В меню",
    "back_button": "⬅️ Назад",
    "worker_commands_button": "📋 Команды",
    "worker_commands_menu_message": "📋 <b>Команды воркера</b>\n\nВыберите действие:",
    "worker_cmd_deals_count_button": "📊 Кол-во сделок",
    "worker_cmd_deals_sum_button": "💵 Сумма сделок",
    "worker_cmd_vouches_button": "⭐ Отзывы",
    "worker_cmd_balance_button": "💰 Пополнить баланс",
    "worker_balance_choose_type": "💰 <b>Пополнение баланса</b>\n\nВыберите тип: фиат или криптовалюта.",
    "worker_balance_fiat_button": "Фиат",
    "worker_balance_crypto_button": "Криптовалюта",
    "worker_balance_choose_currency_fiat": "<b>Выберите валюту (фиат - звёзды, рубли, доллары и др.):</b>",
    "worker_balance_choose_currency_crypto": "Выберите криптовалюту:",
    "worker_balance_enter_amount": "<b>Введите сумму зачисления для</b> <code>{currency}</code> <b>(положительное число, можно с запятой или точкой):</b>",
    "worker_balance_credited": "✅ <b>Зачислено</b> <code>{amount}</code> {currency}.\n<i>Текущий баланс:</i> <code>{balance}</code>",
    "worker_balance_invalid_amount": "Введите положительное число, например <code>100</code> или <code>50.25</code>.",
    "worker_cmd_confirm_payment_button": "✅ Подтвердить оплату",
    "worker_enter_deals_count": "Введите количество успешных сделок (целое число):",
    "worker_enter_deals_sum": "<b>Введите сумму сделок ($), например</b> <code>1000</code> <b>или</b> <code>1500.50</code><b>:</b>",
    "worker_enter_vouches": "Введите оценку и количество отзывов через пробел, например: <code>4.75 361</code>",
    "worker_deals_count_ok": "✅ Кол-во успешных сделок изменено.",
    "worker_deals_sum_ok": "✅ Сумма сделок установлена.",
    "worker_vouches_ok": "✅ Оценка и отзывы установлены.",
    "worker_confirm_payment_list_message": "✅ <b>Подтверждение оплаты</b>\n\nВыберите сделку для подтверждения:",
    "worker_confirm_payment_no_active": "<blockquote><b>Нет активных сделок (ожидающих подтверждения оплаты).</b></blockquote>",
    "worker_confirm_payment_done": "✅ <b>Оплата по сделке подтверждена.</b>",
    "worker_confirm_payment_button": "✅ Подтвердить оплату",
    "worker_chat_deal_notice": (
        "💼 <b>Сделка</b> <code>#{deal_id_short}</code>\n"
        "🎁 <b>Тип сделки:</b> {deal_type_label}\n\n"
        "<i>👤 Покупатель в сделке - ожидается оплата.</i>\n\n"
        "📌 <b>Продавец:</b> {seller_line}\n"
        "👤 <b>Покупатель:</b> {buyer_line}\n"
        "💎 <b>Сумма:</b> <code>{amount}</code> {valute}\n"
        "📝 <b>Описание:</b> <code>{description}</code>"
    ),
    "main_wallet_button": "💼 Кошелёк",
    "main_requisites_button": "💰 Мои реквизиты",
    "main_create_deal_button": "🤝 Создать сделку",
    "wallet_main_message": (
        "💼 <b>Кошелёк</b>\n\n"
        "Баланс:\n"
        "   • TON: <b>{ton}</b> {ton_usd}\n"
        "   • USDT: <b>{usdt}</b> {usdt_usd}\n\n"
        "TON-кошелёк для вывода: {ton_addr}"
    ),
    "wallet_no_addr": "<i>не привязан</i>",
    "wallet_btn_dep": "Пополнить",
    "wallet_btn_wd": "Вывести",
    "wallet_btn_dep_ton": "TON",
    "wallet_btn_dep_usdt": "USDT",
    "wallet_btn_wd_ton": "TON",
    "wallet_btn_wd_usdt": "USDT",
    "wallet_dep_choose_msg": "<b>Выбери валюту для пополнения:</b>",
    "wallet_wd_choose_msg": "<b>Выбери валюту для вывода:</b>",
    "amount_invalid_message": "❌ Введи число.",
    "wallet_btn_set_addr": "Привязать TON-адрес",
    "wallet_btn_my_withdrawals": "Мои выводы",
    "my_withdrawals_empty": "У тебя пока нет заявок на вывод.",
    "my_withdrawals_title": "📤 <b>Мои выводы</b>\n",
    "my_withdrawals_item": (
        "#{wid} — <b>{amount} {currency}</b>\n"
        "Адрес: <code>{address}</code>\n"
        "Статус: {status_emoji} <i>{status}</i>\n"
        "Создана: {created_at}"
    ),
    "wd_status_pending": "в очереди",
    "wd_status_sent": "выплачено",
    "wd_status_rejected": "отклонено",
    "wallet_btn_my_requisites": "💰 Мои реквизиты",
    "deposit_ton_message": (
        "📥 <b>Пополнение TON</b>\n\n"
        "Отправь TON на адрес:\n<code>{address}</code>\n\n"
        "❗️ <b>Обязательно</b> укажи в комментарии (memo):\n<code>{memo}</code>\n\n"
        "Минимум: <b>{min_amount} TON</b>\n"
        "Зачисление автоматическое в течение 1–2 минут после подтверждения сети."
    ),
    "deposit_usdt_message": (
        "📥 <b>Пополнение USDT</b> (TON-сеть, jetton)\n\n"
        "Отправь USDT₮ на адрес:\n<code>{address}</code>\n\n"
        "❗️ <b>Обязательно</b> укажи в комментарии (memo):\n<code>{memo}</code>\n\n"
        "Минимум: <b>{min_amount} USDT</b>\n"
        "Зачисление автоматическое в течение 1–2 минут."
    ),
    "deposit_disabled_message": "⚠️ Пополнение временно недоступно. Попробуйте позже.",
    "withdraw_ask_address": "Введи адрес TON-кошелька получателя:",
    "withdraw_ask_amount": "<b>Введи сумму вывода (минимум</b> <code>{min_amount}</code> <code>{currency}</code><b>):</b>",
    "withdraw_low_balance": "❌ Недостаточно средств. Баланс: {balance} {currency}.",
    "withdraw_below_min": (
        "❌ <b>Сумма ниже минимальной</b>\n\n"
        "<blockquote>"
        "<b>Минимум:</b> <code>{min_amount} {currency}</code>"
        "</blockquote>"
    ),
    "wd_too_frequent_message": (
        "⏳ <b>Слишком частые заявки</b>\n\n"
        "<blockquote>"
        "У вас уже есть свежая заявка на вывод. Подождите немного."
        "</blockquote>"
    ),
    # P5.48: 24h aggregate cap
    "wd_daily_cap_exceeded": (
        "🚫 <b>Превышен суточный лимит вывода</b>\n\n"
        "<blockquote>"
        "<b>Лимит:</b> <code>{cap} {currency}</code> за 24 ч.\n"
        "Попробуйте позже или обратитесь в поддержку."
        "</blockquote>"
    ),
    "cancel_after_sent_blocked_message": "❌ Товар уже передан. Используйте «⚠️ Открыть спор» вместо отмены.",
    "withdraw_submitted": (
        "✅ Заявка на вывод создана.\n\n"
        "Сумма: <b>{amount} {currency}</b>\n"
        "Адрес: <code>{address}</code>\n\n"
        "Средства поступят в течение нескольких минут."
    ),
    "ton_addr_ask": "<b>Отправь свой TON-адрес (он сохранится для быстрых выводов):</b>",
    "ton_addr_invalid": "<blockquote><b>❌ Это не похоже на TON-адрес. Адрес должен начинаться с EQ или UQ и содержать 48 символов.</b></blockquote>",
    "ton_addr_saved": "✅ Адрес сохранён: <code>{address}</code>",
    "main_how_deal_button": "🆘 Как проходит сделка",
    "how_deal_message": (
        "<b>📋 Как проходит сделка</b>\n\n"
        "<b>Продавец:</b> добавляет реквизиты → создаёт сделку (тип, валюта, сумма, описание) → отправляет покупателю ссылку из бота.\n\n"
        "<b>Покупатель:</b> переходит по ссылке → добавляет реквизиты при необходимости → в течение 15 минут оплачивает <b>точную сумму</b> и указывает <b>обязательный комментарий (memo)</b>.\n\n"
        "После подтверждения оплаты (для TON - администратором) продавец передаёт товар в поддержку @{support}, нажимает «Подтверждаю передачу подарка». Покупатель подтверждает получение - сделка завершена, продавец получает выплату."
    ),
    "settings_button": "⚙️ Настройки",
    "settings_menu_message": "⚙️ <b>Настройки</b>",
    "settings_lang_button": "🇷🇺 Язык бота",
    "pay_from_balance_button": "💸 Оплатить с баланса",
    "add_wallet_button": "🪙 Добавить/изменить реквизиты",
    "add_ton_wallet_button": "💼 Добавить/изменить TON-кошелек",
    "add_card_button": "💳 Добавить/изменить карту",
    "create_deal_button": "📄 Создать сделку",
    "change_lang_button": "🌐 Сменить язык",
    "support_button": "📞 Поддержка",
    "english_lang_button": "🇬🇧 English",
    "russian_lang_button": "🇷🇺 Русский",
    "admin_view_deals_button": "💳 Просмотр сделок",
    "admin_change_balance_button": "💰 Изменить баланс пользователя",
    "admin_change_successful_deals_button": "✅ Изменить успешные сделки",
    "admin_change_valute_button": "💱 Изменить валюту",
    "admin_manage_admins_button": "👑 Назначить/удалить администратора",
    "admin_list_button": "👑 Список администраторов",
    "admin_manual_button": "📖 Мануал для админов",
    "admin_back_to_panel_button": "🔙 В админ-панель",
    "admin_manual_message": (
        "<b>📖 Мануал для администраторов гарант-бота</b>\n\n"
        "<b>💳 Просмотр сделок</b>\n"
        "Список сделок (сначала активные - ожидают оплаты, затем остальные). Сделки старше 24 часов автоматически удаляются. Можно открыть любую сделку, посмотреть данные продавца и покупателя, сумму, описание. В карточке активной сделки:\n"
        "• <b>Подтвердить</b> - вы подтверждаете, что оплата поступила. Покупатель и продавец получат уведомления, продавцу придёт инструкция отправить подарок.\n"
        "• <b>Отменить</b> - отмена сделки. Обе стороны получат уведомление.\n\n"
        "<b>💰 Изменить баланс пользователя</b>\n"
        "Ввести одной строкой: <code>ID_пользователя новый_баланс</code>\n"
        "Пример: <code>123456789 150.5</code> - у пользователя с ID 123456789 баланс станет 150.5.\n\n"
        "<b>✅ Изменить успешные сделки</b>\n"
        "Ввести одной строкой: <code>ID_пользователя количество</code>\n"
        "Пример: <code>123456789 10</code> - у пользователя будет отображаться 10 успешных сделок (влияет на доверие в сделках).\n\n"
        "<b>💱 Изменить валюту</b>\n"
        "Ввести одну валюту, например: TON, RUB, USD. Используется для отображения баланса пользователей в боте.\n\n"
        "<b>💬 Установить чат уведомлений</b>\n"
        "Ввести ID чата (например <code>-1001234567890</code>). В этот чат бот будет отправлять уведомления: новая сделка, подтверждение оплаты, отмена сделки, завершение сделки. Бота нужно добавить в чат и дать право писать сообщения.\n\n"
        "<b>📋 Установить чат логов</b> (только суперадмин)\n"
        "Ввести ID чата. В этот чат отправляются логи действий админов: изменение баланса, успешных сделок, валюты, подтверждение/отмена сделки.\n\n"
        "<b>🔗 Рассылка</b> (только суперадмин)\n"
        "После нажатия ввести текст сообщения. Оно будет отправлено всем пользователям бота одним сообщением.\n\n"
        "<i>Все действия админов логируются и отправляются в чат, который задаёт суперадмин в админке (кнопка «Установить чат логов»).</i>"
    ),
    "admin_confirm_deal_button": "✅ Подтвердить",
    "admin_cancel_deal_button": "❌ Отменить",
    "seller_transfer_gift_button": "🎁 Передать товар",
    "seller_confirm_sent_button": "✅ Подтверждаю передачу подарка",
    "buyer_confirm_received_button": "Подтверждаю получение товара",
    "contact_support_button": "🛟 Саппорт",
    "payment_ton_button": "💎 TON",
    "payment_crypto_button": "🪙 Криптовалюта",
    "payment_sbp_button": "💰 Валюта",
    "choose_crypto_currency_message": "<blockquote><b>Выберите криптовалюту 👇</b></blockquote>\n<i>Адрес кошелька - сети TON (один для TON и USDT).</i>",
    "crypto_usdt_button": "💵 USDT",
    "crypto_ton_button": "💎 TON",
    "payment_stars_button": "⭐ Звезды",
    "choose_card_currency_message": "<blockquote><b>Выберите валюту карты 👇</b></blockquote>",
    "currency_rub_button": "🇷🇺 Рубли",
    "currency_uah_button": "🇺🇦 Гривны",
    "currency_usd_button": "🇺🇸 Доллары",
    "currency_eur_button": "🇪🇺 Евро",
    "currency_kzt_button": "🇰🇿 Тенге",
    "currency_byn_button": "🇧🇾 Бел. рубли",
    "currency_uzs_button": "🇺🇿 Сумы",
    "currency_cny_button": "🇨🇳 Юани",
    "not_specified_wallet": "не указан",
    "not_specified_card": "не указаны",
    "no_deals_message": "📭 <b>У вас пока нет сделок.</b>",
    "nothing_here_button": "⚪ Здесь ничего нет",
    "seller_total_placeholder": "0.00$",
    "buyer_total_placeholder": "0.00$",
    "buyer_add_wallet_first_message": (
        "<blockquote><b>‼️ Перед вступлением в сделку привяжите свой TON-кошелёк. Один адрес — и для TON, и для USDT.</b></blockquote>"
    ),
    "your_deals_message": "📋 <b>Ваши сделки:</b>",
    "my_deals_button": "📋 Мои сделки",
    "my_profile_button": "👤 Мой профиль",
    "history_deals_button": "📋 История сделок",
    "profile_message": (
        "<b>👤 Мой профиль</b>\n\n"
        "<b>{name}</b>\n"
        "<b>ID:</b> <code>{user_id}</code>\n\n"
        "<b>Завершённых сделок:</b> <code>{deals_count}</code>\n"
        "<b>Репутация:</b> {reputation}\n"
        "<b>Оценка:</b> 👍 <code>{likes}</code>  👎 <code>{dislikes}</code>\n\n"
        "<blockquote>"
        "<b>💰 Баланс</b>\n"
        "🔹 <b>TON:</b> <code>{balance_ton}</code>\n"
        "🔹 <b>USDT:</b> <code>{balance_usdt}</code>"
        "</blockquote>\n\n"
        "<b>Зарегистрирован:</b> <i>{registered}</i>"
    ),
    "profile_vouches_line": "<code>{rating}★ ({count} отзывов)</code>",
    "vouches_short_line": "{rating}★ ({count} отзывов)",
    "my_deals_intro_message": "📋 <b>Мои сделки</b>\n\n<blockquote><b>Выберите тип сделок которые хотите посмотреть 👇</b></blockquote>",
    "deals_type_gifts_button": "🎁 Подарки",
    "deals_type_channel_button": "📢 Канал",
    "deals_type_accounts_button": "🆕 Аккаунты",
    "deals_type_other_goods_button": "📦 Другие товары",
    "deals_type_account_button": "🆕 Аккаунты",
    "deals_type_game_currency_button": "🎮 Игровая валюта",
    "choose_deal_subtype_message": "<b>❔ Выберите тип товара</b>",
    "seller_confirm_sent_button_product": "✅ Подтверждаю передачу товара",
    "seller_confirm_sent_message_product": (
        "✅ <b>Вы подтвердили передачу товара для сделки</b> <code>{deal_id_short}</code>\n\n"
        "<b>Ожидайте подтверждения получения от покупателя</b>\n\n"
        "<blockquote><b>Убедитесь, что передали товар покупателю &#64;{buyer_username}, в противном случае покупатель не сможет подтвердить получение, а вы не получите оплату</b></blockquote>"
    ),
    "deal_details_message": (
        "<b>📄 Сделка #{deal_id_short}</b>\n\n"
        "<b>💰 Сумма:</b> {amount} {valute}\n"
        "<b>📝 Описание:</b> {description}\n"
        "<b>🔄 Статус:</b> {status}\n"
        "<b>👤 Вторая сторона:</b> @{other_user}\n"
        "<b>📅 Дата создания:</b> {created_at}\n\n"
        "<i>Вы {role} в этой сделке</i>"
    ),
    "deal_role_seller": "продавец",
    "deal_role_buyer": "покупатель",
    "deal_status_active": "⏳ В работе",
    "deal_status_confirmed": "⏳ Ожидание отправки",
    "deal_status_seller_sent": "⏳ Ожидание подтверждения",
    "deal_status_completed": "✅ Завершена",
    "deal_status_cancelled": "❌ Отменена",
    "cancel_deal_button": "🔴 Выйти из сделки",
    "deal_cancelled_message": "✅ <b>Сделка #{deal_id_short} отменена.</b>",
    "back_to_deals_button": "🔙 Назад к списку сделок",
    "no_access_to_deal_message": "🚫 У вас нет доступа к этой сделке.",

    # ============================================================
    # Админ-панель (доступна только GARANT_ADMIN_USER_ID)
    # ============================================================
    "admin_only": "🚫 Команда доступна только администратору.",
    "admin_menu_title": (
        "🛠 <b>Админ-панель</b>\n\n"
        "Выбери раздел:"
    ),
    "admin_btn_stats":  "📊 Статистика",
    "admin_btn_wallet": "💼 Кошелёк бота",
    "admin_btn_token":  "🔑 Бот-токен",
    "admin_btn_deal":   "🤝 Сделка",
    "admin_btn_user":   "👤 Пользователь",
    "admin_btn_withdrawals": "📤 Заявки на вывод ({count})",
    "admin_btn_disputes": "⚠️ Споры ({count})",
    "admin_disputes_empty": "Открытых споров нет.",
    "admin_disputes_title": "⚠️ <b>Открытые споры</b>\n",
    "admin_btn_dispute_chat": "💬 Чат споров",
    "admin_dispute_chat_message": "💬 <b>Чат разбора споров</b>\n\n<b>Текущая ссылка:</b> {link}\n\n<i>Эту ссылку получают оба участника при открытии спора.</i>",
    "admin_dispute_chat_empty": "<i>не задана</i>",
    "admin_dispute_chat_ask": "Пришли ссылку на чат разбора споров (например <code>https://t.me/+abc123</code> или <code>t.me/your_dispute_chat</code>).",
    "admin_dispute_chat_invalid": "❌ Неверный формат. Нужна ссылка на Telegram-чат: <code>https://t.me/...</code> или <code>t.me/...</code>",
    "admin_dispute_chat_saved": "✅ <b>Ссылка на чат споров сохранена:</b>\n{link}",
    "open_dispute_button": "⚠️ Открыть спор",
    "dispute_chat_button": "💬 Чат разбора",
    "dispute_opened_msg": (
        "⚠️ <b>Спор открыт по сделке</b> <code>#{deal_id_short}</code>\n\n"
        "<blockquote><b>Действия по сделке заблокированы.</b>\n"
        "<b>Решение принимает администратор.</b>\n"
        "<b>Перейди в чат разбора и опиши ситуацию.</b></blockquote>"
    ),
    "dispute_opened_no_chat_msg": (
        "⚠️ <b>Спор открыт по сделке</b> <code>#{deal_id_short}</code>\n\n"
        "<blockquote><b>Действия по сделке заблокированы.</b>\n"
        "<b>Свяжись с администратором: @{support}</b></blockquote>"
    ),
    "dispute_opened_admin_msg": (
        "⚠️ <b>Открыт спор</b>\n"
        "<b>Сделка:</b> <code>#{deal_id_short}</code>\n"
        "<b>Сумма:</b> {amount} {currency}\n"
        "<b>Продавец:</b> <code>{seller_id}</code>\n"
        "<b>Покупатель:</b> <code>{buyer_id}</code>\n"
        "<b>Инициатор:</b> <code>{initiator_id}</code>\n\n"
        "Открой <code>/admin → ⚠️ Споры</code> для разбора."
    ),
    "dispute_action_blocked": "❌ По сделке открыт спор. Действия — только через администратора.",
    "dispute_already_open": "Спор по этой сделке уже открыт.",
    "dispute_cannot_open_completed": "❌ Сделка уже закрыта — спор открыть нельзя.",
    "dispute_status_label": "⚠️ <b>Статус: спор</b>",
    "admin_btn_back":   "‹ Назад",
    "admin_btn_change": "✏️ Сменить",
    "admin_wd_empty": "Заявок на вывод нет.",
    "admin_wd_list_title": "📤 <b>Заявки на вывод</b> (в очереди)",
    "admin_wd_item": (
        "#{wid} — <b>{amount} {currency}</b>\n"
        "Юзер: <code>{user_id}</code>\n"
        "Адрес: <code>{address}</code>\n"
        "Создана: {created_at}"
    ),
    "admin_btn_wd_sent": "✅ Выплачено",
    "admin_btn_wd_reject": "✖ Отклонить (возврат)",
    "admin_wd_sent_done": "✅ Заявка #{wid} помечена как выплаченная.",
    "admin_wd_rejected_done": "✖ Заявка #{wid} отклонена, средства возвращены.",

    "admin_stats_message": (
        "📊 <b>Статистика</b>\n\n"
        "Пользователей: <b>{users}</b>\n"
        "Сделок всего: <b>{deals_total}</b>\n"
        "   • активных: <b>{deals_active}</b>\n"
        "   • завершённых: <b>{deals_done}</b>\n"
        "   • отменённых: <b>{deals_cancel}</b>\n\n"
        "Депозиты:\n"
        "   • TON: <b>{dep_ton}</b>\n"
        "   • USDT: <b>{dep_usdt}</b>\n\n"
        "Заявки на вывод:\n"
        "   • в очереди: <b>{wd_pending}</b>\n"
        "   • выплачено: <b>{wd_sent}</b>"
    ),

    "admin_wallet_message": (
        "💼 <b>Общий TON-кошелёк бота</b>\n\n"
        "Текущий адрес:\n<code>{address}</code>\n\n"
        "На него поступают пополнения юзеров (TON и USDT-jetton). Один и тот же адрес используется для обеих валют."
    ),
    "admin_wallet_empty": "<i>не задан</i>",
    "admin_wallet_ask":   "<b>Отправь новый TON-адрес общего кошелька (48 символов, EQ/UQ):</b>",
    "admin_wallet_saved": "✅ <b>Адрес сохранён:</b>\n<code>{address}</code>",

    "admin_token_message": (
        "🔑 <b>Токен гарант-бота</b>\n\n"
        "Текущий токен: <code>{masked}</code>\n\n"
        "<i>После смены токена нужно перезапустить бота (python main.py).</i>"
    ),
    "admin_token_empty": "<i>не задан</i>",
    "admin_token_ask":   "Отправь новый токен от @BotFather (формат <code>123456:AAA...</code>):",
    "admin_token_invalid": "❌ <b>Неверный формат токена.</b>\n<i>Должно быть</i> <code>123456:AA...</code>",
    "admin_token_saved": "✅ <b>Токен сохранён.</b>\n<i>Перезапусти бота, чтобы он применился.</i>",

    "admin_deal_ask": "Введи ID сделки (полный или короткий):",
    "admin_deal_not_found": "❌ Сделка не найдена.",
    "admin_deal_card": (
        "🤝 <b>Сделка</b> <code>{deal_id_short}</code>\n\n"
        "Статус: <b>{status}</b>\n"
        "Сумма: <b>{amount} {currency}</b>\n"
        "Продавец: <code>{seller_id}</code>\n"
        "Покупатель: <code>{buyer_id}</code>\n"
        "Описание: {description}\n"
        "Создана: {created_at}"
    ),
    "admin_btn_deal_confirm": "💸 Подтвердить оплату",
    "admin_btn_deal_complete": "✅ Завершить сделку",
    "admin_btn_deal_cancel":  "✖ Отменить сделку",
    "admin_btn_resolve_seller": "⚖️ В пользу продавца",
    "admin_btn_resolve_buyer":  "⚖️ В пользу покупателя",
    "admin_deal_done": "✅ Готово.",
    "admin_deal_action_failed": "❌ Не удалось: {reason}",

    "admin_user_ask": "<b>Введи user_id юзера:</b>",
    "admin_user_not_found": "❌ <b>Пользователь не найден.</b>",
    "admin_user_card": (
        "👤 <b>Карточка пользователя</b>\n\n"
        "<b>Имя:</b> {name}\n"
        "<b>ID:</b> <code>{user_id}</code>\n\n"
        "<blockquote>"
        "<b>📊 Статистика</b>\n"
        "🔹 <b>Завершённых сделок:</b> <code>{deals_count}</code>\n"
        "🔹 <b>Репутация:</b> 👍 <code>{likes}</code>  👎 <code>{dislikes}</code>"
        "</blockquote>\n\n"
        "<blockquote>"
        "<b>💰 Балансы</b>\n"
        "🔹 <b>TON:</b> <code>{ton}</code>\n"
        "🔹 <b>USDT:</b> <code>{usdt}</code>\n"
        "🔹 <b>STARS:</b> <code>{stars}</code>"
        "</blockquote>"
    ),
    "admin_btn_credit_ton":  "+ TON",
    "admin_btn_debit_ton":   "− TON",
    "admin_btn_credit_usdt": "+ USDT",
    "admin_btn_debit_usdt":  "− USDT",
    "admin_btn_credit_stars": "+ STARS",
    "admin_btn_debit_stars":  "− STARS",
    "admin_balance_ask_amount": "Введи сумму в {currency} ({sign}):",
    "admin_balance_done": "✅ Баланс {currency} пользователя <code>{user_id}</code> теперь <b>{new_balance}</b>",
    "admin_balance_invalid": "❌ Введи положительное число.",
    "admin_balance_low": "❌ Недостаточно для списания. Текущий баланс: {balance}",

    # P5.37: localized fallbacks for network/internal errors (was hardcoded RU in bot.py).
    "error_network": "🚫 <b>Ошибка сети. Пожалуйста, попробуйте позже.</b>",
    "error_generic": "🚫 <b>Произошла ошибка. Пожалуйста, попробуйте позже.</b>",
}

EN_TEXTS = {
    "start_message": (
        "👋 <b>Welcome!</b>\n\n"
        "💼 <b>Reliable service for safe deals!</b>\n"
        "✨ <b>Automated, fast and hassle-free!</b>\n\n"
        "<blockquote>"
        "🔹 <b>Service commission: <code>{commission}%</code></b>\n"
        "🔹 <b>24/7 Support: @{support}</b>\n"
        "🔹 <b>User reviews: {reviews}</b>\n"
        "</blockquote>\n\n"
        "💌 <b>Your deals are now protected!</b> 🛡️"
    ),
    "wallet_menu_message": "💰 <b>My requisites</b>\n\n<blockquote><b>Choose a requisite from the list or add a new one:</b></blockquote>",
    "wallet_empty_placeholder": "⚪ Nothing here",
    "add_wallet_short_button": "👛 Add wallet",
    "add_ton_row_button": "💼 Add TON",
    "add_card_row_button": "💳 Add card",
    "add_stars_row_button": "⭐ Add stars recipient",
    "delete_requisite_button": "🗑",
    "requisite_detail_ton": "💼 TON wallet:\n<code>{value}</code>",
    "requisite_detail_card": "💳 Card:\n<code>{value}</code>",
    "requisite_detail_stars": "⭐ Stars recipient:\n<code>@{value}</code>",
    "wallet_card_button": "💳 Card",
    "wallet_ton_button": "💼 TON wallet",
    "stars_contact_button": "⭐ Stars recipient",
    "stars_contact_message": "<blockquote><b>Enter @username for receiving stars (5-32 characters: letters, numbers, underscore).</b></blockquote>\n<i>Example: @username</i>",
    "enter_name_for_wallet_message": "<b>Enter a name for the wallet (at least 5 letters, only Russian or English letters):</b>",
    "ask_name_for_card_message": "✅ <b>Card added!</b>\n\n<blockquote><b>Would you like to add a name for the card?</b></blockquote>",
    "ask_name_for_stars_message": "✅ <b>Username added!</b>\n\n<blockquote><b>Would you like to add a name for the requisite?</b></blockquote>",
    "enter_name_for_card_message": "Enter a name for the card (at least 5 letters, only Russian or English letters):",
    "enter_name_for_stars_message": "Enter a name for the requisite (at least 5 letters, only Russian or English letters):",
    "invalid_requisite_name_message": "❌ Name: at least 5 letters, only Russian or English letters (no digits or symbols).",
    "requisite_already_exists_message": (
        "❌ <b>This requisite type is already added</b>\n\n"
        "<blockquote>"
        "Delete the existing one in «My requisites» and add a new one."
        "</blockquote>"
    ),
    "creator_cannot_join_own_deal_message": "<blockquote><b>❌ You cannot join your own deal. This link is for the buyer.</b></blockquote>",
    "valute_stars": "Stars",
    "stars_username_saved": "✅ Username for receiving stars saved: <code>{username}</code>",
    "invalid_stars_username_message": "<blockquote><b>❌ Invalid username format. Must be 5-32 characters (Latin letters, digits, underscore). Example: @username</b></blockquote>",
    "no_stars_username_for_deal_message": "<blockquote><b>❌ For a Stars deal, set the stars recipient in «My requisites» → «Stars recipient».</b></blockquote>",
    "add_ton_wallet_message": (
        "👛 <b>Adding wallet (TON network)</b>\n\n"
        "<blockquote><b>Send the TON network wallet address (48 characters, starts with EQ or UQ).</b></blockquote>\n"
        "<i>Works for receiving TON and USDT. Example: UQAbc123...xyz</i>"
    ),
    "add_ton_wallet_message_with_current": (
        "💼 Your current wallet: <code>{current_wallet}</code>\n\n"
        "Send a new TON network wallet address (48 characters, EQ or UQ)."
    ),
    "add_card_message": (
        "💳 <b>Adding card</b>\n"
        "<blockquote><b>Send bank and card number (12-19 digits) in format: Bank - Number</b></blockquote>\n"
        "<i>Example: Sberbank - 4276123456789012</i>"
    ),
    "add_card_message_with_current": (
        "💳 Your current card details: <code>{current_card}</code>\n\n"
        "Send details in format: <code>Bank - Number</code> (12-19 digits)\n"
        "<i>Example: Sberbank - 4276123456789012</i>"
    ),
    "no_requisites_message": "<blockquote><b>❌ Please add payment details before creating a deal.</b></blockquote>",
    "no_ton_wallet_for_deal_message": "<blockquote><b>❌ Link your TON wallet before creating a deal. The same address is used for both TON and USDT.</b></blockquote>",
    "no_card_for_deal_message": "<blockquote><b>❌ Card payment requires linked card details. Add them in «Add/change requisites».</b></blockquote>",
    "invalid_ton_wallet_message": "❌ Invalid wallet format!\n\nTry again 👇",
    "invalid_card_message": "❌ Invalid format. Use format: <code>Bank - Number</code> (12-19 digits). Example: Sberbank - 4276123456789012",
    "deal_already_has_buyer_message": (
        "🚫 <b>Deal already taken</b>\n\n"
        "<blockquote>"
        "<b>Another buyer has already joined this deal.</b>\n"
        "If you want — create your own deal from the main menu 👇"
        "</blockquote>"
    ),
    "choose_payment_method_message": "<blockquote><b>💰 Choose deal currency 👇</b></blockquote>",
    "create_deal_message": (
        "💼 <b>Create a deal</b>\n\n"
        "<blockquote><b>Enter the deal amount in {valute} in format <code>123.4</code> 👇</b></blockquote>"
    ),
    "wallet_added_ask_name_message": (
        "✅ <b>Wallet added!</b>\n\n"
        "<blockquote><b>Would you like to add a name for the wallet?</b></blockquote>"
    ),
    "add_name_button": "➕ Add name",
    "skip_button": "Skip",
    "wallet_added_success_message": (
        "👛 New wallet successfully added!\n\n"
        "Address: <code>{wallet_address}</code>"
    ),
    "change_lang_message": "<b>Choose language</b>",
    "change_lang_instruction_ru": "<blockquote><b>🇷🇺 → Выберите язык бота прежде чем начать пользоваться.</b></blockquote>",
    "change_lang_instruction_en": "<blockquote><b>🇺🇸 → Choose the bot's language before you start using it.</b></blockquote>",
    "lang_set_success_message": (
        "🎉 <b>Language successfully set!</b>\n\n"
        "<blockquote>Click the button below to go 👇 to the main menu.</blockquote>"
    ),
    "lang_rus_button": "🇷🇺 RUS",
    "lang_eng_button": "🇺🇸 ENG",
    "awaiting_description_message": (
        "💼 <b>Create a deal</b>\n\n"
        "<blockquote><b>Specify what you are offering in the deal. Example: <code>10 Peaches and a Cap</code> 👇</b></blockquote>"
    ),
    "wallet_updated": "🔗 {wallet_type} updated: <code>{details}</code>",
    "choose_deal_type_message": "<b>❔ Choose deal type!</b>",
    "deal_created_message": (
        "💥 <b>Deal successfully created!</b>\n"
        "<b>Deal type: 🎁 Gifts</b>\n\n"
        "<b>You give:</b> <code>{description}</code>\n"
        "<b>You receive:</b> <code>{amount} {valute}</code>\n\n"
        "<b>⛓️ Link for buyer:</b>\n"
        "<code>https://t.me/{bot_username}?start={deal_id}</code>"
    ),
    "deal_info_ton_message": (
        "<b>💼 Deal</b> <code>{deal_id_short}</code>\n\n"
        "<i><b>👤 You are the buyer.</b></i>\n\n"
        "<i><b>📌 Seller:</b></i> <b>@{seller_username}</b> <b>(</b><code>{seller_id}</code><b>)</b>\n"
        "<i><b>• Deals:</b></i> <code>{successful_deals}</code>\n"
        "<i><b>• Rating:</b></i> <code>{seller_vouches_line}</code>\n\n"
        "<i><b>• You are buying:</b></i> <code>{description}</code>\n"
        "<i><b>• To pay:</b></i> <b>{amount} {valute}</b>\n\n"
        "<blockquote><b>💸 Payment is made from the bot's internal balance. "
        "If you don't have enough — top up your wallet.</b></blockquote>"
    ),
    "deal_info_sbp_message": (
        "<b>💼 Deal</b> <code>{deal_id_short}</code>\n"
        "<b>Deal type: 🎁 Gifts</b>\n\n"
        "<i><b>👤 You are the buyer, you have 15 minutes to pay for the deal!</b></i>\n\n"
        "<i><b>📌 Seller:</b></i> <b>@{seller_username}</b> <b>(</b><code>{seller_id}</code><b>)</b>\n\n"
        "<i><b>• Number of seller's deals:</b></i> <code>{successful_deals}</code>\n"
        "<i><b>• Seller's deal amount:</b></i> <code>{seller_total_usd}</code>\n"
        "<i><b>• Seller rating:</b></i> <code>{seller_vouches_line}</code>\n\n"
        "<i><b>• You are buying:</b></i> <code>{description}</code>\n"
        "<i><b>• You are giving:</b></i> <code>{amount} {valute}</code>\n\n"
        "<i><b>💳 Card for payment:</b></i>\n"
        "<code>{card}</code>\n\n"
        "<b>💸 Amount to pay:</b>\n"
        "💎 <code>{amount}</code> <b>{valute}</b>\n\n"
        "<i><b>🚨 Transaction comment:</b></i> <code>{deal_id}</code>\n\n"
        "<blockquote><b>‼️ Please make sure to specify the mandatory comment (memo) and exact amount when paying!</b></blockquote>\n\n"
        "<b>Payment will be confirmed automatically.</b>"
    ),
    "deal_info_stars_message": (
        "<b>💼 Deal</b> <code>{deal_id_short}</code>\n"
        "<b>Deal type: 🎁 Gifts</b>\n\n"
        "<i><b>👤 You are the buyer, you have 15 minutes to pay for the deal!</b></i>\n\n"
        "<i><b>📌 Seller:</b></i> <b>@{seller_username}</b> <b>(</b><code>{seller_id}</code><b>)</b>\n\n"
        "<i><b>• Number of seller's deals:</b></i> <code>{successful_deals}</code>\n"
        "<i><b>• Seller's deal amount:</b></i> <code>{seller_total_usd}</code>\n"
        "<i><b>• Seller rating:</b></i> <code>{seller_vouches_line}</code>\n\n"
        "<i><b>• You are buying:</b></i> <code>{description}</code>\n"
        "<i><b>• You are giving:</b></i> <code>{amount} Stars</code>\n\n"
        "<i><b>🌟 Payment via Telegram Stars:</b></i>\n"
        "<b>Transfer stars here:</b> @{support_username}\n\n"
        "<b>💸 Amount to pay:</b>\n"
        "💎 <code>{amount}</code> <b>Stars</b>\n\n"
        "<blockquote><b>‼️ Specify the exact amount when transferring. After payment, wait for administrator confirmation.</b></blockquote>\n\n"
        "<b>Payment will be confirmed after verification.</b>"
    ),
    "payment_confirmed_message": (
        "💥 <b>Transaction for deal</b> <code>{deal_id_short}</code> <b>found!</b>\n\n"
        "<b>Deal type: 🎁 Gifts</b>\n\n"
        "<b>👤 Seller:</b> <b>@{seller_username}</b> <b>(</b><code>{seller_id}</code><b>)</b>\n\n"
        "<b>You receive:</b> <code>{description}</code>\n"
        "<b>You give:</b> <code>{amount} {valute}</code>\n\n"
        "<blockquote><b>‼️ The deal will complete after the seller delivers the item to you and you confirm it.</b></blockquote>"
    ),
    "payment_confirmed_seller_message": (
        "💥 <b>Payment received for deal</b> <code>{deal_id_short}</code>!\n\n"
        "<blockquote>‼️ <b>Deliver the item → @{buyer_username}</b> ‼️</blockquote>\n\n"
        "<b>Deal type:</b> 🎁 <b>Gifts</b>.\n"
        "<b>👤 Buyer:</b> <b>@{buyer_username}</b> <b>(</b><code>{buyer_id}</code><b>)</b>\n\n"
        "<blockquote>‼️ <b>Deliver the item → @{buyer_username}</b> ‼️</blockquote>\n\n"
        "<b>You receive:</b> <code>{amount} {valute}</code>\n"
        "<b>You give:</b> <code>{description}</code>\n\n"
        "<blockquote>‼️ <b>Deliver the item only to the buyer @{buyer_username}</b>\n"
        "<b>If you deliver to another person, no refund will be made.</b>\n"
        "<b>For warranty, record the moment of transfer on video.</b></blockquote>"
    ),
    "payment_confirmed_seller_message_account": (
        "💥 <b>Payment received for deal</b> <code>{deal_id_short}</code>!\n\n"
        "<blockquote>‼️ <b>Send account data only to @{buyer_username}</b> ‼️</blockquote>\n\n"
        "<b>Deal type:</b> 🆕 <b>Accounts</b>.\n"
        "<b>👤 Buyer:</b> <b>@{buyer_username}</b> <b>(</b><code>{buyer_id}</code><b>)</b>\n\n"
        "<blockquote>‼️ <b>Send account data only to @{buyer_username}</b> ‼️</blockquote>\n\n"
        "<b>You receive:</b> <code>{amount} {valute}</code>\n"
        "<b>You give:</b> <code>{description}</code>\n\n"
        "<blockquote><b>Send account data only to @{buyer_username}.</b>\n"
        "<b>If you send to another person, no refund will be made.</b></blockquote>"
    ),
    "seller_confirm_sent_message": (
        "✅ <b>You confirmed delivery of the gift for deal</b> <code>{deal_id_short}</code>\n\n"
        "<b>Waiting for the buyer's confirmation of receipt</b>\n\n"
        "<blockquote><b>Make sure you have delivered the gift to the buyer &#64;{buyer_username}, otherwise the buyer will not be able to see and confirm the delivery, and you will not receive payment</b></blockquote>"
    ),
    "seller_confirm_sent_notification": (
        "🚀 <b>Seller confirmed delivery for deal</b> <code>{deal_id_short}!</code>\n\n"
        "<blockquote><b>Please check that you received the item and confirm by pressing the button below. 👆</b></blockquote>"
    ),
    "buyer_confirm_received_message": (
        "✅ <b>Successful deal!</b>\n\n"
        "<b>You confirmed receipt of the gift.</b>\n\n"
        "<b>Deal completed!</b>"
    ),
    "buyer_rate_seller_message": (
        "✅ <b>Deal completed!</b>\n\n"
        "<blockquote><b>Rate the seller:</b></blockquote>"
    ),
    "seller_rate_buyer_message": (
        "✅ <b>Deal completed!</b>\n\n"
        "<blockquote><b>Rate the buyer:</b></blockquote>"
    ),
    "vote_recorded_message": "✅ <b>Thanks! Your feedback is recorded.</b>",
    "vote_already_message": "❌ You already rated this participant.",
    "seller_deal_completed_message": (
        "✅ <b>Deal successfully completed!</b>\n\n"
        "<blockquote>"
        "<b>Buyer confirmed receipt of the item.</b>\n"
        "<b>Funds already credited to your internal balance.</b>\n\n"
        "<i>Withdraw via</i> <b>Wallet → Withdraw</b> <i>(auto-payout 1-2 min).</i>"
        "</blockquote>\n\n"
        "<b>Rate the buyer:</b>"
    ),
    "payout_stars_ton_only": "<blockquote><b>Stars payout to TON only. Contact support.</b></blockquote>",
    "payout_wallet_chosen_minimum": "<b>Withdrawal amount is below the minimum allowed.</b>",
    "seller_notification_message": (
        "<b>👤 User</b> <b>@{buyer_username}</b> <b>(</b><code>{buyer_id}</code><b>)</b>\n"
        "<b>has joined your deal</b> <code>{deal_id_short}</code>\n\n"
        "<i><b>• Number of buyer's deals:</b></i> <code>{successful_deals}</code>\n"
        "<i><b>• Buyer's deal amount:</b></i> <code>{buyer_total_usd}</code>\n"
        "<i><b>• Buyer rating:</b></i> <code>{buyer_vouches_line}</code>\n\n"
        "<blockquote>‼️ <b>Make sure this is the same user you were talking to earlier!</b></blockquote>\n\n"
        "<b>Do not transfer the item(s) to the buyer @{buyer_username} until you receive a message from the bot confirming payment!</b>"
    ),
    "insufficient_balance_message": "❌ <b>Insufficient balance.</b>",
    "pay_from_balance_stars_not_available": "<blockquote><b>Pay from balance is not available for Stars deals. Transfer stars to support.</b></blockquote>",
    "admin_panel_message": "🔧 <b>Admin panel</b>:",
    "admin_broadcast_message": "📢 Enter the text for broadcasting to all users:",
    "broadcast_success_message": (
        "📢 <b>Broadcast completed.</b>\n"
        "✅ <b>Successfully sent:</b> <code>{success_count}</code>\n"
        "❌ <b>Errors:</b> <code>{fail_count}</code>"
    ),
    "admin_view_deals_message": "💳 Select a deal:",
    "admin_view_deal_message": (
        "<b>ℹ️ Deal Information #{deal_id_short}</b>\n\n"
        "👤 <b>Seller:</b> <b>@{seller_username}</b> <b>(ID: </b><code>{seller_id}</code><b>)</b>\n"
        "✅ Successful deals: {seller_successful_deals}\n\n"
        "👤 <b>Buyer:</b> <b>@{buyer_username}</b> <b>(ID: </b><code>{buyer_id}</code><b>)</b>\n"
        "✅ Successful deals: {buyer_successful_deals}\n\n"
        "➖➖➖➖➖➖➖➖➖➖\n\n"
        "📝 <b>Description:</b>\n{description}\n\n"
        "💰 <b>Amount:</b> {amount} {valute}\n"
        "💳 <b>Payment Details:</b>\n<code>{payment_details}</code>\n\n"
        "📊 <b>Status:</b> {status}"
    ),
    "admin_confirm_no_buyer": "<blockquote><b>Buyer must join the deal first.</b></blockquote>",
    "seller_confirm_no_buyer": "<blockquote><b>Buyer has not joined the deal. Contact support.</b></blockquote>",
    "admin_confirm_deal_message": (
        "✅ Payment for deal <b>#{deal_id_short}</b> confirmed by admin.\n"
        "Seller and buyer have been notified."
    ),
    "admin_cancel_deal_message": "❌ Deal <b>#{deal_id_short}</b> was cancelled by admin.",
    "deal_cancelled_notification": "❌ Deal <b>#{deal_id_short}</b> was cancelled by admin.",
    "admin_change_balance_message": "Enter user ID and new balance in the format: <code>user_id balance</code>",
    "admin_change_successful_deals_message": "Enter user ID and number of successful deals in the format: <code>user_id count</code>",
    "admin_change_valute_message": "<b>Enter new currency (e.g., TON, USD, EUR, RUB).</b>\n<i>Used for displaying user balance:</i>",
    "admin_manage_admins_message": "Enter user ID and action (add/remove) in the format: <code>user_id action</code>",
    "admin_added_message": "✅ User <code>{user_id}</code> has been added as an admin.",
    "admin_removed_message": "❌ User <code>{user_id}</code> has been removed from admins.",
    "admin_cannot_remove_self_message": "🚫 You cannot remove yourself from admins!",
    "admin_cannot_remove_super_admin_message": "🚫 Cannot remove a super admin.",
    "invalid_action_message": "<blockquote><b>❌ Invalid action. Use 'add' or 'remove'.</b></blockquote>",
    "admin_list_message": "👑 <b>List of administrators</b>:\n\n{admin_list}",
    "unknown_callback_error": "❌ Unknown action. Please select an option from the menu.",
    "lang_set_message": "✅ Language changed to English.",
    "menu_button": "🔙 Back to menu",
    "back_to_menu_button": "🔙 To menu",
    "back_button": "⬅️ Back",
    "worker_commands_button": "📋 Commands",
    "worker_commands_menu_message": "📋 <b>Worker commands</b>\n\nChoose action:",
    "worker_cmd_deals_count_button": "📊 Deals count",
    "worker_cmd_deals_sum_button": "💵 Deals sum",
    "worker_cmd_vouches_button": "⭐ Reviews",
    "worker_cmd_balance_button": "💰 Top up balance",
    "worker_balance_choose_type": "💰 <b>Balance top-up</b>\n\nChoose fiat or cryptocurrency.",
    "worker_balance_fiat_button": "Fiat",
    "worker_balance_crypto_button": "Cryptocurrency",
    "worker_balance_choose_currency_fiat": "<b>Choose currency (fiat - Stars, rubles, dollars, etc.):</b>",
    "worker_balance_choose_currency_crypto": "Choose cryptocurrency:",
    "worker_balance_enter_amount": "<b>Enter the amount to credit for</b> <code>{currency}</code> <b>(positive number, comma or dot):</b>",
    "worker_balance_credited": "✅ <b>Credited</b> <code>{amount}</code> {currency}.\n<i>Current balance:</i> <code>{balance}</code>",
    "worker_balance_invalid_amount": "Enter a positive number, e.g. <code>100</code> or <code>50.25</code>.",
    "worker_cmd_confirm_payment_button": "✅ Confirm payment",
    "worker_enter_deals_count": "Enter successful deals count (integer):",
    "worker_enter_deals_sum": "<b>Enter deals sum ($), e.g.</b> <code>1000</code> <b>or</b> <code>1500.50</code><b>:</b>",
    "worker_enter_vouches": "Enter rating and reviews count separated by space, e.g. <code>4.75 361</code>",
    "worker_deals_count_ok": "✅ Deals count updated.",
    "worker_deals_sum_ok": "✅ Deals sum set.",
    "worker_vouches_ok": "✅ Rating and reviews set.",
    "worker_confirm_payment_list_message": "✅ <b>Confirm payment</b>\n\nSelect deal to confirm:",
    "worker_confirm_payment_no_active": "<blockquote><b>No active deals awaiting payment confirmation.</b></blockquote>",
    "worker_confirm_payment_done": "✅ <b>Payment confirmed for deal.</b>",
    "worker_confirm_payment_button": "✅ Confirm payment",
    "worker_chat_deal_notice": (
        "💼 <b>Deal</b> <code>#{deal_id_short}</code>\n"
        "🎁 <b>Type:</b> {deal_type_label}\n\n"
        "<i>👤 Buyer joined - awaiting payment.</i>\n\n"
        "📌 <b>Seller:</b> {seller_line}\n"
        "👤 <b>Buyer:</b> {buyer_line}\n"
        "💎 <b>Amount:</b> <code>{amount}</code> {valute}\n"
        "📝 <b>Description:</b> <code>{description}</code>"
    ),
    "main_wallet_button": "💼 Wallet",
    "main_requisites_button": "💰 My requisites",
    "main_create_deal_button": "🤝 Create deal",
    "wallet_main_message": (
        "💼 <b>Wallet</b>\n\n"
        "Balance:\n"
        "   • TON: <b>{ton}</b> {ton_usd}\n"
        "   • USDT: <b>{usdt}</b> {usdt_usd}\n\n"
        "TON wallet for withdrawal: {ton_addr}"
    ),
    "wallet_no_addr": "<i>not linked</i>",
    "wallet_btn_dep": "Top up",
    "wallet_btn_wd": "Withdraw",
    "wallet_btn_dep_ton": "TON",
    "wallet_btn_dep_usdt": "USDT",
    "wallet_btn_wd_ton": "TON",
    "wallet_btn_wd_usdt": "USDT",
    "wallet_dep_choose_msg": "<b>Choose currency to top up:</b>",
    "wallet_wd_choose_msg": "<b>Choose currency to withdraw:</b>",
    "amount_invalid_message": "❌ Enter a number.",
    "wallet_btn_set_addr": "🔗 Link TON address",
    "wallet_btn_my_withdrawals": "📤 My withdrawals",
    "my_withdrawals_empty": "No withdrawal requests yet.",
    "my_withdrawals_title": "📤 <b>My withdrawals</b>\n",
    "my_withdrawals_item": (
        "#{wid} — <b>{amount} {currency}</b>\n"
        "Address: <code>{address}</code>\n"
        "Status: {status_emoji} <i>{status}</i>\n"
        "Created: {created_at}"
    ),
    "wd_status_pending": "pending",
    "wd_status_sent": "sent",
    "wd_status_rejected": "rejected",
    "wallet_btn_my_requisites": "💰 My requisites",
    "deposit_ton_message": (
        "📥 <b>Deposit TON</b>\n\n"
        "Send TON to address:\n<code>{address}</code>\n\n"
        "❗️ <b>You must</b> include comment (memo):\n<code>{memo}</code>\n\n"
        "Minimum: <b>{min_amount} TON</b>\n"
        "Auto-credit within 1–2 minutes after network confirmation."
    ),
    "deposit_usdt_message": (
        "📥 <b>Deposit USDT</b> (TON network, jetton)\n\n"
        "Send USDT₮ to address:\n<code>{address}</code>\n\n"
        "❗️ <b>You must</b> include comment (memo):\n<code>{memo}</code>\n\n"
        "Minimum: <b>{min_amount} USDT</b>\n"
        "Auto-credit within 1–2 minutes."
    ),
    "deposit_disabled_message": "⚠️ Deposits temporarily unavailable. Please try later.",
    "withdraw_ask_address": "Enter recipient TON wallet address:",
    "withdraw_ask_amount": "<b>Enter withdrawal amount (minimum</b> <code>{min_amount}</code> <code>{currency}</code><b>):</b>",
    "withdraw_low_balance": "❌ Insufficient funds. Balance: {balance} {currency}.",
    "withdraw_below_min": (
        "❌ <b>Amount below minimum</b>\n\n"
        "<blockquote>"
        "<b>Minimum:</b> <code>{min_amount} {currency}</code>"
        "</blockquote>"
    ),
    "wd_too_frequent_message": (
        "⏳ <b>Too many withdrawal requests</b>\n\n"
        "<blockquote>"
        "You already have a recent withdrawal request. Please wait a moment."
        "</blockquote>"
    ),
    # P5.48: 24h aggregate cap
    "wd_daily_cap_exceeded": (
        "🚫 <b>Daily withdrawal cap exceeded</b>\n\n"
        "<blockquote>"
        "<b>Cap:</b> <code>{cap} {currency}</code> per 24h.\n"
        "Try again later or contact support."
        "</blockquote>"
    ),
    "cancel_after_sent_blocked_message": "❌ The item has already been delivered. Use «⚠️ Open dispute» instead of cancel.",
    "withdraw_submitted": (
        "✅ Withdrawal request created.\n\n"
        "Amount: <b>{amount} {currency}</b>\n"
        "Address: <code>{address}</code>\n\n"
        "Funds will arrive within a few minutes."
    ),
    "ton_addr_ask": "<b>Send your TON address (it will be saved for fast withdrawals):</b>",
    "ton_addr_invalid": "<blockquote><b>❌ Doesn't look like a TON address. It must start with EQ or UQ and have 48 characters.</b></blockquote>",
    "ton_addr_saved": "✅ Address saved: <code>{address}</code>",
    "main_how_deal_button": "🆘 How does a deal work?",
    "settings_button": "⚙️ Settings",
    "settings_menu_message": "⚙️ <b>Settings</b>",
    "settings_lang_button": "🇷🇺 Bot language",
    "pay_from_balance_button": "💸 Pay from balance",
    "add_wallet_button": "🪙 Add/change requisites",
    "add_ton_wallet_button": "💼 Add/change TON wallet",
    "add_card_button": "💳 Add/change card",
    "create_deal_button": "📄 Create deal",
    "change_lang_button": "🌐 Change language",
    "support_button": "📞 Support",
    "english_lang_button": "🇬🇧 English",
    "russian_lang_button": "🇷🇺 Русский",
    "admin_view_deals_button": "💳 View deals",
    "admin_change_balance_button": "💰 Change user balance",
    "admin_change_successful_deals_button": "✅ Change successful deals",
    "admin_change_valute_button": "💱 Change currency",
    "admin_manage_admins_button": "👑 Appoint/remove admin",
    "admin_list_button": "👑 List of administrators",
    "admin_manual_button": "📖 Admin manual",
    "admin_back_to_panel_button": "🔙 Back to admin panel",
    "admin_manual_message": (
        "<b>📖 Guarant bot - Admin manual</b>\n\n"
        "<b>💳 View deals</b>\n"
        "List of deals (active first - awaiting payment, then others). Deals older than 24 hours are auto-removed. Open any deal to see seller, buyer, amount, description. In an active deal card:\n"
        "• <b>Confirm</b> - you confirm that payment was received. Buyer and seller get notified; seller gets instructions to send the gift.\n"
        "• <b>Cancel</b> - cancel the deal. Both parties get notified.\n\n"
        "<b>💰 Change user balance</b>\n"
        "Enter one line: <code>user_id new_balance</code>\n"
        "Example: <code>123456789 150.5</code> - user 123456789 will have balance 150.5.\n\n"
        "<b>✅ Change successful deals</b>\n"
        "Enter one line: <code>user_id count</code>\n"
        "Example: <code>123456789 10</code> - user will show 10 successful deals (affects trust in deals).\n\n"
        "<b>💱 Change currency</b>\n"
        "Enter one currency, e.g. TON, RUB, USD. Used for displaying user balance in the bot.\n\n"
        "<b>💬 Set notification chat</b>\n"
        "Enter chat ID (e.g. <code>-1001234567890</code>). The bot will send notifications to this chat: new deal, payment confirmed, deal cancelled, deal completed. Add the bot to the chat and allow it to send messages.\n\n"
        "<b>📋 Set admin log chat</b> (super admin only)\n"
        "Enter chat ID. Admin action logs (balance, successful deals, currency, confirm/cancel deal) are sent to this chat.\n\n"
        "<b>🔗 Broadcast</b> (super admin only)\n"
        "After pressing, enter the message text. It will be sent to all bot users at once.\n\n"
        "<i>All admin actions are logged and sent to the chat set by super admin in the admin panel («Set admin log chat»).</i>"
    ),
    "admin_confirm_deal_button": "✅ Confirm",
    "admin_cancel_deal_button": "❌ Cancel",
    "seller_transfer_gift_button": "🎁 Transfer gift",
    "seller_confirm_sent_button": "✅ Confirm gift delivery",
    "buyer_confirm_received_button": "Confirm receipt of item",
    "contact_support_button": "🛟 Support",
    "payment_ton_button": "💎 TON",
    "payment_crypto_button": "🪙 Cryptocurrency",
    "payment_sbp_button": "💰 Currency",
    "payment_stars_button": "⭐ Stars",
    "choose_crypto_currency_message": "<blockquote><b>Choose cryptocurrency 👇</b></blockquote>\n<i>Wallet address is TON network (one for TON and USDT).</i>",
    "crypto_usdt_button": "💵 USDT",
    "crypto_ton_button": "💎 TON",
    "choose_card_currency_message": "<blockquote><b>Choose card currency 👇</b></blockquote>",
    "currency_rub_button": "🇷🇺 Rubles",
    "currency_uah_button": "🇺🇦 Hryvnias",
    "currency_usd_button": "🇺🇸 Dollars",
    "currency_eur_button": "🇪🇺 Euros",
    "currency_kzt_button": "🇰🇿 Tenge",
    "currency_byn_button": "🇧🇾 Bel. rubles",
    "currency_uzs_button": "🇺🇿 Sums",
    "currency_cny_button": "🇨🇳 Yuan",
    "not_specified_wallet": "not specified",
    "not_specified_card": "not specified",
    "no_deals_message": "📭 <b>You don't have any deals yet.</b>",
    "nothing_here_button": "⚪ Nothing here",
    "seller_total_placeholder": "0.00$",
    "buyer_total_placeholder": "0.00$",
    "buyer_add_wallet_first_message": (
        "<blockquote><b>‼️ Link your TON wallet before joining the deal. The same address is used for both TON and USDT.</b></blockquote>"
    ),
    "your_deals_message": "📋 <b>Your deals:</b>",
    "my_deals_button": "📋 My deals",
    "my_profile_button": "👤 My profile",
    "history_deals_button": "📋 Deal history",
    "profile_message": (
        "<b>👤 My profile</b>\n\n"
        "<b>{name}</b>\n"
        "<b>ID:</b> <code>{user_id}</code>\n\n"
        "<b>Completed deals:</b> <code>{deals_count}</code>\n"
        "<b>Reputation:</b> {reputation}\n"
        "<b>Rating:</b> 👍 <code>{likes}</code>  👎 <code>{dislikes}</code>\n\n"
        "<blockquote>"
        "<b>💰 Balance</b>\n"
        "🔹 <b>TON:</b> <code>{balance_ton}</code>\n"
        "🔹 <b>USDT:</b> <code>{balance_usdt}</code>"
        "</blockquote>\n\n"
        "<b>Registered:</b> <i>{registered}</i>"
    ),
    "profile_vouches_line": "<code>{rating}★ ({count} reviews)</code>",
    "vouches_short_line": "{rating}★ ({count} reviews)",
    "my_deals_intro_message": "📋 <b>My deals</b>\n\n<blockquote>Choose the type of deals you want to view 👇</blockquote>",
    "deals_type_gifts_button": "🎁 Gifts",
    "deals_type_channel_button": "📢 Channel",
    "deals_type_accounts_button": "🆕 Accounts",
    "deals_type_other_goods_button": "📦 Other goods",
    "deals_type_account_button": "🆕 Accounts",
    "deals_type_game_currency_button": "🎮 Game currency",
    "choose_deal_subtype_message": "<b>❔ Choose product type</b>",
    "seller_confirm_sent_button_product": "✅ Confirm product delivery",
    "seller_confirm_sent_message_product": (
        "✅ <b>You confirmed product delivery for deal</b> <code>{deal_id_short}</code>\n\n"
        "<b>Wait for buyer to confirm receipt</b>\n\n"
        "<blockquote><b>Make sure you sent the product to the buyer &#64;{buyer_username}, otherwise the buyer cannot confirm and you will not get paid</b></blockquote>"
    ),
    "deal_details_message": (
        "<b>📄 Deal #{deal_id_short}</b>\n\n"
        "<b>💰 Amount:</b> {amount} {valute}\n"
        "<b>📝 Description:</b> {description}\n"
        "<b>🔄 Status:</b> {status}\n"
        "<b>👤 Other party:</b> @{other_user}\n"
        "<b>📅 Created at:</b> {created_at}\n\n"
        "<i>You are the {role} in this deal</i>"
    ),
    "deal_role_seller": "seller",
    "deal_role_buyer": "buyer",
    "deal_status_active": "⏳ In progress",
    "deal_status_confirmed": "⏳ Awaiting shipment",
    "deal_status_seller_sent": "⏳ Awaiting confirmation",
    "deal_status_completed": "✅ Completed",
    "deal_status_cancelled": "❌ Cancelled",
    "cancel_deal_button": "🔴 Exit deal",
    "deal_cancelled_message": "✅ <b>Deal #{deal_id_short} cancelled.</b>",
    "back_to_deals_button": "🔙 Back to deals list",
    "no_access_to_deal_message": "🚫 You don't have access to this deal.",

    # ============================================================
    # Admin panel
    # ============================================================
    "admin_only": "🚫 Command for administrator only.",
    "admin_menu_title": "🛠 <b>Admin panel</b>\n\nChoose a section:",
    "admin_btn_stats":  "📊 Statistics",
    "admin_btn_wallet": "💼 Bot wallet",
    "admin_btn_token":  "🔑 Bot token",
    "admin_btn_deal":   "🤝 Deal",
    "admin_btn_user":   "👤 User",
    "admin_btn_withdrawals": "📤 Withdrawal requests ({count})",
    "admin_btn_disputes": "⚠️ Disputes ({count})",
    "admin_disputes_empty": "No open disputes.",
    "admin_disputes_title": "⚠️ <b>Open disputes</b>\n",
    "admin_btn_dispute_chat": "💬 Dispute chat",
    "admin_dispute_chat_message": "💬 <b>Dispute resolution chat</b>\n\n<b>Current link:</b> {link}\n\n<i>Both deal participants receive this link when a dispute is opened.</i>",
    "admin_dispute_chat_empty": "<i>not set</i>",
    "admin_dispute_chat_ask": "Send the link to the dispute chat (e.g. <code>https://t.me/+abc123</code> or <code>t.me/your_dispute_chat</code>).",
    "admin_dispute_chat_invalid": "❌ Invalid format. Need a Telegram chat link: <code>https://t.me/...</code> or <code>t.me/...</code>",
    "admin_dispute_chat_saved": "✅ <b>Dispute chat link saved:</b>\n{link}",
    "open_dispute_button": "⚠️ Open dispute",
    "dispute_chat_button": "💬 Dispute chat",
    "dispute_opened_msg": (
        "⚠️ <b>Dispute opened for deal</b> <code>#{deal_id_short}</code>\n\n"
        "<blockquote><b>Actions on the deal are blocked.</b>\n"
        "<b>Decision is made by the administrator.</b>\n"
        "<b>Join the dispute chat and describe the situation.</b></blockquote>"
    ),
    "dispute_opened_no_chat_msg": (
        "⚠️ <b>Dispute opened for deal</b> <code>#{deal_id_short}</code>\n\n"
        "<blockquote><b>Actions on the deal are blocked.</b>\n"
        "<b>Contact the administrator: @{support}</b></blockquote>"
    ),
    "dispute_opened_admin_msg": (
        "⚠️ <b>Dispute opened</b>\n"
        "<b>Deal:</b> <code>#{deal_id_short}</code>\n"
        "<b>Amount:</b> {amount} {currency}\n"
        "<b>Seller:</b> <code>{seller_id}</code>\n"
        "<b>Buyer:</b> <code>{buyer_id}</code>\n"
        "<b>Initiator:</b> <code>{initiator_id}</code>\n\n"
        "Open <code>/admin → ⚠️ Disputes</code> to review."
    ),
    "dispute_action_blocked": "❌ A dispute is open on this deal. Actions are handled by the administrator only.",
    "dispute_already_open": "A dispute is already open for this deal.",
    "dispute_cannot_open_completed": "❌ The deal is already closed — cannot open a dispute.",
    "dispute_status_label": "⚠️ <b>Status: disputed</b>",
    "admin_btn_back":   "‹ Back",
    "admin_btn_change": "✏️ Change",
    "admin_wd_empty": "No withdrawal requests.",
    "admin_wd_list_title": "📤 <b>Withdrawal queue</b>",
    "admin_wd_item": (
        "#{wid} — <b>{amount} {currency}</b>\n"
        "User: <code>{user_id}</code>\n"
        "Address: <code>{address}</code>\n"
        "Created: {created_at}"
    ),
    "admin_btn_wd_sent": "✅ Sent",
    "admin_btn_wd_reject": "✖ Reject (refund)",
    "admin_wd_sent_done": "✅ Request #{wid} marked as sent.",
    "admin_wd_rejected_done": "✖ Request #{wid} rejected, funds refunded.",

    "admin_stats_message": (
        "📊 <b>Statistics</b>\n\n"
        "Users: <b>{users}</b>\n"
        "Total deals: <b>{deals_total}</b>\n"
        "   • active: <b>{deals_active}</b>\n"
        "   • completed: <b>{deals_done}</b>\n"
        "   • cancelled: <b>{deals_cancel}</b>\n\n"
        "Deposits:\n"
        "   • TON: <b>{dep_ton}</b>\n"
        "   • USDT: <b>{dep_usdt}</b>\n\n"
        "Withdrawal requests:\n"
        "   • pending: <b>{wd_pending}</b>\n"
        "   • sent: <b>{wd_sent}</b>"
    ),

    "admin_wallet_message": (
        "💼 <b>Bot's main TON wallet</b>\n\n"
        "Current address:\n<code>{address}</code>\n\n"
        "Receives user top-ups (TON and USDT-jetton). Same address for both currencies."
    ),
    "admin_wallet_empty": "<i>not set</i>",
    "admin_wallet_ask":   "<b>Send the new TON address (48 chars, EQ/UQ):</b>",
    "admin_wallet_saved": "✅ <b>Address saved:</b>\n<code>{address}</code>",

    "admin_token_message": (
        "🔑 <b>Garant bot token</b>\n\n"
        "Current token: <code>{masked}</code>\n\n"
        "<i>After changing the token, restart the bot (python main.py).</i>"
    ),
    "admin_token_empty": "<i>not set</i>",
    "admin_token_ask":   "Send the new token from @BotFather (<code>123456:AAA...</code>):",
    "admin_token_invalid": "❌ <b>Wrong token format.</b>\n<i>Expected</i> <code>123456:AA...</code>",
    "admin_token_saved": "✅ <b>Token saved.</b>\n<i>Restart the bot to apply.</i>",

    "admin_deal_ask": "Send deal ID (full or short):",
    "admin_deal_not_found": "❌ Deal not found.",
    "admin_deal_card": (
        "🤝 <b>Deal</b> <code>{deal_id_short}</code>\n\n"
        "Status: <b>{status}</b>\n"
        "Amount: <b>{amount} {currency}</b>\n"
        "Seller: <code>{seller_id}</code>\n"
        "Buyer: <code>{buyer_id}</code>\n"
        "Description: {description}\n"
        "Created: {created_at}"
    ),
    "admin_btn_deal_confirm": "💸 Confirm payment",
    "admin_btn_deal_complete": "✅ Complete deal",
    "admin_btn_deal_cancel":  "✖ Cancel deal",
    "admin_btn_resolve_seller": "⚖️ Rule for seller",
    "admin_btn_resolve_buyer":  "⚖️ Rule for buyer",
    "admin_deal_done": "✅ Done.",
    "admin_deal_action_failed": "❌ Failed: {reason}",

    "admin_user_ask": "<b>Send user_id of the user:</b>",
    "admin_user_not_found": "❌ <b>User not found.</b>",
    "admin_user_card": (
        "👤 <b>User profile</b>\n\n"
        "<b>Name:</b> {name}\n"
        "<b>ID:</b> <code>{user_id}</code>\n\n"
        "<blockquote>"
        "<b>📊 Stats</b>\n"
        "🔹 <b>Completed deals:</b> <code>{deals_count}</code>\n"
        "🔹 <b>Reputation:</b> 👍 <code>{likes}</code>  👎 <code>{dislikes}</code>"
        "</blockquote>\n\n"
        "<blockquote>"
        "<b>💰 Balances</b>\n"
        "🔹 <b>TON:</b> <code>{ton}</code>\n"
        "🔹 <b>USDT:</b> <code>{usdt}</code>\n"
        "🔹 <b>STARS:</b> <code>{stars}</code>"
        "</blockquote>"
    ),
    "admin_btn_credit_ton":  "+ TON",
    "admin_btn_debit_ton":   "− TON",
    "admin_btn_credit_usdt": "+ USDT",
    "admin_btn_debit_usdt":  "− USDT",
    "admin_btn_credit_stars": "+ STARS",
    "admin_btn_debit_stars":  "− STARS",
    "admin_balance_ask_amount": "Enter amount in {currency} ({sign}):",
    "admin_balance_done": "✅ {currency} balance of <code>{user_id}</code> is now <b>{new_balance}</b>",
    "admin_balance_invalid": "❌ Enter a positive number.",
    "admin_balance_low": "❌ Insufficient for debit. Current balance: {balance}",

    # P5.37: localized fallbacks for network/internal errors (was hardcoded RU in bot.py).
    "error_network": "🚫 <b>Network error. Please try again later.</b>",
    "error_generic": "🚫 <b>An error occurred. Please try again later.</b>",
}

def get_text(lang: str, key: str, **kwargs) -> str:
    """
    Get localized text by key with optional formatting
    
    Args:
        lang (str): Language code ('ru' or 'en')
        key (str): Text key from RU_TEXTS/EN_TEXTS
        **kwargs: Formatting parameters
        
    Returns:
        str: Formatted localized text or key if not found
    """
    texts_to_use = RU_TEXTS if lang == 'ru' else EN_TEXTS
    message_template = texts_to_use.get(key, '')
    
    if not message_template:
        # Fallback to English if translation not found
        message_template = EN_TEXTS.get(key, key)  # Return key as default if not found
        
    try:
        return message_template.format(**kwargs)
    except KeyError as e:
        # P5.36: warn through the bot logger so it shows up in bot.log instead of stdout.
        logger.warning("Missing placeholder %s in text key '%s'", e, key)
        return message_template
    except Exception as e:
        logger.warning("Error formatting text for key '%s': %s", key, e)
        return key
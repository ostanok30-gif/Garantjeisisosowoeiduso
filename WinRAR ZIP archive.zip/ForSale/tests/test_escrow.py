# -*- coding: utf-8 -*-
"""
Pytest: проверка ключевой бизнес-логики escrow.

Запуск: pytest tests/
"""
import os
import sys
import sqlite3
import tempfile

import pytest


# ============================================================
# Фикстура: чистая БД во временной папке
# ============================================================

@pytest.fixture
def fresh_bot(monkeypatch, tmp_path):
    """Чистый импорт bot.py с временной БД, не пересекающейся с production."""
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    # Подменяем путь к БД в config до импорта bot.py
    import config
    db_path = str(tmp_path / "test.db")
    monkeypatch.setattr(config, "PUT_K_BD_GARANT", db_path, raising=False)
    monkeypatch.setattr(config, "GARANT_DB_PATH", db_path, raising=False)

    # Сбрасываем кэш модуля bot, если был импортирован раньше
    for name in list(sys.modules.keys()):
        if name == "no_main.bot" or name.startswith("no_main.bot."):
            del sys.modules[name]

    from no_main import bot
    bot.DB_NAME = db_path  # глобальная переменная в bot.py
    bot.init_db()
    bot.deals.clear()
    bot.user_data.clear()
    return bot


# ============================================================
# Тесты
# ============================================================

def test_escrow_happy_path(fresh_bot):
    """50 → 40 (заморозка) → 9.8 у продавца (с комиссией 2%)."""
    bot = fresh_bot
    bot.ensure_user_exists(100)
    bot.ensure_user_exists(200)
    bot.user_data[100]['balance_currencies'] = {'TON': 50.0}

    bot.deals['DEAL_HAPPY'] = {
        'amount': 10.0, 'description': 't', 'seller_id': 200, 'buyer_id': 100,
        'status': 'active', 'payment_method': 'ton', 'deal_type': 'gifts',
    }

    # Buyer pays: debit only
    bot._debit_user_balance_by_deal(100, 10.0, 'ton')
    bot.deals['DEAL_HAPPY']['status'] = 'confirmed'

    assert bot.user_data[100]['balance_currencies']['TON'] == 40.0
    assert bot.user_data[200].get('balance_currencies', {}).get('TON', 0) == 0.0

    # Buyer confirms received: credit seller minus 2%
    fee = 10.0 * 2 / 100
    net = 10.0 - fee
    bot._credit_user_balance_by_deal(200, net, 'ton')
    bot.deals['DEAL_HAPPY']['status'] = 'completed'

    assert bot.user_data[100]['balance_currencies']['TON'] == 40.0
    assert bot.user_data[200]['balance_currencies']['TON'] == pytest.approx(9.8)


def test_escrow_cancel_after_payment_refunds_buyer(fresh_bot):
    """Отмена после оплаты возвращает покупателю."""
    bot = fresh_bot
    bot.ensure_user_exists(100)
    bot.ensure_user_exists(200)
    bot.user_data[100]['balance_currencies'] = {'TON': 30.0}

    bot.deals['DEAL_CAN'] = {
        'amount': 5.0, 'description': 't', 'seller_id': 200, 'buyer_id': 100,
        'status': 'confirmed', 'payment_method': 'ton',
    }
    bot._debit_user_balance_by_deal(100, 5.0, 'ton')
    assert bot.user_data[100]['balance_currencies']['TON'] == 25.0

    # Refund (как в cancel_deal_*)
    bot._credit_user_balance_by_deal(100, 5.0, 'ton')
    bot.deals['DEAL_CAN']['status'] = 'cancelled'
    assert bot.user_data[100]['balance_currencies']['TON'] == 30.0


def test_deposit_idempotent(fresh_bot):
    """Один и тот же tx_hash зачисляется только раз."""
    bot = fresh_bot
    bot.ensure_user_exists(42)

    assert bot.record_deposit_and_credit("TX_AAA", 42, "TON", 5.0) is True
    assert bot.user_data[42]['balance_currencies']['TON'] == 5.0

    # Повтор — не должен зачислиться
    assert bot.record_deposit_and_credit("TX_AAA", 42, "TON", 5.0) is False
    assert bot.user_data[42]['balance_currencies']['TON'] == 5.0


def test_withdrawal_freezes_balance(fresh_bot):
    """create_withdrawal списывает с баланса и заводит запись."""
    bot = fresh_bot
    bot.ensure_user_exists(42)
    bot.user_data[42]['balance_currencies'] = {'TON': 10.0}

    wid = bot.create_withdrawal(42, 'TON', 3.0, 'UQ' + 'a' * 46)
    assert wid > 0
    assert bot.user_data[42]['balance_currencies']['TON'] == 7.0


def test_withdrawal_rejects_insufficient(fresh_bot):
    """Если средств меньше суммы — ValueError."""
    bot = fresh_bot
    bot.ensure_user_exists(42)
    bot.user_data[42]['balance_currencies'] = {'TON': 1.0}
    with pytest.raises(ValueError):
        bot.create_withdrawal(42, 'TON', 5.0, 'UQ' + 'a' * 46)


def test_user_ton_address_validation(fresh_bot):
    """Регексп TON-адреса принимает EQ/UQ + 46 base64url, отклоняет всё остальное."""
    bot = fresh_bot
    assert bot.is_valid_ton_address("UQ" + "a" * 46) is True
    assert bot.is_valid_ton_address("EQ" + "B" * 46) is True
    assert bot.is_valid_ton_address("XQ" + "a" * 46) is False
    assert bot.is_valid_ton_address("UQ" + "a" * 30) is False
    assert bot.is_valid_ton_address("") is False

# -*- coding: utf-8 -*-
"""Активные токены ботов: панель + гарант. Хранятся в admin_settings (БД), при отсутствии - fallback на config.

Импортируется из applications_bot.py, bot.py, gift_parser.py - чтобы при замене токена через
админку парсер сразу слал уведомления через нового бота (панель - hot-reload без рестарта,
гарант - после рестарта main.py)."""
import sqlite3
from typing import Optional

PANEL_TOKEN_DB_KEY = "panel_bot_token"
GARANT_TOKEN_DB_KEY = "garant_bot_token"


def _conn():
    """sqlite3 connection with per-connection PRAGMAs (P6.2).
    Mirrors bot._db_connect — busy_timeout=30s waits on writer-locks instead
    of immediately raising OperationalError; foreign_keys=ON enforces deletes.
    Don't share bot._db_connect to avoid circular import (config → panel_token → bot)."""
    from config import PUT_K_BD_GARANT
    c = sqlite3.connect(PUT_K_BD_GARANT)
    try:
        c.execute("PRAGMA busy_timeout=30000")
        c.execute("PRAGMA foreign_keys=ON")
    except Exception:
        c.close()
        raise
    return c


def _get_db_value(key: str) -> Optional[str]:
    try:
        c = _conn()
        cur = c.cursor()
        cur.execute("SELECT value FROM admin_settings WHERE key = ?", (key,))
        row = cur.fetchone()
        c.close()
        if row and row[0]:
            v = (row[0] or "").strip()
            return v if v else None
    except Exception:
        pass
    return None


def _set_db_value(key: str, value: str) -> tuple[bool, str]:
    try:
        c = _conn()
        cur = c.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS admin_settings (key TEXT PRIMARY KEY, value TEXT)")
        cur.execute(
            "INSERT OR REPLACE INTO admin_settings (key, value) VALUES (?, ?)",
            (key, str(value)),
        )
        c.commit()
        c.close()
        return True, ""
    except Exception as e:
        return False, repr(e)


def _delete_db_value(key: str) -> tuple[bool, str]:
    try:
        c = _conn()
        cur = c.cursor()
        cur.execute("DELETE FROM admin_settings WHERE key = ?", (key,))
        c.commit()
        c.close()
        return True, ""
    except Exception as e:
        return False, repr(e)


# ====== ПАНЕЛЬ ======

def get_panel_token() -> Optional[str]:
    """Активный токен панели. БД → config.PANEL_BOT_TOKEN → config.BOT_ZAYAVOK_TOKEN."""
    v = _get_db_value(PANEL_TOKEN_DB_KEY)
    if v:
        return v
    try:
        import config as cfg
        return getattr(cfg, "PANEL_BOT_TOKEN", None) or getattr(cfg, "BOT_ZAYAVOK_TOKEN", None)
    except Exception:
        return None


def set_panel_token(new_token: str) -> tuple[bool, str]:
    return _set_db_value(PANEL_TOKEN_DB_KEY, new_token)


def reset_panel_token() -> tuple[bool, str]:
    """Удаляет переопределение из БД - fallback вернётся на config.PANEL_BOT_TOKEN."""
    return _delete_db_value(PANEL_TOKEN_DB_KEY)


# ====== ГАРАНТ ======

def get_garant_token() -> Optional[str]:
    """Активный токен гарант-бота. БД → config.GARANT_BOT_TOKEN → config.GARANT_SERVIS_BOT_TOKEN."""
    v = _get_db_value(GARANT_TOKEN_DB_KEY)
    if v:
        return v
    try:
        import config as cfg
        return getattr(cfg, "GARANT_BOT_TOKEN", None) or getattr(cfg, "GARANT_SERVIS_BOT_TOKEN", None)
    except Exception:
        return None


def set_garant_token(new_token: str) -> tuple[bool, str]:
    return _set_db_value(GARANT_TOKEN_DB_KEY, new_token)


def reset_garant_token() -> tuple[bool, str]:
    """Удаляет переопределение из БД - fallback вернётся на config.GARANT_BOT_TOKEN."""
    return _delete_db_value(GARANT_TOKEN_DB_KEY)

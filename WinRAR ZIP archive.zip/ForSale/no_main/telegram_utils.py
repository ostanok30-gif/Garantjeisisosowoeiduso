# -*- coding: utf-8 -*-
"""
Общие утилиты для работы с Telegram Bot API.
Отправка сообщений и фото - используются парсером подарков и при необходимости ботами.
"""
import json
import logging
import os
import ssl
import urllib.parse
import urllib.request
import urllib.error
from typing import Optional, Union

logger = logging.getLogger(__name__)


def _urlopen_with_ssl_fallback(req: urllib.request.Request, timeout: int):
    """
    Пытается открыть HTTPS-запрос с системной валидацией сертификата.
    Если в окружении self-signed цепочка (часто на прокси/антивирусе),
    делает повтор с unverified SSL context.
    """
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.URLError as e:
        reason = getattr(e, "reason", None)
        if isinstance(reason, ssl.SSLCertVerificationError):
            logger.warning(
                "SSL verify failed для Telegram API, повтор без проверки сертификата: %s",
                reason,
            )
            insecure_ctx = ssl._create_unverified_context()
            return urllib.request.urlopen(req, timeout=timeout, context=insecure_ctx)
        raise


def send_telegram_message(
    bot_token: str,
    chat_id: Union[int, str],
    text: str,
    parse_mode: str = "HTML",
    timeout: int = 10,
) -> bool:
    """
    Отправляет сообщение через Telegram Bot API.
    Returns:
        True при успехе, False при ошибке.
    """
    if not bot_token or not str(chat_id):
        return False
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    data = urllib.parse.urlencode({
        "chat_id": chat_id,
        "text": text,
        "parse_mode": parse_mode,
    }).encode()
    try:
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        with _urlopen_with_ssl_fallback(req, timeout=timeout) as resp:
            return resp.status == 200
    except Exception as e:
        logger.warning("Не удалось отправить сообщение: %s", e)
        return False


def send_telegram_photo(
    bot_token: str,
    chat_id: Union[int, str],
    photo_path: str,
    caption: str,
    reply_markup: Optional[dict] = None,
    parse_mode: str = "HTML",
    timeout: int = 15,
) -> bool:
    """
    Отправляет фото с подписью через Telegram Bot API.
    Returns:
        True при успехе, False при ошибке.
    """
    if not bot_token or not str(chat_id) or not photo_path or not os.path.isfile(photo_path):
        return False
    url = f"https://api.telegram.org/bot{bot_token}/sendPhoto"
    boundary = "----FormBoundary" + str(id(photo_path))
    body_parts = []
    body_parts.append(f"--{boundary}\r\n".encode())
    body_parts.append(f'Content-Disposition: form-data; name="chat_id"\r\n\r\n{chat_id}\r\n'.encode())
    body_parts.append(f"--{boundary}\r\n".encode())
    body_parts.append(
        b'Content-Disposition: form-data; name="photo"; filename="banner.png"\r\nContent-Type: image/png\r\n\r\n'
    )
    with open(photo_path, "rb") as f:
        body_parts.append(f.read())
    body_parts.append(f"\r\n--{boundary}\r\n".encode())
    body_parts.append(f'Content-Disposition: form-data; name="caption"\r\n\r\n{caption}\r\n'.encode("utf-8"))
    body_parts.append(f"--{boundary}\r\n".encode())
    body_parts.append(f'Content-Disposition: form-data; name="parse_mode"\r\n\r\n{parse_mode}\r\n'.encode())
    if reply_markup:
        body_parts.append(f"--{boundary}\r\n".encode())
        body_parts.append(
            f'Content-Disposition: form-data; name="reply_markup"\r\n\r\n{json.dumps(reply_markup)}\r\n'.encode()
        )
    body_parts.append(f"--{boundary}--\r\n".encode())
    body = b"".join(body_parts)
    try:
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
        with _urlopen_with_ssl_fallback(req, timeout=timeout) as resp:
            return resp.status == 200
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", errors="replace")
            err_data = json.loads(body) if body.strip() else {}
            desc = err_data.get("description", body)
            logger.warning("Не удалось отправить фото: HTTP %s - %s", e.code, desc)
        except Exception:
            logger.warning("Не удалось отправить фото: %s", e)
        return False
    except Exception as e:
        logger.warning("Не удалось отправить фото: %s", e)
        return False


def _bot_api_call(bot_token: str, method: str, params: dict, timeout: int = 10) -> tuple[bool, str]:
    """Унифицированный вызов Bot API. Возвращает (ok, description_or_error)."""
    if not bot_token:
        return False, "no token"
    url = f"https://api.telegram.org/bot{bot_token}/{method}"
    try:
        data = urllib.parse.urlencode(params).encode()
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        with _urlopen_with_ssl_fallback(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8", errors="replace")
        try:
            j = json.loads(body)
        except Exception:
            return False, body[:200]
        if j.get("ok"):
            return True, json.dumps(j.get("result"))[:200] if j.get("result") else "ok"
        return False, str(j.get("description") or "unknown error")
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", errors="replace")
            j = json.loads(body) if body.strip() else {}
            return False, str(j.get("description") or body[:200])
        except Exception:
            return False, f"HTTP {e.code}"
    except Exception as e:
        return False, repr(e)


def set_bot_name(bot_token: str, name: str, language_code: str = "") -> tuple[bool, str]:
    """setMyName: меняет имя бота (то что под аватаркой / в шапке профиля). Длина до 64 символов."""
    p = {"name": name}
    if language_code:
        p["language_code"] = language_code
    return _bot_api_call(bot_token, "setMyName", p)


def set_bot_description(bot_token: str, description: str, language_code: str = "") -> tuple[bool, str]:
    """setMyDescription: расширенное описание (отображается в пустом чате с ботом и в шапке профиля). До 512 символов."""
    p = {"description": description}
    if language_code:
        p["language_code"] = language_code
    return _bot_api_call(bot_token, "setMyDescription", p)


def set_bot_short_description(bot_token: str, short_description: str, language_code: str = "") -> tuple[bool, str]:
    """setMyShortDescription: краткое описание (под аватаркой при поиске и в превью). До 120 символов."""
    p = {"short_description": short_description}
    if language_code:
        p["language_code"] = language_code
    return _bot_api_call(bot_token, "setMyShortDescription", p)


def get_bot_name(bot_token: str, language_code: str = "") -> tuple[bool, str]:
    p = {}
    if language_code:
        p["language_code"] = language_code
    ok, info = _bot_api_call(bot_token, "getMyName", p)
    if ok:
        try:
            j = json.loads(info)
            return True, j.get("name", "") if isinstance(j, dict) else ""
        except Exception:
            return True, info
    return False, info


def get_bot_description(bot_token: str, language_code: str = "") -> tuple[bool, str]:
    p = {}
    if language_code:
        p["language_code"] = language_code
    ok, info = _bot_api_call(bot_token, "getMyDescription", p)
    if ok:
        try:
            j = json.loads(info)
            return True, j.get("description", "") if isinstance(j, dict) else ""
        except Exception:
            return True, info
    return False, info


def get_bot_short_description(bot_token: str, language_code: str = "") -> tuple[bool, str]:
    p = {}
    if language_code:
        p["language_code"] = language_code
    ok, info = _bot_api_call(bot_token, "getMyShortDescription", p)
    if ok:
        try:
            j = json.loads(info)
            return True, j.get("short_description", "") if isinstance(j, dict) else ""
        except Exception:
            return True, info
    return False, info


def send_telegram_video(
    bot_token: str,
    chat_id: Union[int, str],
    video_path: str,
    caption: str,
    reply_markup: Optional[dict] = None,
    parse_mode: str = "HTML",
    timeout: int = 60,
) -> bool:
    """Отправляет видео с подписью через Telegram Bot API. True при успехе."""
    if not bot_token or not str(chat_id) or not video_path or not os.path.isfile(video_path):
        return False
    url = f"https://api.telegram.org/bot{bot_token}/sendVideo"
    boundary = "----FormBoundary" + str(id(video_path))
    body_parts = []
    body_parts.append(f"--{boundary}\r\n".encode())
    body_parts.append(f'Content-Disposition: form-data; name="chat_id"\r\n\r\n{chat_id}\r\n'.encode())
    body_parts.append(f"--{boundary}\r\n".encode())
    fname = os.path.basename(video_path) or "video.mp4"
    body_parts.append(
        f'Content-Disposition: form-data; name="video"; filename="{fname}"\r\nContent-Type: video/mp4\r\n\r\n'.encode()
    )
    with open(video_path, "rb") as f:
        body_parts.append(f.read())
    body_parts.append(f"\r\n--{boundary}\r\n".encode())
    body_parts.append(f'Content-Disposition: form-data; name="caption"\r\n\r\n{caption}\r\n'.encode("utf-8"))
    body_parts.append(f"--{boundary}\r\n".encode())
    body_parts.append(f'Content-Disposition: form-data; name="parse_mode"\r\n\r\n{parse_mode}\r\n'.encode())
    if reply_markup:
        body_parts.append(f"--{boundary}\r\n".encode())
        body_parts.append(
            f'Content-Disposition: form-data; name="reply_markup"\r\n\r\n{json.dumps(reply_markup)}\r\n'.encode()
        )
    body_parts.append(f"--{boundary}--\r\n".encode())
    body = b"".join(body_parts)
    try:
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
        with _urlopen_with_ssl_fallback(req, timeout=timeout) as resp:
            return resp.status == 200
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", errors="replace")
            err_data = json.loads(body) if body.strip() else {}
            desc = err_data.get("description", body)
            logger.warning("Не удалось отправить видео: HTTP %s - %s", e.code, desc)
        except Exception:
            logger.warning("Не удалось отправить видео: %s", e)
        return False
    except Exception as e:
        logger.warning("Не удалось отправить видео: %s", e)
        return False

# -*- coding: utf-8 -*-
"""
Курсы TON и USDT в USD. Кэш в памяти на PRICE_CACHE_TTL_SEC секунд.
Источник: CoinGecko API (бесплатный, без ключа).
"""
from __future__ import annotations

import time as _time
import urllib.request
import urllib.parse
import json as _json
import logging

import config


log = logging.getLogger(__name__)

_cache = {"ts": 0.0, "ton_usd": 0.0, "usdt_usd": 1.0}


def _fetch():
    url = ("https://api.coingecko.com/api/v3/simple/price?"
           "ids=the-open-network,tether&vs_currencies=usd")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "ForSale/1.0"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = _json.loads(resp.read().decode("utf-8"))
        ton = float((data.get("the-open-network") or {}).get("usd") or 0.0)
        usdt = float((data.get("tether") or {}).get("usd") or 1.0)
        if ton > 0:
            _cache["ton_usd"] = ton
            _cache["usdt_usd"] = usdt
            _cache["ts"] = _time.time()
    except Exception as e:
        log.debug("[price] fetch failed: %s", e)


def _refresh_if_stale():
    ttl = int(getattr(config, "PRICE_CACHE_TTL_SEC", 300))
    if _time.time() - _cache["ts"] > ttl:
        _fetch()


def ton_usd() -> float:
    _refresh_if_stale()
    return float(_cache.get("ton_usd") or 0.0)


def usdt_usd() -> float:
    _refresh_if_stale()
    return float(_cache.get("usdt_usd") or 1.0)


def to_usd(amount: float, currency: str) -> float:
    """Перевести amount {currency} в USD по текущему курсу. 0 если курс недоступен."""
    cur = (currency or "").upper()
    if cur == "TON":
        rate = ton_usd()
    elif cur == "USDT":
        rate = usdt_usd()
    else:
        rate = 0.0
    return float(amount or 0) * rate


def fmt_usd(amount: float, currency: str) -> str:
    """Возвращает строку '≈ $12.50' или '' если курс недоступен."""
    usd = to_usd(amount, currency)
    if usd <= 0:
        return ""
    return f"≈ ${usd:,.2f}".replace(",", " ")

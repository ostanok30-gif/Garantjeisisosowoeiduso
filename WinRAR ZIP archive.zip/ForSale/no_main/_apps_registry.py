# -*- coding: utf-8 -*-
"""Реестр приложений ботов для корректной остановки по Ctrl+C из main.py."""
import threading

# name -> {'app', 'loop', 'stop_scheduled': bool, 'reload_event': asyncio.Event}
_apps = {}

# Глобальный флаг остановки. Ставится signal_handler-ом в main.py при Ctrl+C/SIGTERM.
# Цикл hot-reload в applications_bot.main() проверяет его и завершает работу, не пересоздавая Application.
shutdown_flag = threading.Event()

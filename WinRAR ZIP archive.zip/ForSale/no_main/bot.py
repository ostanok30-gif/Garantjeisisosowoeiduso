import sqlite3
import re
import math
import asyncio
import contextlib
import threading
import time
from typing import Optional

# Module-level lock for cross-thread balance_currencies mutations.
# TonDepositMonitor (daemon thread) credits balances while asyncio main loop
# debits via create_withdrawal — without this lock read-modify-write races
# corrupt the dict (Python's GIL doesn't make x = x + y atomic across threads).
_BALANCE_LOCK = threading.Lock()

# Per-user locks for create_withdrawal: stops user double-click from creating
# two withdrawal rows + double-debit. setdefault keeps the lock instance stable
# across calls (same user always gets the same Lock object). Different users
# never contend with each other.
_WD_USER_LOCKS: "dict[int, threading.Lock]" = {}

# Per-deal asyncio locks for dispute open serialization (race fix).
_DISPUTE_LOCKS: "dict[str, asyncio.Lock]" = {}

# Per-deal asyncio locks for status-transition critical sections (cancel /
# seller_confirm_sent / buyer_confirm_received / deal-join). Without this two
# concurrent handlers can both read status='seller_sent' and both proceed,
# causing double payouts (P5.2/P5.6) or two buyers claiming an unclaimed deal
# (P5.50). Pattern mirrors _DISPUTE_LOCKS: setdefault keeps lock instance
# stable across calls; pop() inside finally is just memory cleanup — concurrent
# waiters already hold a reference to the same Lock object.
_DEAL_TX_LOCKS: "dict[str, asyncio.Lock]" = {}
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputMediaAnimation, InputMediaPhoto
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler, ContextTypes
from telegram.request import HTTPXRequest
from telegram.error import NetworkError, BadRequest, Conflict, Forbidden
import uuid
import json
import logging
from logging.handlers import RotatingFileHandler
import html as html_module
import os
from datetime import datetime
from .messages import get_text
from config import (
    PROJECT_DIR,
    PUT_K_BD_GARANT,
    VALUTE_GARANT,
    PROXY_URL,
    REQUEST_CONNECT_TIMEOUT,
    REQUEST_READ_TIMEOUT,
    BOT_POLL_TIMEOUT,
    BOT_LOG_FILE,
)
# P5.26: cap deal description length at write-time. Imported lazily-tolerant — if
# config doesn't define it (older deployment), default to 500.
try:
    from config import MAX_DESCRIPTION_LEN
except ImportError:
    MAX_DESCRIPTION_LEN = 500
from .dynamic_settings import (
    get_garant_notify_chat_id,
    get_garant_ton_address,
    get_garant_sbp_card,
    get_garant_commission_percent,
    get_garant_support_username,
)
from .panel_token import get_garant_token


# P5.8: deals.created_at is TEXT — old rows used "%d.%m.%Y %H:%M" which doesn't sort
# lexically across day/month/year boundaries. New rows use ISO "%Y-%m-%d %H:%M" which
# IS lexically sortable. This helper parses both formats so existing rows keep working.
def _parse_deal_created_at(created_str):
    """Parse deals.created_at to a datetime. Tries ISO first, falls back to old DD.MM.YYYY.
    Returns None on failure."""
    if not created_str:
        return None
    for fmt in ("%Y-%m-%d %H:%M", "%d.%m.%Y %H:%M"):
        try:
            return datetime.strptime(created_str, fmt)
        except (ValueError, TypeError):
            continue
    return None


# Валидация TON-адреса: 48 символов, начинается с EQ или UQ, base64url
def is_valid_ton_address(s):
    if not s or len(s) != 48:
        return False
    return bool(re.match(r'^[EU]Q[A-Za-z0-9_-]{46}$', s.strip()))

# Валидация карты / СБП-телефона: "Банк - Номер", "Банк Номер"; номер - карта или телефон (с + или без, с пробелами).
# Примеры: Сбербанк - +7977351242 | Сбербанк +3165164161 | Сбербанк 7977351242
_PHONE_OR_CARD_TAIL_RE = re.compile(
    r'(?P<num>\+?\s*[\d\s\-]+)\s*$',
    re.UNICODE,
)


def is_valid_card(s):
    if not s or len(s.strip()) < 6:
        return False
    s = s.strip()
    if '|' in s:
        s = s.split('|', 1)[1].strip()
    # Вариант 1: "Банк - Номер" / "Банк-Номер" (номер: +7…, карта, телефон с пробелами)
    parts = re.split(r'\s*[--]\s*', s, 1)
    if len(parts) == 2:
        bank, number = parts[0].strip(), parts[1].strip()
        if not bank or not number:
            return False
        if not re.search(r'[a-zA-Zа-яА-ЯёЁ]', bank):
            return False
        digits = re.sub(r'\D', '', number)
        return 8 <= len(digits) <= 19

    # Вариант 2: "Банк Номер" - номер в конце: опционально +, затем цифры с пробелами/дефисами (не обрываем на + внутри номера)
    m = _PHONE_OR_CARD_TAIL_RE.search(s)
    if not m:
        return False
    number = m.group('num').strip()
    bank = s[: m.start()].strip()
    if not bank or not re.search(r'[a-zA-Zа-яА-ЯёЁ]', bank):
        return False
    digits = re.sub(r'\D', '', number)
    return 8 <= len(digits) <= 19


def _card_currency_and_details(card_str):
    """Возвращает (currency, details). Карта может быть в формате CURRENCY|Банк - Номер или просто Банк - Номер (RUB)."""
    if not card_str or '|' not in card_str:
        return ('RUB', (card_str or '').strip())
    pre, rest = card_str.strip().split('|', 1)
    return (pre.strip().upper() or 'RUB', rest.strip())


def _get_card_for_currency(cards, currency):
    """Возвращает первую карту с указанной валютой. currency 'RUB' или 'sbp' совпадает с картами без префикса или RUB."""
    want = 'RUB' if currency == 'sbp' else (currency or 'RUB').upper()
    for c in (cards or []):
        cur, _ = _card_currency_and_details(c)
        if cur == want:
            return c
    return None


def _valute_display(payment_method, lang):
    """Строка валюты для отображения: TON, USDT, RUB, UAH, USD, звёзды и т.д."""
    if payment_method == 'ton':
        return 'TON'
    if payment_method == 'usdt':
        return 'USDT'
    if payment_method == 'sbp':
        return 'RUB'
    if payment_method == 'stars':
        return get_text(lang, 'valute_stars')
    return (payment_method or 'RUB').upper()


# Латинские алиасы (после сжатия пробелов/дефисов) → ключ в balance_currencies
_BALANCE_LATIN_COMPACT_TO_KEY = {
    'rub': 'RUB',
    'ruble': 'RUB',
    'rouble': 'RUB',
    'uah': 'UAH',
    'hryvnia': 'UAH',
    'usd': 'USD',
    'dollar': 'USD',
    'eur': 'EUR',
    'euro': 'EUR',
    'kzt': 'KZT',
    'tenge': 'KZT',
    'byn': 'BYN',
    'uzs': 'UZS',
    'cny': 'CNY',
    'yuan': 'CNY',
    'rmb': 'CNY',
    'ton': 'TON',
    'toncoin': 'TON',
    'usdt': 'USDT',
    'som': 'UZS',
}

# Кириллица в payment_method (как в БД/ручном вводе) → ключ
_BALANCE_CYR_SUBSTRINGS = (
    ('грн', 'UAH'),
    ('руб', 'RUB'),
    ('тенге', 'KZT'),
    ('юань', 'CNY'),
    ('доллар', 'USD'),
    ('евро', 'EUR'),
)


def _balance_key_from_payment_method(payment_method) -> str:
    """Ключ валюты для balance_currencies (как в BALANCE_CURRENCIES). Stars - отдельно (balance_stars)."""
    if payment_method is None:
        logger.warning(
            "_balance_key_from_payment_method: payment_method=None → RUB; в сделке нет валюты в БД - начисление неверное"
        )
        return 'RUB'
    s = str(payment_method).strip()
    if not s:
        logger.warning("_balance_key_from_payment_method: пустая строка → RUB")
        return 'RUB'
    pm = s.lower()
    pm_compact = re.sub(r'[\s_\-.]+', '', pm)

    if pm == 'sbp':
        return 'RUB'

    # USDT раньше TON: в строке «usdt» есть подстрока «ton»
    if pm == 'usdt' or 'usdt' in pm_compact:
        return 'USDT'
    if pm == 'ton' or pm_compact in ('ton', 'toncoin'):
        return 'TON'

    if pm_compact in _BALANCE_LATIN_COMPACT_TO_KEY:
        return _BALANCE_LATIN_COMPACT_TO_KEY[pm_compact]

    for sub, key in _BALANCE_CYR_SUBSTRINGS:
        if sub in pm:
            return key

    u = s.upper().strip()
    if u in BALANCE_CURRENCIES and u != 'Stars':
        return u

    logger.warning(
        "_balance_key_from_payment_method: нераспознано %r → RUB (проверьте payment_method в сделке)",
        payment_method,
    )
    return 'RUB'


def _canonical_deal_payment_method(payment_method) -> str:
    """Нормализация для сохранения в deals: usdt/ton/stars/sbp или код фиата (UAH, USD, …)."""
    if payment_method is None:
        return 'ton'
    s = str(payment_method).strip()
    if not s:
        return 'ton'
    pm0 = s.lower()
    pm0c = re.sub(r'[\s_\-.]+', '', pm0)
    if pm0 == 'stars' or pm0c == 'stars':
        return 'stars'
    key = _balance_key_from_payment_method(s)
    if key == 'RUB':
        return 'sbp'
    if key == 'USDT':
        return 'usdt'
    if key == 'TON':
        return 'ton'
    if key == 'UAH':
        return 'UAH'
    if key == 'USD':
        return 'USD'
    if key == 'EUR':
        return 'EUR'
    if key == 'KZT':
        return 'KZT'
    if key == 'BYN':
        return 'BYN'
    if key == 'UZS':
        return 'UZS'
    if key == 'CNY':
        return 'CNY'
    return s if len(s) <= 12 else s[:12]


def _credit_user_balance_by_deal(user_id: int, amount: float, payment_method):
    """Начисление на баланс в валюте сделки (не всё в RUB).

    RMW (read-modify-write) защищён `_BALANCE_LOCK` — иначе ~20 callers
    (admin_panel cancel-deal, _do_close_deal, авто-возврат и т.д.) могут
    одновременно читать-добавить-писать одну ячейку и потерять deltas.
    Лок берётся внутри хелпера, чтобы все callers получили защиту в одной точке.
    """
    if not user_id or amount is None or float(amount) <= 0:
        return
    ensure_user_exists(user_id)
    with _BALANCE_LOCK:
        if _is_stars_deal({'payment_method': payment_method}):
            user_data[user_id]['balance_stars'] = float(user_data[user_id].get('balance_stars', 0) or 0) + float(amount)
        else:
            key = _balance_key_from_payment_method(payment_method)
            bc = user_data[user_id].setdefault('balance_currencies', {})
            # Миграция/совместимость: старые пользователи могли хранить RUB только в `balance` (без balance_currencies_json).
            # Если в balance_currencies RUB пусто, подтягиваем legacy-значение.
            if key == 'RUB':
                legacy_rub = float(user_data[user_id].get('balance', 0) or 0)
                if float(bc.get('RUB', 0) or 0) == 0 and legacy_rub != 0:
                    bc['RUB'] = legacy_rub
            bc[key] = float(bc.get(key, 0) or 0) + float(amount)
            if key == 'RUB':
                user_data[user_id]['balance'] = float(bc.get('RUB', 0) or 0)


def _debit_user_balance_by_deal(user_id: int, amount: float, payment_method) -> bool:
    """Списание с баланса в валюте сделки. True если хватило средств.

    RMW (включая check-and-debit) защищён `_BALANCE_LOCK` — иначе два
    параллельных списания на одного юзера могут оба пройти проверку
    `cur >= amt` до того, как первый запишет результат, и в итоге уйти
    в минус.
    """
    if not user_id or amount is None:
        return False
    ensure_user_exists(user_id)
    amt = float(amount)
    with _BALANCE_LOCK:
        if _is_stars_deal({'payment_method': payment_method}):
            cur = float(user_data[user_id].get('balance_stars', 0) or 0)
            if cur < amt:
                return False
            user_data[user_id]['balance_stars'] = cur - amt
            return True
        key = _balance_key_from_payment_method(payment_method)
        bc = user_data[user_id].setdefault('balance_currencies', {})
        # Миграция/совместимость: если RUB хранится только в `balance`, подтягиваем в balance_currencies.
        if key == 'RUB':
            legacy_rub = float(user_data[user_id].get('balance', 0) or 0)
            if float(bc.get('RUB', 0) or 0) == 0 and legacy_rub != 0:
                bc['RUB'] = legacy_rub
        cur = float(bc.get(key, 0) or 0)
        if cur < amt:
            return False
        bc[key] = cur - amt
        if key == 'RUB':
            user_data[user_id]['balance'] = float(bc.get('RUB', 0) or 0)
        return True


def _user_available_balance_for_deal(user_id: int, payment_method) -> float:
    """Сколько доступно в валюте этой сделки."""
    ensure_user_exists(user_id)
    if _is_stars_deal({'payment_method': payment_method}):
        return float(user_data[user_id].get('balance_stars', 0) or 0)
    key = _balance_key_from_payment_method(payment_method)
    bc = user_data[user_id].get('balance_currencies') or {}
    if key == 'RUB':
        # Для старых пользователей RUB мог быть только в `balance`.
        legacy_rub = float(user_data[user_id].get('balance', 0) or 0)
        if float(bc.get('RUB', 0) or 0) == 0 and legacy_rub != 0:
            bc = dict(bc)
            bc['RUB'] = legacy_rub
    return float(bc.get(key, 0) or 0)


def _is_stars_deal(deal):
    """Сделка в звёздах (учёт любого регистра payment_method)."""
    if not deal:
        return False
    pm = (deal.get('payment_method') or '').strip().lower()
    return pm == 'stars'


# Валидация юзернейма для звёзд: 5-32 символа, латиница/цифры/подчёркивание (формат Telegram)
def _deal_id_short(deal_id):
    """Возвращает краткий ID сделки (8 символов) для отображения пользователю."""
    return (deal_id[:8] if deal_id else '')


def _resolve_deal_id(given_id):
    """Находит deal_id по точному совпадению или по префиксу.

    P10.16 (HIGH) — Deal hijack via prefix matching: для prefix-поиска
    требуем минимум 8 hex-символов (32 бита, ~4 миллиарда комбинаций),
    иначе атакующий мог бы перебирать /start 0 .. /start f и захватывать
    все сделки начинающиеся на каждый hex-символ. Также возвращаем
    результат только если совпадение РОВНО одно (несколько → None,
    чтобы избежать произвольного выбора первого).
    """
    if not given_id:
        return None
    given = str(given_id).strip().lstrip('#').lower()
    # Точное совпадение всегда разрешено
    if given in deals:
        return given
    # Поиск по префиксу: минимум 8 hex-символов для защиты от перебора (P10.16)
    if len(given) < 8:
        return None
    # Поиск: короткий ID → полный (did.startswith(given)). Только если
    # совпадение единственно (несколько → ambiguous → None).
    matches = [did for did in deals if did.startswith(given)]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        return None  # ambiguous
    # Поиск: given = полный UUID, а в deals ключи 8 символов (префикс UUID)
    short = given.split('-')[0] if '-' in given else given[:8]
    if short and short in deals:
        return short
    rev_matches = [did for did in deals if given.startswith(did)]
    if len(rev_matches) == 1:
        return rev_matches[0]
    return None

def _is_user_admin(user_id):
    """P10.17 (MEDIUM) — defence-in-depth guard для admin callback-веток.

    Проверяет, что user_id входит в GARANT_ADMIN_USER_IDS (или legacy
    GARANT_ADMIN_USER_ID). admin_view_deal_/admin_confirm_deal_/
    admin_cancel_deal_ ветки рендерятся только админам, но callback_data
    можно подделать (Telegram не верифицирует, что кнопку нажал тот, кому
    она отправлена) — поэтому добавляем явную проверку. Локальная
    реализация (без import из admin_panel) — избегаем circular import.
    """
    try:
        import config as _cfg
        admins = set(getattr(_cfg, "GARANT_ADMIN_USER_IDS", None) or set())
        legacy = getattr(_cfg, "GARANT_ADMIN_USER_ID", None)
        if legacy:
            try:
                admins.add(int(legacy))
            except (ValueError, TypeError):
                pass
        return int(user_id) in admins
    except Exception:
        return False


def is_valid_stars_username(s):
    if not s:
        return False
    s = str(s).strip().lstrip('@').strip()
    return bool(re.match(r'^[a-zA-Z0-9_]{5,32}$', s))

# Валидация названия реквизита: от 5 букв, только русские или английские буквы (без цифр и символов)
def is_valid_requisite_name(s):
    if not s or not isinstance(s, str):
        return False
    s = s.strip()
    return len(s) >= 5 and bool(re.match(r'^[a-zA-Zа-яА-ЯёЁ]+$', s))

# P8.7: RotatingFileHandler заменяет bare FileHandler — иначе bot.log
# растёт безгранично (на больших развёртываниях это диск-out-of-space за месяц).
# 20 MB × 10 backups = ~200 MB cap.
_rfh_main = RotatingFileHandler(
    BOT_LOG_FILE, maxBytes=20_000_000, backupCount=10, encoding='utf-8'
)
_rfh_main.setFormatter(logging.Formatter(
    fmt='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
))
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=[
        _rfh_main,
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# basicConfig срабатывает только если root logger ещё не настроен.
# main.py ставит свой basicConfig(stream=sys.stdout) ПЕРВЫМ → наш handlers игнорируется.
# Принудительно добавляем FileHandler — иначе все warnings (вкл. "support log fail") теряются.
# P8.7: тот же RotatingFileHandler, что и выше.
try:
    _has_file = any(
        isinstance(h, logging.FileHandler) and getattr(h, 'baseFilename', '') == BOT_LOG_FILE
        for h in logger.handlers + logging.getLogger().handlers
    )
    if not _has_file:
        _fh = RotatingFileHandler(
            BOT_LOG_FILE, maxBytes=20_000_000, backupCount=10, encoding='utf-8'
        )
        _fh.setFormatter(logging.Formatter(
            fmt='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S',
        ))
        _fh.setLevel(logging.INFO)
        logging.getLogger().addHandler(_fh)
        logger.info("=== bot.py logger inited (rotating file handler added) ===")
except Exception:
    pass

BOT_TOKEN = get_garant_token() or ""
VALUTE = VALUTE_GARANT
# get_garant_ton_address(), get_garant_sbp_card() - из config

# ID чата уведомлений о сделках
NOTIFICATION_CHAT_ID = get_garant_notify_chat_id()

user_data = {}
deals = {}
admin_commands = {}

DB_NAME = PUT_K_BD_GARANT


def _db_connect():
    """sqlite3.connect with per-connection pragmas applied. Use everywhere
    instead of bare sqlite3.connect(DB_NAME) to ensure busy_timeout / FK
    semantics are uniform across threads (P5.9). WAL is set globally in
    init_db (it persists in the file header). busy_timeout means SQLite
    waits up to 30s on a locked DB before raising OperationalError.

    P6.3: PRAGMA executes wrapped in try/except — extremely unlikely with
    a healthy DB, but a corrupt sqlite file can raise on PRAGMA, leaking
    the open connection if not closed in the failure path.
    """
    c = sqlite3.connect(DB_NAME)
    try:
        c.execute("PRAGMA busy_timeout=30000")
        c.execute("PRAGMA foreign_keys=ON")
    except Exception:
        c.close()
        raise
    return c


# Баланс: валюты и минимальная сумма вывода
BALANCE_CURRENCIES = ('USDT', 'TON', 'RUB', 'UAH', 'USD', 'EUR', 'KZT', 'BYN', 'UZS', 'CNY', 'Stars')
# Страна/регион для отображения в балансе (страна - валюта - $; сумма в <code> моноширным)
BALANCE_CURRENCY_COUNTRY = {
    'ru': {'USDT': 'Крипто', 'TON': 'Крипто', 'RUB': 'Россия', 'UAH': 'Украина', 'USD': 'США', 'EUR': 'Евро', 'KZT': 'Казахстан', 'BYN': 'Беларусь', 'UZS': 'Узбекистан', 'CNY': 'Китай', 'Stars': 'Telegram Stars'},
    'en': {'USDT': 'Crypto', 'TON': 'Crypto', 'RUB': 'Russia', 'UAH': 'Ukraine', 'USD': 'USA', 'EUR': 'Euro', 'KZT': 'Kazakhstan', 'BYN': 'Belarus', 'UZS': 'Uzbekistan', 'CNY': 'China', 'Stars': 'Telegram Stars'},
}

# Фиат для пополнения баланса воркером (крипта TON/USDT отдельно), порядок - как в меню
WORKER_BALANCE_FIAT = ('Stars', 'RUB', 'USD', 'EUR', 'UAH', 'KZT', 'BYN', 'UZS', 'CNY')
WORKER_BALANCE_CRYPTO = ('TON', 'USDT')


def _credit_worker_balance_currency(user_id: int, amount: float, currency_key: str):
    """Зачисление воркеру на баланс в выбранной валюте (Stars / TON / USDT / фиат из BALANCE_CURRENCIES)."""
    if not user_id or amount is None or float(amount) <= 0:
        return
    cur = (currency_key or '').strip()
    if cur == 'Stars':
        _credit_user_balance_by_deal(user_id, amount, 'stars')
    elif cur == 'TON':
        _credit_user_balance_by_deal(user_id, amount, 'ton')
    elif cur == 'USDT':
        _credit_user_balance_by_deal(user_id, amount, 'usdt')
    elif cur in BALANCE_CURRENCIES:
        _credit_user_balance_by_deal(user_id, amount, cur)
    else:
        logger.warning(f"_credit_worker_balance_currency: unknown currency {cur!r}")


def _set_worker_balance_currency(user_id: int, amount: float, currency_key: str):
    """
    Установка баланса воркеру в выбранной валюте.
    В UX «Пополнить баланс» мы трактуем ввод как целевую величину (set), а не прибавку (add).
    """
    if not user_id or amount is None or float(amount) < 0:
        return
    cur = (currency_key or '').strip()
    ensure_user_exists(user_id)
    amt = float(amount)

    if cur == 'Stars':
        user_data[user_id]['balance_stars'] = amt
        return

    bc = user_data[user_id].setdefault('balance_currencies', {})
    if cur == 'RUB':
        bc['RUB'] = amt
        user_data[user_id]['balance'] = amt
        return

    if cur in BALANCE_CURRENCIES and cur != 'Stars':
        bc[cur] = amt
        return

    if cur == 'TON':
        bc['TON'] = amt
        return

    if cur == 'USDT':
        bc['USDT'] = amt
        return

    logger.warning(f"_set_worker_balance_currency: unknown currency {cur!r}")


def _worker_balance_currency_display(lang, cur: str) -> str:
    lang_key = 'ru' if (lang or 'ru').lower().startswith('ru') else 'en'
    countries = BALANCE_CURRENCY_COUNTRY.get(lang_key, BALANCE_CURRENCY_COUNTRY['en'])
    name = countries.get(cur, cur)
    return f"{name} ({cur})"


def _worker_balance_new_balance_line(user_id: int, cur: str) -> float:
    ensure_user_exists(user_id)
    if cur == 'Stars':
        return float(user_data[user_id].get('balance_stars', 0) or 0)
    bc = _get_balance_currencies(user_id)
    return float(bc.get(cur, 0) or 0)

MIN_WITHDRAWAL_BALANCE = 10_000_000   # минимальная сумма вывода в каждой валюте (нигде не показывать, только сообщение «ниже минимально допустимой»)
MIN_PAYOUT_BALANCE = 10_000_000       # минимум для выбора кошелька после сделки

# Аватарка и гифки: из корня проекта (assets/, GIF/) - не из no_main/
AVATAR_PATH = os.path.join(PROJECT_DIR, 'assets', 'gift_guarant_bot_avatar.png')
AVATAR_URL_FALLBACK = "https://postimg.cc/ZWskj31P"
GIF_DIR = os.path.join(PROJECT_DIR, 'GIF')
ASSETS_DIR = os.path.join(PROJECT_DIR, 'assets')
# Баннер для приветствия и смены языка (FUNPAY-API / FunPay OTC Bot)
WELCOME_FUNPAY_BANNER_PATH = os.path.join(ASSETS_DIR, 'welcome_funpay_banner.png')

# Маппинг разделов бота на файлы из папки GIF (наши названия -> исходные имена)
SECTION_GIF_FILES = {
    'welcome': 'Главное меню.mp4',
    'wallet': 'wallet_ru.mp4',
    'create_deal': 'Создание сделки.mp4',
    'my_deals': 'Список сделок.mp4',
    'settings': 'Главное меню.mp4',
    'deal_created': 'Создана сделка.mp4',
    'buyer_joined': 'Пользователь присоединился к сделке.mp4',
    'payment_confirmed': 'Оплата получена.mp4',
    'change_lang': 'Выбор языка.mp4',
}

def get_avatar_photo():
    """Возвращает фото для send_photo: локальный файл или URL."""
    if os.path.exists(AVATAR_PATH):
        with open(AVATAR_PATH, 'rb') as f:
            return f.read()
    return AVATAR_URL_FALLBACK

def get_welcome_banner_photo():
    """Фото баннера для приветствия и смены языка (если есть)."""
    if os.path.isfile(WELCOME_FUNPAY_BANNER_PATH):
        with open(WELCOME_FUNPAY_BANNER_PATH, 'rb') as f:
            return f.read()
    return None

def get_animation_path(section: str):
    """Возвращает путь к MP4/GIF для раздела: сначала assets/section.mp4, затем GIF/исходное_имя. Для change_lang гифки нет."""
    if section == 'change_lang':
        return None
    our_path = os.path.join(ASSETS_DIR, section + '.mp4')
    if os.path.isfile(our_path):
        return our_path
    fname = SECTION_GIF_FILES.get(section)
    if fname:
        path = os.path.join(GIF_DIR, fname)
        if os.path.isfile(path):
            return path
    return None

async def send_wallet_menu_with_media(context, chat_id, lang, user_id):
    """Отправляет меню реквизитов новым сообщением с гифкой (если есть) и клавиатурой."""
    keyboard = _build_wallet_keyboard(lang, user_id)
    caption = get_text(lang, "wallet_menu_message")
    await _send_wallet_media_or_text(context, chat_id, caption, InlineKeyboardMarkup(keyboard))

async def _send_wallet_media_or_text(context, chat_id, caption, reply_markup):
    """Отправляет сообщение с гифкой раздела wallet (если есть) или просто текст."""
    path = get_animation_path('wallet')
    if path and os.path.isfile(path):
        with open(path, 'rb') as f:
            await context.bot.send_animation(
                chat_id=chat_id,
                animation=f,
                caption=caption,
                parse_mode="HTML",
                reply_markup=reply_markup
            )
    else:
        await context.bot.send_message(
            chat_id=chat_id,
            text=caption,
            parse_mode="HTML",
            reply_markup=reply_markup
        )

async def _chat_username_or_name(context, user_id, fallback="Неизвестно"):
    """Возвращает @username или имя (first_name + last_name), если юзернейма нет.

    R11: free-text имена (first_name/last_name/fallback) могут содержать <,>,&
    и сломать parse_mode=HTML, поэтому escape применяется к ним. Username Telegram
    разрешает только [A-Za-z0-9_], escape не нужен.
    """
    if not user_id:
        return html_module.escape(fallback)
    try:
        chat = await context.bot.get_chat(user_id)
        if getattr(chat, "username", None):
            return chat.username  # safe: alnum+underscore
        name = (getattr(chat, "first_name", "") or "").strip()
        if getattr(chat, "last_name", None):
            name = (name + " " + (chat.last_name or "").strip()).strip()
        name = name or fallback
        return html_module.escape(name)
    except Exception:
        return html_module.escape(fallback)

def get_start_message(lang):
    """Приветственное сообщение с подстановкой комиссии, поддержки и канала отзывов."""
    try:
        import config as _cfg
        reviews_raw = (getattr(_cfg, "GARANT_REVIEWS_CHANNEL", "") or "").strip()
    except Exception:
        reviews_raw = ""
    if not reviews_raw:
        reviews = "—"
    elif reviews_raw.startswith("http"):
        reviews = f'<a href="{reviews_raw}">канал</a>'
    else:
        handle = reviews_raw.lstrip("@")
        reviews = f'<a href="https://t.me/{handle}">@{handle}</a>'
    return get_text(lang, "start_message",
        commission=get_garant_commission_percent(),
        support=get_garant_support_username(),
        reviews=reviews,
    )

HOW_DEAL_URL = "https://teletype.in/@otcbotsupporter/R7xRWh40wcu"

# Стили кнопок (Bot API 9.4): primary - синий, success - зелёный, danger - красный
def _btn(text, callback_data=None, url=None, style=None, icon_custom_emoji_id=None):
    kwargs = {}
    if style:
        kwargs["style"] = style
    if icon_custom_emoji_id:
        kwargs["icon_custom_emoji_id"] = str(icon_custom_emoji_id)
    api_kwargs = kwargs if kwargs else None
    if callback_data is not None:
        return InlineKeyboardButton(text, callback_data=callback_data, api_kwargs=api_kwargs)
    return InlineKeyboardButton(text, url=url, api_kwargs=api_kwargs)

def build_main_menu_keyboard(lang, user_id):
    """Главное меню: как на фото 6 - два столбца сверху, два в ряд снизу. У воркеров - кнопка «Команды»."""
    keyboard = [
        [_btn(get_text(lang, "main_create_deal_button"), callback_data='create_deal')],
        [_btn(get_text(lang, "main_wallet_button"), callback_data='wallet_menu')],
        [
            _btn(get_text(lang, "my_profile_button"), callback_data='my_profile'),
            _btn(get_text(lang, "settings_button"), callback_data='settings'),
        ],
    ]
    if is_worker(user_id):
        keyboard.append([_btn(get_text(lang, "worker_commands_button"), callback_data='worker_commands')])
    return InlineKeyboardMarkup(keyboard)

def init_db():
    conn = _db_connect()
    cursor = conn.cursor()
    # P5.9: WAL persists in the file header (set once is enough), but we
    # set it here on every startup to be safe. busy_timeout/foreign_keys
    # are already applied by _db_connect().
    cursor.execute("PRAGMA journal_mode=WAL")

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            ton_wallet TEXT,
            card_details TEXT,
            balance REAL,
            successful_deals INTEGER,
            lang TEXT,
            granted_by INTEGER,
            is_admin INTEGER DEFAULT 0
        )
    ''')

    cursor.execute("PRAGMA table_info(users)")
    columns = [column[1] for column in cursor.fetchall()]
    if 'ton_wallet' not in columns:
        cursor.execute('ALTER TABLE users ADD COLUMN ton_wallet TEXT')
    if 'card_details' not in columns:
        cursor.execute('ALTER TABLE users ADD COLUMN card_details TEXT')
    if 'lang' not in columns:
        cursor.execute('ALTER TABLE users ADD COLUMN lang TEXT DEFAULT "ru"')
    if 'granted_by' not in columns:
        cursor.execute('ALTER TABLE users ADD COLUMN granted_by INTEGER')
    if 'is_admin' not in columns:
        cursor.execute('ALTER TABLE users ADD COLUMN is_admin INTEGER DEFAULT 0')
    if 'ton_wallets_json' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN ton_wallets_json TEXT DEFAULT '[]'")
    if 'cards_json' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN cards_json TEXT DEFAULT '[]'")
    if 'stars_usernames_json' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN stars_usernames_json TEXT DEFAULT '[]'")
    if 'ton_wallet_names_json' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN ton_wallet_names_json TEXT DEFAULT '[]'")
    if 'card_names_json' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN card_names_json TEXT DEFAULT '[]'")
    if 'stars_names_json' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN stars_names_json TEXT DEFAULT '[]'")
    if 'total_deals_usd' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN total_deals_usd REAL DEFAULT 0")
    if 'vouches_rating' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN vouches_rating REAL")
    if 'vouches_count' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN vouches_count INTEGER DEFAULT 0")
    if 'balance_stars' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN balance_stars REAL DEFAULT 0")
    if 'balance_currencies_json' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN balance_currencies_json TEXT DEFAULT '{}'")
    if 'likes' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN likes INTEGER DEFAULT 0")
    if 'dislikes' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN dislikes INTEGER DEFAULT 0")
    if 'registered_at' not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN registered_at INTEGER")

    # Депозиты (идемпотентный лог входящих TON/USDT-зачислений)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS deposits (
            tx_hash    TEXT PRIMARY KEY,
            user_id    INTEGER NOT NULL,
            currency   TEXT NOT NULL,
            amount     REAL NOT NULL,
            created_at INTEGER NOT NULL
        )
    ''')

    # Заявки на вывод
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS withdrawals (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id       INTEGER NOT NULL,
            currency      TEXT NOT NULL,
            amount        REAL NOT NULL,
            address       TEXT NOT NULL,
            status        TEXT NOT NULL DEFAULT 'pending',
            created_at    INTEGER NOT NULL,
            processed_at  INTEGER,
            tx_hash       TEXT,
            error         TEXT
        )
    ''')
    cursor.execute("PRAGMA table_info(withdrawals)")
    _wd_cols = [c[1] for c in cursor.fetchall()]
    if 'tx_hash' not in _wd_cols:
        cursor.execute("ALTER TABLE withdrawals ADD COLUMN tx_hash TEXT")
    if 'error' not in _wd_cols:
        cursor.execute("ALTER TABLE withdrawals ADD COLUMN error TEXT")
    if 'broadcast_at' not in _wd_cols:
        cursor.execute("ALTER TABLE withdrawals ADD COLUMN broadcast_at INTEGER")
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS deals (
            deal_id TEXT PRIMARY KEY,
            amount REAL,
            description TEXT,
            seller_id INTEGER,
            buyer_id INTEGER,
            status TEXT,
            payment_method TEXT
        )
    ''')

    cursor.execute("PRAGMA table_info(deals)")
    columns = [column[1] for column in cursor.fetchall()]
    if 'payment_method' not in columns:
        cursor.execute('ALTER TABLE deals ADD COLUMN payment_method TEXT')
    if 'created_at' not in columns:
        cursor.execute('ALTER TABLE deals ADD COLUMN created_at TEXT')
    if 'join_notification_sent' not in columns:
        cursor.execute('ALTER TABLE deals ADD COLUMN join_notification_sent INTEGER DEFAULT 0')
    # P5.41: track whether buyer's balance was actually debited. Stars deals
    # confirmed via admin_confirm_deal_ flip status to 'confirmed' WITHOUT
    # debiting balance; cancelling such a deal previously credited the buyer
    # creating free balance. Only refund on cancel when escrow_collected=1.
    if 'escrow_collected' not in columns:
        cursor.execute('ALTER TABLE deals ADD COLUMN escrow_collected INTEGER DEFAULT 0')
    if 'seller_voted' not in columns:
        cursor.execute("ALTER TABLE deals ADD COLUMN seller_voted INTEGER DEFAULT 0")
    if 'buyer_voted' not in columns:
        cursor.execute("ALTER TABLE deals ADD COLUMN buyer_voted INTEGER DEFAULT 0")

    # P6.8 / P5.26 follow-up: truncate any pre-existing description longer
    # than MAX_DESCRIPTION_LEN. P5.26 caps NEW descriptions at write-time, but
    # legacy rows from before that change can still be over-length and break
    # downstream Telegram MessageTooLong errors. One-time migration; idempotent
    # (no-op once everything is short enough). Wrapped in try/except so init_db
    # never crashes on this best-effort cleanup.
    try:
        cursor.execute(
            f"UPDATE deals SET description = SUBSTR(description, 1, {MAX_DESCRIPTION_LEN}) "
            f"WHERE LENGTH(description) > {MAX_DESCRIPTION_LEN}"
        )
        if cursor.rowcount > 0:
            logger.info(f"Truncated {cursor.rowcount} legacy deal descriptions to {MAX_DESCRIPTION_LEN} chars")
    except Exception as e:
        logger.warning(f"description truncation migration: {e}")

    # P8.31: prune stale empty cancelled deals (cancelled before any buyer joined,
    # older than 30 days). Без этого таблица deals пухнет от auto-cancelled
    # просроченных пустых сделок (DEAL_TIMEOUT_MIN=1440, никто не присоединился) —
    # они никогда не понадобятся ни для аналитики, ни для разбора. One-time at
    # startup; idempotent (no-op once everything fresh enough).
    try:
        cursor.execute(
            "DELETE FROM deals WHERE status='cancelled' AND buyer_id IS NULL "
            "AND created_at < datetime('now', '-30 days')"
        )
        if cursor.rowcount > 0:
            logger.info(f"Pruned {cursor.rowcount} stale empty cancelled deals (>30d, no buyer)")
    except Exception as e:
        logger.warning(f"prune migration: {e}")

    # Таблица для настроек бота
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS bot_settings (
            setting_name TEXT PRIMARY KEY,
            setting_value TEXT
        )
    ''')

    # Подгруппа workers - user_id, имеющие право использовать /setdeals и /setmoney
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS workers (
            user_id INTEGER PRIMARY KEY
        )
    ''')

    # worker_gifts: worker_id (покупатель в workers) - подарок от продавца (from_seller_id) по сделке deal_id
    # UNIQUE по gift_link задаётся в gift_parser._init_worker_gifts_table (миграция), не по gift_info
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS worker_gifts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER NOT NULL,
            gift_info TEXT NOT NULL,
            from_seller_id INTEGER NOT NULL,
            deal_id TEXT,
            created_at TEXT
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS gift_parser_state (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')

    # Индексы для ускорения поиска
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_deals_seller_id ON deals(seller_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_worker_gifts_worker_id ON worker_gifts(worker_id)")

    # P5.10: 3-й слой защиты от дубликатных pending выплат.
    # Существующие 30-сек SQL-probe и per-user lock закрывают «двойной клик»
    # на уровне приложения, но не защищают от race-condition при рестарте
    # процесса в момент INSERT. Partial UNIQUE-индекс гарантирует, что
    # одновременно может существовать максимум одна 'pending'-строка на
    # (user_id, currency, amount, address) — sent/error выплаты не блокируют
    # повторные попытки.
    try:
        cursor.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_withdrawals_pending_unique "
            "ON withdrawals(user_id, currency, amount, address) "
            "WHERE status='pending'"
        )
    except sqlite3.OperationalError as e:
        # Если в БД уже лежат дубликатные pending-строки от старого кода —
        # CREATE UNIQUE INDEX упадёт. Логируем и продолжаем (init_db не должен
        # ронять процесс). Админ должен вручную почистить дубликаты.
        logger.warning(f"init_db: idx_withdrawals_pending_unique create failed: {e}")

    conn.commit()
    conn.close()

def load_data():
    global NOTIFICATION_CHAT_ID
    conn = _db_connect()
    cursor = conn.cursor()
    cursor.execute("PRAGMA table_info(users)")
    user_columns = [col[1] for col in cursor.fetchall()]
    has_json_cols = 'ton_wallets_json' in user_columns and 'cards_json' in user_columns and 'stars_usernames_json' in user_columns
    has_names_cols = 'ton_wallet_names_json' in user_columns and 'card_names_json' in user_columns and 'stars_names_json' in user_columns
    has_total_usd = 'total_deals_usd' in user_columns
    has_vouches = 'vouches_rating' in user_columns and 'vouches_count' in user_columns
    has_balance_stars = 'balance_stars' in user_columns
    has_bc_json = 'balance_currencies_json' in user_columns
    has_likes = 'likes' in user_columns and 'dislikes' in user_columns
    base_cols = 'user_id, ton_wallet, card_details, balance, successful_deals, lang, granted_by, is_admin'
    json_cols = ', ton_wallets_json, cards_json, stars_usernames_json'
    names_cols = ', ton_wallet_names_json, card_names_json, stars_names_json' if has_names_cols else ''
    usd_col = ', total_deals_usd' if has_total_usd else ''
    vouches_cols = ', vouches_rating, vouches_count' if has_vouches else ''
    stars_balance_col = ', balance_stars' if has_balance_stars else ''
    bc_col = ', balance_currencies_json' if has_bc_json else ''
    likes_col = ', likes, dislikes' if has_likes else ''
    if has_json_cols:
        sel = f'SELECT {base_cols}{json_cols}{names_cols}{usd_col}{vouches_cols}{stars_balance_col}{bc_col}{likes_col} FROM users'
        cursor.execute(sel)
    else:
        sel = f'SELECT {base_cols}{usd_col}{vouches_cols}{stars_balance_col}{bc_col}{likes_col} FROM users'
        cursor.execute(sel)
    colnames = [c[0] for c in cursor.description]
    for row in cursor.fetchall():
        d = dict(zip(colnames, row))
        user_id = d['user_id']
        ton_wallet = d.get('ton_wallet') or ''
        card_details = d.get('card_details') or ''
        balance = d.get('balance')
        successful_deals = d.get('successful_deals')
        lang = d.get('lang')
        granted_by = d.get('granted_by')
        is_admin = d.get('is_admin')
        total_deals_usd = d.get('total_deals_usd') if has_total_usd else 0
        vouches_rating = d.get('vouches_rating') if has_vouches else None
        vouches_count = d.get('vouches_count') if has_vouches else 0
        if not has_total_usd:
            total_deals_usd = 0
        if not has_vouches:
            vouches_rating = None
            vouches_count = 0
        if has_json_cols:
            ton_wallets = json.loads(d.get('ton_wallets_json') or '[]') if d.get('ton_wallets_json') else ([ton_wallet] if ton_wallet else [])
            cards = json.loads(d.get('cards_json') or '[]') if d.get('cards_json') else ([card_details] if card_details else [])
            stars_usernames = json.loads(d.get('stars_usernames_json') or '[]') if d.get('stars_usernames_json') else []
        else:
            ton_wallets = [ton_wallet] if ton_wallet else []
            cards = [card_details] if card_details else []
            stars_usernames = []
        if not ton_wallets and ton_wallet:
            ton_wallets = [ton_wallet]
        if not cards and card_details:
            cards = [card_details]
        ton_wallet_names = json.loads(d.get('ton_wallet_names_json') or '[]') if has_names_cols else []
        card_names = json.loads(d.get('card_names_json') or '[]') if has_names_cols else []
        stars_names = json.loads(d.get('stars_names_json') or '[]') if has_names_cols else []
        while len(ton_wallet_names) < len(ton_wallets):
            ton_wallet_names.append('')
        while len(card_names) < len(cards):
            card_names.append('')
        while len(stars_names) < len(stars_usernames):
            stars_names.append('')
        balance_stars_val = float(d.get('balance_stars') or 0) if has_balance_stars else 0.0
        likes_val = int(d.get('likes') or 0) if has_likes else 0
        dislikes_val = int(d.get('dislikes') or 0) if has_likes else 0
        balance_currencies = {}
        if has_bc_json:
            try:
                raw_bc = d.get('balance_currencies_json') or '{}'
                balance_currencies = json.loads(raw_bc) if isinstance(raw_bc, str) else {}
            except (json.JSONDecodeError, TypeError):
                balance_currencies = {}
        if not isinstance(balance_currencies, dict):
            balance_currencies = {}
        bal_f = float(balance or 0)
        if not balance_currencies and bal_f:
            balance_currencies = {'RUB': bal_f}
        elif bal_f > float(balance_currencies.get('RUB', 0) or 0) + 1e-9:
            balance_currencies['RUB'] = bal_f
        sync_rub = float(balance_currencies.get('RUB', 0) or 0)
        user_data[user_id] = {
            'ton_wallet': ton_wallets[0] if ton_wallets else '',
            'card_details': cards[0] if cards else '',
            'stars_username': stars_usernames[0] if stars_usernames else '',
            'ton_wallets': ton_wallets,
            'cards': cards,
            'stars_usernames': stars_usernames,
            'ton_wallet_names': ton_wallet_names[:len(ton_wallets)],
            'card_names': card_names[:len(cards)],
            'stars_names': stars_names[:len(stars_usernames)],
            'balance': sync_rub,
            'balance_currencies': balance_currencies,
            'balance_stars': balance_stars_val,
            'successful_deals': successful_deals,
            'total_deals_usd': total_deals_usd if isinstance(total_deals_usd, (int, float)) else 0,
            'vouches_rating': vouches_rating,
            'vouches_count': vouches_count,
            'likes': likes_val,
            'dislikes': dislikes_val,
            'lang': lang or 'ru',
            'granted_by': granted_by,
            'is_admin': is_admin
        }
    # Однократная очистка всех сделок (при первом запуске после обновления)
    cursor.execute('SELECT setting_value FROM bot_settings WHERE setting_name = "deals_cleared_once"')
    cleared_result = cursor.fetchone()
    cleared_now = False
    if cleared_result is None or cleared_result[0] != '1':
        cursor.execute('DELETE FROM deals')
        conn.commit()
        cursor.execute(
            'INSERT OR REPLACE INTO bot_settings (setting_name, setting_value) VALUES ("deals_cleared_once", "1")'
        )
        conn.commit()
        cleared_now = True
        deals.clear()
        logger.info("Все сделки очищены (однократно).")

    if not cleared_now:
        try:
            cursor.execute('SELECT deal_id, amount, description, seller_id, buyer_id, status, payment_method, created_at, join_notification_sent, escrow_collected, seller_voted, buyer_voted FROM deals')
        except sqlite3.OperationalError:
            try:
                cursor.execute('SELECT deal_id, amount, description, seller_id, buyer_id, status, payment_method, created_at, join_notification_sent, escrow_collected FROM deals')
            except sqlite3.OperationalError:
                try:
                    cursor.execute('SELECT deal_id, amount, description, seller_id, buyer_id, status, payment_method, created_at, join_notification_sent FROM deals')
                except sqlite3.OperationalError:
                    cursor.execute('SELECT deal_id, amount, description, seller_id, buyer_id, status, payment_method FROM deals')
        rows = cursor.fetchall()
        for row in rows:
            deal_id, amount, description, seller_id, buyer_id, status, payment_method = row[:7]
            created_at = row[7] if len(row) > 7 else None
            join_sent = row[8] if len(row) > 8 else 0
            escrow_collected = row[9] if len(row) > 9 else 0
            seller_voted = row[10] if len(row) > 10 else 0
            buyer_voted = row[11] if len(row) > 11 else 0
            deals[deal_id] = {
                'amount': amount,
                'description': description,
                'seller_id': seller_id,
                'buyer_id': buyer_id,
                'status': status or 'active',
                'payment_method': payment_method,
                'created_at': created_at,
                'join_notification_sent': join_sent,
                'escrow_collected': bool(escrow_collected),
                'seller_voted': bool(seller_voted),
                'buyer_voted': bool(buyer_voted),
            }

    # Загружаем ID чата для уведомлений.
    # Если уведомления выключены в config (GARANT_CHAT_NOTIFICATIONS=0) - НЕ переопределяем из БД.
    if get_garant_notify_chat_id():
        cursor.execute('SELECT setting_value FROM bot_settings WHERE setting_name = "notification_chat_id"')
        result = cursor.fetchone()
        if result:
            NOTIFICATION_CHAT_ID = int(result[0])
            logger.info(f"Загружен ID чата для уведомлений: {NOTIFICATION_CHAT_ID}")
    else:
        logger.info("Уведомления гаранта отключены в config (notification_chat_id не загружается из БД).")
    conn.close()

def save_user_data(user_id):
    conn = _db_connect()
    cursor = conn.cursor()
    user = user_data.get(user_id, {})
    ton_wallets = user.get('ton_wallets') or []
    cards = user.get('cards') or []
    stars_usernames = user.get('stars_usernames') or []
    ton_wallet_names = user.get('ton_wallet_names') or []
    card_names = user.get('card_names') or []
    stars_names = user.get('stars_names') or []
    while len(ton_wallet_names) < len(ton_wallets):
        ton_wallet_names.append('')
    while len(card_names) < len(cards):
        card_names.append('')
    while len(stars_names) < len(stars_usernames):
        stars_names.append('')
    ton_wallet = ton_wallets[0] if ton_wallets else user.get('ton_wallet', '')
    card_details = cards[0] if cards else user.get('card_details', '')
    bc = dict(user.get('balance_currencies') or {})
    rub_balance = float(bc.get('RUB', 0) or 0)
    user['balance'] = rub_balance
    bc_json = json.dumps(bc)
    cursor.execute("PRAGMA table_info(users)")
    cols = [c[1] for c in cursor.fetchall()]
    has_total_usd = 'total_deals_usd' in cols
    has_vouches = 'vouches_rating' in cols and 'vouches_count' in cols
    has_balance_stars = 'balance_stars' in cols
    has_bc_json = 'balance_currencies_json' in cols
    has_likes = 'likes' in cols and 'dislikes' in cols
    usd_val = user.get('total_deals_usd', 0)
    balance_stars_val = float(user.get('balance_stars', 0) or 0)
    v_rating = user.get('vouches_rating')
    v_count = user.get('vouches_count', 0) or 0
    likes_val = int(user.get('likes', 0) or 0)
    dislikes_val = int(user.get('dislikes', 0) or 0)
    stars_sql = ', balance_stars' if has_balance_stars else ''
    stars_ph = ', ?' if has_balance_stars else ''
    stars_arg = (balance_stars_val,) if has_balance_stars else ()
    bc_sql = ', balance_currencies_json' if has_bc_json else ''
    bc_ph = ', ?' if has_bc_json else ''
    bc_arg = (bc_json,) if has_bc_json else ()
    likes_sql = ', likes, dislikes' if has_likes else ''
    likes_ph = ', ?, ?' if has_likes else ''
    likes_arg = (likes_val, dislikes_val) if has_likes else ()
    if 'ton_wallet_names_json' in cols and 'card_names_json' in cols and 'stars_names_json' in cols:
        if has_total_usd and has_vouches:
            cursor.execute(f'''
                INSERT OR REPLACE INTO users (user_id, ton_wallet, card_details, balance, successful_deals, lang, granted_by, is_admin, ton_wallets_json, cards_json, stars_usernames_json, ton_wallet_names_json, card_names_json, stars_names_json, total_deals_usd, vouches_rating, vouches_count{stars_sql}{bc_sql}{likes_sql})
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?{stars_ph}{bc_ph}{likes_ph})
            ''', (user_id, ton_wallet, card_details, rub_balance,
                  user.get('successful_deals', 0), user.get('lang', 'ru'), user.get('granted_by', None),
                  user.get('is_admin', 0), json.dumps(ton_wallets), json.dumps(cards), json.dumps(stars_usernames),
                  json.dumps(ton_wallet_names[:len(ton_wallets)]), json.dumps(card_names[:len(cards)]), json.dumps(stars_names[:len(stars_usernames)]), usd_val, v_rating, v_count) + stars_arg + bc_arg + likes_arg)
        elif has_total_usd:
            cursor.execute(f'''
                INSERT OR REPLACE INTO users (user_id, ton_wallet, card_details, balance, successful_deals, lang, granted_by, is_admin, ton_wallets_json, cards_json, stars_usernames_json, ton_wallet_names_json, card_names_json, stars_names_json, total_deals_usd{stars_sql}{bc_sql}{likes_sql})
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?{stars_ph}{bc_ph}{likes_ph})
            ''', (user_id, ton_wallet, card_details, rub_balance,
                  user.get('successful_deals', 0), user.get('lang', 'ru'), user.get('granted_by', None),
                  user.get('is_admin', 0), json.dumps(ton_wallets), json.dumps(cards), json.dumps(stars_usernames),
                  json.dumps(ton_wallet_names[:len(ton_wallets)]), json.dumps(card_names[:len(cards)]), json.dumps(stars_names[:len(stars_usernames)]), usd_val) + stars_arg + bc_arg + likes_arg)
        else:
            cursor.execute(f'''
                INSERT OR REPLACE INTO users (user_id, ton_wallet, card_details, balance, successful_deals, lang, granted_by, is_admin, ton_wallets_json, cards_json, stars_usernames_json, ton_wallet_names_json, card_names_json, stars_names_json{stars_sql}{bc_sql}{likes_sql})
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?{stars_ph}{bc_ph}{likes_ph})
            ''', (user_id, ton_wallet, card_details, rub_balance,
                  user.get('successful_deals', 0), user.get('lang', 'ru'), user.get('granted_by', None),
                  user.get('is_admin', 0), json.dumps(ton_wallets), json.dumps(cards), json.dumps(stars_usernames),
                  json.dumps(ton_wallet_names[:len(ton_wallets)]), json.dumps(card_names[:len(cards)]), json.dumps(stars_names[:len(stars_usernames)])) + stars_arg + bc_arg + likes_arg)
    else:
        if has_total_usd and has_vouches:
            cursor.execute(f'''
                INSERT OR REPLACE INTO users (user_id, ton_wallet, card_details, balance, successful_deals, lang, granted_by, is_admin, ton_wallets_json, cards_json, stars_usernames_json, total_deals_usd, vouches_rating, vouches_count{stars_sql}{bc_sql}{likes_sql})
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?{stars_ph}{bc_ph}{likes_ph})
            ''', (user_id, ton_wallet, card_details, rub_balance,
                  user.get('successful_deals', 0), user.get('lang', 'ru'), user.get('granted_by', None),
                  user.get('is_admin', 0), json.dumps(ton_wallets), json.dumps(cards), json.dumps(stars_usernames), usd_val, v_rating, v_count) + stars_arg + bc_arg + likes_arg)
        elif has_total_usd:
            cursor.execute(f'''
                INSERT OR REPLACE INTO users (user_id, ton_wallet, card_details, balance, successful_deals, lang, granted_by, is_admin, ton_wallets_json, cards_json, stars_usernames_json, total_deals_usd{stars_sql}{bc_sql}{likes_sql})
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?{stars_ph}{bc_ph}{likes_ph})
            ''', (user_id, ton_wallet, card_details, rub_balance,
                  user.get('successful_deals', 0), user.get('lang', 'ru'), user.get('granted_by', None),
                  user.get('is_admin', 0), json.dumps(ton_wallets), json.dumps(cards), json.dumps(stars_usernames), usd_val) + stars_arg + bc_arg + likes_arg)
        else:
            cursor.execute(f'''
                INSERT OR REPLACE INTO users (user_id, ton_wallet, card_details, balance, successful_deals, lang, granted_by, is_admin, ton_wallets_json, cards_json, stars_usernames_json{stars_sql}{bc_sql}{likes_sql})
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?{stars_ph}{bc_ph}{likes_ph})
            ''', (user_id, ton_wallet, card_details, rub_balance,
                  user.get('successful_deals', 0), user.get('lang', 'ru'), user.get('granted_by', None),
                  user.get('is_admin', 0), json.dumps(ton_wallets), json.dumps(cards), json.dumps(stars_usernames)) + stars_arg + bc_arg + likes_arg)
    conn.commit()
    conn.close()

def _get_balance_currencies(user_id):
    """Возвращает словарь балансов по валютам. RUB из balance_currencies; Stars = balance_stars."""
    ensure_user_exists(user_id)
    ud = user_data.get(user_id, {})
    bc = dict(ud.get('balance_currencies') or {})
    for c in BALANCE_CURRENCIES:
        if c not in bc:
            bc[c] = 0.0
    if float(bc.get('RUB', 0) or 0) == 0 and (ud.get('balance') or 0):
        bc['RUB'] = float(ud.get('balance', 0) or 0)
    bc['Stars'] = float(ud.get('balance_stars', 0) or 0)
    return bc


def _user_requisites(user_id):
    """Возвращает списки реквизитов с миграцией со старых одиночных полей."""
    ud = user_data.get(user_id, {})
    ton_wallets = ud.get('ton_wallets')
    if ton_wallets is None and ud.get('ton_wallet'):
        ton_wallets = [ud['ton_wallet']]
    ton_wallets = ton_wallets or []
    cards = ud.get('cards')
    if cards is None and ud.get('card_details'):
        cards = [ud['card_details']]
    cards = cards or []
    stars = ud.get('stars_usernames') or []
    if not stars and (ud.get('stars_username') or '').strip():
        stars = [ud.get('stars_username', '').strip()]
    return ton_wallets, cards, stars

def _build_wallet_keyboard(lang, user_id):
    """Строит клавиатуру меню реквизитов (кнопка «Баланс» в разделе «Мой профиль»)."""
    ton_wallets, cards, stars_usernames = _user_requisites(user_id)
    ud = user_data.get(user_id, {})
    ton_wallet_names = (ud.get('ton_wallet_names') or [])[:len(ton_wallets)]
    card_names = (ud.get('card_names') or [])[:len(cards)]
    stars_names = (ud.get('stars_names') or [])[:len(stars_usernames)]
    while len(ton_wallet_names) < len(ton_wallets):
        ton_wallet_names.append('')
    while len(card_names) < len(cards):
        card_names.append('')
    while len(stars_names) < len(stars_usernames):
        stars_names.append('')
    keyboard = []
    for i, w in enumerate(ton_wallets):
        label = (ton_wallet_names[i] or '').strip() or ((w[:8] + '…' + w[-6:]) if len(w) > 18 else w)
        keyboard.append([
            _btn(f"💼 {label}", callback_data=f'view_ton_{i}'),
            _btn(get_text(lang, "delete_requisite_button"), callback_data=f'del_ton_{i}')
        ])
    for i, c in enumerate(cards):
        cur, details = _card_currency_and_details(c)
        short_details = (details[:11] + '…') if len(details) > 14 else details
        label = (card_names[i] or '').strip() or f"{cur} {short_details}"
        keyboard.append([
            _btn(f"💳 {label}", callback_data=f'view_card_{i}'),
            _btn(get_text(lang, "delete_requisite_button"), callback_data=f'del_card_{i}')
        ])
    for i, s in enumerate(stars_usernames):
        name = (stars_names[i] or '').strip()
        label = name if name else ('@' + s if s and not s.startswith('@') else s)
        keyboard.append([
            _btn(f"⭐ {label}", callback_data=f'view_stars_{i}'),
            _btn(get_text(lang, "delete_requisite_button"), callback_data=f'del_stars_{i}')
        ])
    if not ton_wallets:
        keyboard.append([_btn(get_text(lang, "add_ton_row_button"), callback_data='add_ton_wallet')])
    keyboard.append([_btn(get_text(lang, "add_card_row_button"), callback_data='add_card')])
    if not stars_usernames:
        keyboard.append([_btn(get_text(lang, "add_stars_row_button"), callback_data='stars_contact')])
    keyboard.append([_btn(get_text(lang, "back_to_menu_button"), callback_data='menu')])
    return keyboard

def ensure_user_exists(user_id):
    if user_id not in user_data:
        user_data[user_id] = {
            'ton_wallet': '',
            'card_details': '',
            'stars_username': '',
            'ton_wallets': [],
            'cards': [],
            'stars_usernames': [],
            'ton_wallet_names': [],
            'card_names': [],
            'stars_names': [],
            'balance': 0.0,
            'balance_currencies': {},
            'balance_stars': 0.0,
            'successful_deals': 0,
            'total_deals_usd': 0,
            'vouches_rating': None,
            'vouches_count': 0,
            'likes': 0,
            'dislikes': 0,
            'registered_at': int(time.time()),
            'lang': 'ru',
            'granted_by': None,
            'is_admin': 0
        }
        save_user_data(user_id)
    else:
        # Миграция: если списков нет - построить из одиночных полей
        ud = user_data[user_id]
        if 'registered_at' not in ud or not ud.get('registered_at'):
            ud['registered_at'] = int(time.time())
            save_user_data(user_id)
        if 'likes' not in ud:
            ud['likes'] = 0
        if 'dislikes' not in ud:
            ud['dislikes'] = 0
        if 'ton_wallets' not in ud and ud.get('ton_wallet'):
            ud['ton_wallets'] = [ud['ton_wallet']]
        if 'ton_wallets' not in ud:
            ud['ton_wallets'] = []
        if 'cards' not in ud and ud.get('card_details'):
            ud['cards'] = [ud['card_details']]
        if 'cards' not in ud:
            ud['cards'] = []
        if 'stars_usernames' not in ud:
            ud['stars_usernames'] = []
        if 'stars_username' in ud and ud['stars_username'] and ud['stars_username'] not in ud['stars_usernames']:
            ud['stars_usernames'] = [ud['stars_username']] + [x for x in ud['stars_usernames'] if x != ud['stars_username']]
        if 'ton_wallet_names' not in ud:
            ud['ton_wallet_names'] = (ud.get('ton_wallet_names') or []) + [''] * max(0, len(ud.get('ton_wallets', [])) - len(ud.get('ton_wallet_names', [])))
        if 'card_names' not in ud:
            ud['card_names'] = (ud.get('card_names') or []) + [''] * max(0, len(ud.get('cards', [])) - len(ud.get('card_names', [])))
        if 'stars_names' not in ud:
            ud['stars_names'] = (ud.get('stars_names') or []) + [''] * max(0, len(ud.get('stars_usernames', [])) - len(ud.get('stars_names', [])))
        if 'total_deals_usd' not in ud:
            ud['total_deals_usd'] = 0
        if 'vouches_rating' not in ud:
            ud['vouches_rating'] = None
        if 'vouches_count' not in ud:
            ud['vouches_count'] = 0

def _format_total_usd(user_id):
    """Возвращает сумму сделок в долларах (конвертируется автоматически): '0.00$', '1000.00$'."""
    val = user_data.get(user_id, {}).get('total_deals_usd', 0)
    try:
        n = float(val)
    except (TypeError, ValueError):
        n = 0.0
    return f"{n:.2f}$"

def is_worker(user_id):
    """True если user_id - основной воркер ИЛИ его твинк (твинки = полная копия)."""
    conn = _db_connect()
    cursor = conn.cursor()
    cursor.execute('SELECT 1 FROM workers WHERE user_id = ?', (user_id,))
    if cursor.fetchone():
        conn.close()
        return True
    try:
        cursor.execute('SELECT 1 FROM worker_twinks WHERE twink_id = ?', (user_id,))
        found = bool(cursor.fetchone())
    except sqlite3.OperationalError:
        found = False
    conn.close()
    return found


def _resolve_main_worker_id(user_id: int) -> int:
    """Если user_id - твинк, возвращает owner_worker_id (основного). Иначе возвращает user_id."""
    try:
        conn = _db_connect()
        cur = conn.cursor()
        cur.execute("SELECT owner_worker_id FROM worker_twinks WHERE twink_id = ?", (user_id,))
        row = cur.fetchone()
        conn.close()
        if row and row[0] is not None:
            return int(row[0])
    except Exception:
        pass
    return int(user_id)


# ====== Поддержка («Обратиться в поддержку» под алертами гаранта) ======
support_pending = {}  # user_id (отправитель) -> {'deal_id': str, 'recipient_id': int}


def _get_deal_seller_buyer(deal_id: str):
    """Возвращает (seller_id, buyer_id) или (None, None)."""
    try:
        conn = _db_connect()
        cur = conn.cursor()
        cur.execute("SELECT seller_id, buyer_id FROM deals WHERE deal_id = ?", (deal_id,))
        row = cur.fetchone()
        conn.close()
        if row:
            return (int(row[0]) if row[0] is not None else None,
                    int(row[1]) if row[1] is not None else None)
    except Exception:
        pass
    return (None, None)


def support_button(deal_id: str):
    """InlineKeyboardButton «Обратиться в поддержку» - добавляется под алерты после начала сделки."""
    return InlineKeyboardButton("📞 Обратиться в поддержку", callback_data=f"support_open_{deal_id}")


def save_deal(deal_id):
    conn = _db_connect()
    cursor = conn.cursor()
    deal = deals.get(deal_id, {})
    created_at = deal.get('created_at')
    join_sent = 1 if deal.get('join_notification_sent') else 0
    escrow_collected = 1 if deal.get('escrow_collected') else 0
    seller_voted = 1 if deal.get('seller_voted') else 0
    buyer_voted = 1 if deal.get('buyer_voted') else 0
    try:
        cursor.execute(
            '''
            INSERT OR REPLACE INTO deals (deal_id, amount, description, seller_id, buyer_id, status, payment_method, created_at, join_notification_sent, escrow_collected, seller_voted, buyer_voted)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (deal_id, deal.get('amount', 0.0), deal.get('description', ''), deal.get('seller_id', None),
             deal.get('buyer_id', None), deal.get('status', 'active'), deal.get('payment_method', None), created_at, join_sent, escrow_collected, seller_voted, buyer_voted)
        )
    except sqlite3.OperationalError:
        try:
            cursor.execute(
                '''
                INSERT OR REPLACE INTO deals (deal_id, amount, description, seller_id, buyer_id, status, payment_method, created_at, join_notification_sent, escrow_collected)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                (deal_id, deal.get('amount', 0.0), deal.get('description', ''), deal.get('seller_id', None),
                 deal.get('buyer_id', None), deal.get('status', 'active'), deal.get('payment_method', None), created_at, join_sent, escrow_collected)
            )
        except sqlite3.OperationalError:
            try:
                cursor.execute(
                    '''
                    INSERT OR REPLACE INTO deals (deal_id, amount, description, seller_id, buyer_id, status, payment_method, created_at, join_notification_sent)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''',
                    (deal_id, deal.get('amount', 0.0), deal.get('description', ''), deal.get('seller_id', None),
                     deal.get('buyer_id', None), deal.get('status', 'active'), deal.get('payment_method', None), created_at, join_sent)
                )
            except sqlite3.OperationalError:
                cursor.execute(
                    '''
                    INSERT OR REPLACE INTO deals (deal_id, amount, description, seller_id, buyer_id, status, payment_method)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''',
                    (deal_id, deal.get('amount', 0.0), deal.get('description', ''), deal.get('seller_id', None),
                     deal.get('buyer_id', None), deal.get('status', 'active'), deal.get('payment_method', None))
                )
    conn.commit()
    conn.close()

def delete_deal(deal_id):
    conn = _db_connect()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM deals WHERE deal_id = ?', (deal_id,))
    conn.commit()
    conn.close()


# Phase 9 (P8.14/P8.15): async wrappers around synchronous SQLite writers.
# Hot-path async handlers (pay_from_balance, buyer_confirm_received, auto-payout,
# worker stat setters) call these many times per request; running the sync body
# directly on the event loop blocks the coroutine for the full SQLite round-trip
# (5-50ms x N rows). asyncio.to_thread offloads to the default ThreadPoolExecutor
# so the loop stays free. Sync sites (ensure_user_exists, monitor thread,
# create_withdrawal-internal) keep calling the original functions directly.
async def asave_user_data(user_id: int) -> None:
    """Async wrapper around save_user_data — runs in default thread pool."""
    await asyncio.to_thread(save_user_data, user_id)


async def asave_deal(deal_id: str) -> None:
    """Async wrapper around save_deal — runs in default thread pool."""
    await asyncio.to_thread(save_deal, deal_id)


def save_bot_setting(setting_name, setting_value):
    conn = _db_connect()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT OR REPLACE INTO bot_settings (setting_name, setting_value)
        VALUES (?, ?)
    ''', (setting_name, setting_value))
    conn.commit()
    conn.close()

async def send_notification_to_chat(context: ContextTypes.DEFAULT_TYPE, message: str):
    global NOTIFICATION_CHAT_ID
    if NOTIFICATION_CHAT_ID:
        try:
            await context.bot.send_message(
                chat_id=NOTIFICATION_CHAT_ID,
                text=message,
                parse_mode="HTML"
            )
        except Exception as e:
            logger.error(f"Ошибка при отправке уведомления в чат {NOTIFICATION_CHAT_ID}: {e}")

async def edit_message_or_caption(query, text: str, reply_markup):
    """Редактирует сообщение: подпись к фото/гифке или текст, в зависимости от типа сообщения."""
    if query.message.photo or getattr(query.message, 'animation', None) or getattr(query.message, 'video', None):
        try:
            await query.edit_message_caption(caption=text, parse_mode="HTML", reply_markup=reply_markup)
        except BadRequest as e:
            if "Message is not modified" not in str(e):
                raise
    else:
        await query.edit_message_text(text=text, parse_mode="HTML", reply_markup=reply_markup)

def _message_has_media(message):
    """Проверяет, есть ли у сообщения медиа (фото или анимация/видео)."""
    return bool(message.photo or getattr(message, 'animation', None) or getattr(message, 'video', None))

async def update_section_media(query, section: str, caption: str, reply_markup):
    """Обновляет сообщение: меняет ТОЛЬКО caption (медиа уже на сообщении).
    Раньше каждый клик перезаливал банер/гифку байтами на серверы Telegram (1-3 сек на клик) —
    теперь только caption обновляется (мгновенно). Медиа подгружается единожды при первом
    показе через send_photo/send_animation, после чего edit_message_caption — это просто
    обновление подписи, без пересылки бинаря."""
    await edit_message_or_caption(query, caption, reply_markup)


# ============================================================
# Внутренний кошелёк: баланс TON+USDT, пополнение, вывод
# ============================================================
_TON_ADDR_RE = re.compile(r"^[EU]Q[A-Za-z0-9_-]{46}$")

# P10.3: per-currency float tolerance for balance comparisons. TON has 9 decimal
# places (smallest unit = 1e-9 nano-TON) so 1e-9 epsilon is fine. USDT has only
# 6 decimal places (1e-6 micro-USDT), so a 1e-9 tolerance is tighter than the
# smallest representable amount and would incorrectly reject valid amounts when
# floats drift. 1e-7 is well below 1e-6 (smallest USDT unit) yet loose enough
# to absorb float-arithmetic noise.
_TON_EPS = 1e-9
_USDT_EPS = 1e-7


def _balance_eps(currency: str) -> float:
    """Float-comparison epsilon sized to the currency's smallest unit."""
    return _USDT_EPS if (currency or '').upper() == 'USDT' else _TON_EPS


def _fmt_amount(value, currency: str = '') -> str:
    """Render an amount with per-currency precision.

    P10.4: TON has 9 decimals (1 nano = 1e-9); the legacy 4-decimal cap
    truncated nano-TON dust to "0". USDT has 6 decimals. When the caller
    knows the currency, we render at the native precision; otherwise we
    keep the existing 4-decimal default to avoid breaking unrelated UI.
    """
    try:
        v = float(value or 0)
    except (TypeError, ValueError):
        v = 0.0
    if not math.isfinite(v):
        return "0"
    if float(v).is_integer():
        return f"{int(v)}"
    cur = (currency or '').upper()
    if cur == 'TON':
        return f"{v:.9f}".rstrip("0").rstrip(".") or "0"
    if cur == 'USDT':
        return f"{v:.6f}".rstrip("0").rstrip(".") or "0"
    return f"{v:.4f}".rstrip("0").rstrip(".") or "0"


def _user_balance(user_id: int, currency: str) -> float:
    with _BALANCE_LOCK:
        bc = (user_data.get(user_id, {}) or {}).get('balance_currencies') or {}
        try:
            return float(bc.get(currency, 0) or 0)
        except (TypeError, ValueError):
            return 0.0


def _user_ton_address(user_id: int) -> str:
    ud = user_data.get(user_id, {}) or {}
    addr = (ud.get('ton_wallet') or '').strip()
    if addr:
        return addr
    wallets = ud.get('ton_wallets') or []
    return wallets[0] if wallets else ''


def _set_user_ton_address(user_id: int, address: str) -> None:
    ensure_user_exists(user_id)
    ud = user_data[user_id]
    ud['ton_wallet'] = address
    wallets = list(ud.get('ton_wallets') or [])
    if address not in wallets:
        wallets = [address] + [w for w in wallets if w]
    ud['ton_wallets'] = wallets[:5]
    save_user_data(user_id)


def _build_wallet_main_keyboard(lang: str) -> InlineKeyboardMarkup:
    # 2026-05-07: «Пополнить»/«Вывести» теперь без указания валюты.
    # При клике показывается выбор TON/USDT (USDT-flow пока заглушка
    # «скоро» — jetton-парсер не реализован).
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(get_text(lang, "wallet_btn_dep"), callback_data='wallet_dep')],
        [InlineKeyboardButton(get_text(lang, "wallet_btn_wd"),  callback_data='wallet_wd')],
        [InlineKeyboardButton(get_text(lang, "wallet_btn_set_addr"), callback_data='wallet_set_addr')],
        [InlineKeyboardButton(get_text(lang, "wallet_btn_my_withdrawals"), callback_data='my_withdrawals')],
        [InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='menu')],
    ])


def _build_wallet_currency_choice(lang: str, action: str) -> InlineKeyboardMarkup:
    """Меню выбора валюты для пополнения/вывода. action = 'dep' | 'wd'."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("TON", callback_data=f'wallet_{action}_ton')],
        [InlineKeyboardButton(
            get_text(lang, f"wallet_btn_{action}_usdt"),
            callback_data=f'wallet_{action}_usdt')],
        [InlineKeyboardButton(get_text(lang, "back_button"), callback_data='wallet_menu')],
    ])


async def _send_wallet_main(query, context, user_id: int, lang: str):
    addr = _user_ton_address(user_id)
    addr_html = f"<code>{addr}</code>" if addr else get_text(lang, "wallet_no_addr")
    ton_bal = _user_balance(user_id, 'TON')
    usdt_bal = _user_balance(user_id, 'USDT')
    try:
        from .price import fmt_usd as _fmt_usd
        ton_usd_str = _fmt_usd(ton_bal, 'TON')
        usdt_usd_str = _fmt_usd(usdt_bal, 'USDT')
    except Exception:
        ton_usd_str = usdt_usd_str = ""
    text = get_text(lang, "wallet_main_message",
                    ton=_fmt_amount(ton_bal, 'TON'),
                    usdt=_fmt_amount(usdt_bal, 'USDT'),
                    ton_usd=f"<i>{ton_usd_str}</i>" if ton_usd_str else "",
                    usdt_usd=f"<i>{usdt_usd_str}</i>" if usdt_usd_str else "",
                    ton_addr=addr_html)
    kb = _build_wallet_main_keyboard(lang)
    await update_section_media(query, 'wallet', text, kb)


async def _show_deposit(query, context, user_id: int, lang: str, currency: str):
    try:
        import config as _cfg
        from .dynamic_settings import get_ton_deposit_address as _get_dep_addr
        addr = (_get_dep_addr() or "").strip()
        api_key = (getattr(_cfg, "TON_API_KEY", "") or "").strip()
        min_ton = float(getattr(_cfg, "MIN_DEPOSIT_TON", 0.1))
        min_usdt = float(getattr(_cfg, "MIN_DEPOSIT_USDT", 1.0))
    except Exception:
        addr, api_key, min_ton, min_usdt = "", "", 0.1, 1.0

    if not addr or not api_key:
        await query.answer(get_text(lang, "deposit_disabled_message"), show_alert=True)
        return

    await query.answer()
    memo = f"user_{user_id}"
    if currency == 'TON':
        text = get_text(lang, "deposit_ton_message",
                        address=addr, memo=memo, min_amount=_fmt_amount(min_ton, 'TON'))
    else:
        text = get_text(lang, "deposit_usdt_message",
                        address=addr, memo=memo, min_amount=_fmt_amount(min_usdt, 'USDT'))
    kb = InlineKeyboardMarkup([[InlineKeyboardButton(
        get_text(lang, "back_to_menu_button"), callback_data='wallet_menu')]])
    await update_section_media(query, 'wallet', text, kb)


async def _show_my_withdrawals(query, lang: str, user_id: int):
    await query.answer()
    rows = []
    try:
        c = _db_connect()
        cur = c.cursor()
        cur.execute(
            "SELECT id, currency, amount, address, status, created_at "
            "FROM withdrawals WHERE user_id=? ORDER BY id DESC LIMIT 20", (user_id,))
        rows = cur.fetchall()
        c.close()
    except Exception as e:
        logger.warning("my_withdrawals fetch: %s", e)
    if not rows:
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(
            get_text(lang, "back_to_menu_button"), callback_data='wallet_menu')]])
        await update_section_media(query, 'wallet', get_text(lang, "my_withdrawals_empty"), kb)
        return
    parts = [get_text(lang, "my_withdrawals_title"), ""]
    for wid, cur_, amt, addr, status, ts in rows:
        emoji = {'pending': '⏳', 'sent': '✅', 'rejected': '❌'}.get(status, '•')
        status_text = get_text(lang, f"wd_status_{status}") if status in ('pending','sent','rejected') else status
        try:
            from datetime import datetime as _dt
            ts_str = _dt.fromtimestamp(int(ts)).strftime("%d.%m.%Y %H:%M")
        except Exception:
            ts_str = "—"
        parts.append(get_text(lang, "my_withdrawals_item",
                              wid=wid, amount=_fmt_amount(amt, cur_), currency=cur_,
                              address=addr, status_emoji=emoji,
                              status=status_text, created_at=ts_str))
        parts.append("")
    kb = InlineKeyboardMarkup([[InlineKeyboardButton(
        get_text(lang, "back_to_menu_button"), callback_data='wallet_menu')]])
    await update_section_media(query, 'wallet', "\n".join(parts).strip(), kb)


async def _start_withdraw(query, context, user_id: int, lang: str, currency: str):
    ensure_user_exists(user_id)
    bal = _user_balance(user_id, currency)
    try:
        import config as _cfg
        min_amount = (float(_cfg.MIN_WITHDRAW_TON) if currency == 'TON'
                      else float(_cfg.MIN_WITHDRAW_USDT))
    except Exception:
        min_amount = 1.0 if currency == 'TON' else 5.0

    if bal < min_amount:
        await query.answer(
            get_text(lang, "withdraw_low_balance",
                     balance=_fmt_amount(bal, currency), currency=currency),
            show_alert=True,
        )
        return
    await query.answer()
    saved_addr = _user_ton_address(user_id)
    context.user_data['awaiting_wd_currency'] = currency
    if saved_addr:
        context.user_data['awaiting_wd_address_saved'] = saved_addr
        context.user_data['awaiting_wd_amount'] = True
        text = get_text(lang, "withdraw_ask_amount",
                        min_amount=_fmt_amount(min_amount, currency), currency=currency)
    else:
        context.user_data['awaiting_wd_address'] = True
        text = get_text(lang, "withdraw_ask_address")
    kb = InlineKeyboardMarkup([[InlineKeyboardButton(
        get_text(lang, "back_to_menu_button"), callback_data='wallet_menu')]])
    await update_section_media(query, 'wallet', text, kb)


# --- БД helpers ---

def deposit_exists(tx_hash: str) -> bool:
    try:
        c = _db_connect()
        cur = c.cursor()
        cur.execute("SELECT 1 FROM deposits WHERE tx_hash=?", (tx_hash,))
        row = cur.fetchone()
        c.close()
        return row is not None
    except Exception:
        return False


def record_deposit_and_credit(tx_hash: str, user_id: int, currency: str, amount: float) -> bool:
    """Идемпотентно: записывает депозит и пополняет balance_currencies. True если зачислено."""
    # P5.12: гарантируем строку в users ДО любых операций. Если deposit
    # пришёл от user_id, который ещё не делал /start (например, кто-то
    # отправил TON/USDT с memo до первой регистрации), без этого вызова
    # последующий save_user_data ниже создаст осиротевшую запись или
    # упадёт на FOREIGN KEY (balance_stars и пр.). Идемпотентен — если
    # юзер уже есть, ничего не меняет.
    ensure_user_exists(user_id)
    # P6.6: c=None before try — _db_connect() can raise (e.g. PRAGMA failure
    # on corrupt sqlite, see P6.3) and the bare-except below would NameError
    # on `c.close()`, masking the real cause.
    c = None
    try:
        c = _db_connect()
        cur = c.cursor()
        cur.execute("BEGIN")
        cur.execute(
            "INSERT OR IGNORE INTO deposits (tx_hash, user_id, currency, amount, created_at) "
            "VALUES (?,?,?,?,?)",
            (tx_hash, user_id, currency, float(amount), int(time.time())),
        )
        if cur.rowcount == 0:
            c.execute("ROLLBACK")
            c.close()
            return False
        c.commit()
        c.close()
    except Exception:
        if c is not None:
            try:
                c.close()
            except Exception:
                pass
        return False
    # Пополняем in-memory + persist
    ensure_user_exists(user_id)
    # Lock guards cross-thread RMW: this runs in TonDepositMonitor daemon thread
    # while create_withdrawal mutates the same dict from the asyncio main loop.
    with _BALANCE_LOCK:
        bc = user_data[user_id].setdefault('balance_currencies', {})
        bc[currency] = float(bc.get(currency, 0) or 0) + float(amount)
    save_user_data(user_id)
    return True


def create_withdrawal(user_id: int, currency: str, amount: float, address: str) -> int:
    """Списывает с баланса (заморозка) и создаёт заявку. Кидает ValueError при нехватке.

    Per-user lock (`_WD_USER_LOCKS`) сериализует всю транзакцию debit+insert,
    чтобы быстрые двойные клики юзера не создали две `withdrawals`-записи и не
    списали баланс дважды. Лок per-user, разные пользователи не конкурируют.
    `_BALANCE_LOCK` остаётся для cross-thread защиты от deposit-монитора.
    `contextlib.closing` гарантирует закрытие SQLite-коннекта (стандартный
    `with sqlite3.connect()` коммитит/откатывает, но НЕ закрывает — это leak).
    """
    ensure_user_exists(user_id)
    user_lock = _WD_USER_LOCKS.setdefault(user_id, threading.Lock())
    with user_lock:
        # Anti-double-click guard: if a Telegram tap propagates twice (network
        # retry, fast double-tap, etc.) the second invocation may slip past the
        # in-process per-user lock if the first already finished. A 30-second
        # SQL probe of recently-created pending rows blocks the duplicate before
        # we debit the balance again. raise/catch keeps the existing flow:
        # the text-input handler maps the marker to a friendly user message.
        with contextlib.closing(_db_connect()) as c:
            cur = c.cursor()
            # P10.9: parameterize timestamp via Python time.time() so the dedup
            # window matches the INSERT clock (also int(time.time())). strftime
            # 'now' is UTC while int(time.time()) is also UTC epoch — so the
            # values agree today, but mixing them across queries is brittle if
            # the SQLite build's TZ semantics ever shift. Symmetry > cleverness.
            cur.execute(
                "SELECT 1 FROM withdrawals WHERE user_id=? AND status='pending' "
                "AND created_at > ? LIMIT 1",
                (user_id, int(time.time()) - 30),
            )
            if cur.fetchone():
                raise ValueError("recent_pending_withdrawal")
        # P5.48: per-user 24h aggregate cap. Caps are read from config as
        # DAILY_WITHDRAW_CAP_<CURRENCY>; 0 / unset disables. Sums only
        # 'pending' + 'sent' rows (rejected / failed don't count). Keeps
        # hot-wallet drainers from cycling huge volume through one account.
        try:
            import config as _cfg
            cap = float(getattr(_cfg, f"DAILY_WITHDRAW_CAP_{currency.upper()}", 0) or 0)
        except (TypeError, ValueError):
            cap = 0.0
        if cap > 0:
            with contextlib.closing(_db_connect()) as c:
                cur = c.cursor()
                # P10.9: parameterize timestamp (mirrors INSERT's int(time.time())).
                cur.execute(
                    "SELECT COALESCE(SUM(amount), 0) FROM withdrawals "
                    "WHERE user_id=? AND currency=? AND status IN ('pending','sent') "
                    "AND created_at > ?",
                    (user_id, currency, int(time.time()) - 86400),
                )
                row = cur.fetchone()
                day_sum = float((row[0] if row else 0) or 0)
            if day_sum + float(amount) > cap + 1e-9:
                raise ValueError("daily_cap_exceeded")
        # Atomic check-and-debit — re-read balance INSIDE the lock to avoid TOCTOU
        # against record_deposit_and_credit running in the deposit-monitor thread.
        with _BALANCE_LOCK:
            bc = user_data[user_id].setdefault('balance_currencies', {})
            try:
                bal = float(bc.get(currency, 0) or 0)
            except (TypeError, ValueError):
                bal = 0.0
            # P10.3: per-currency epsilon — 1e-9 is correct for TON (1 nano)
            # but tighter than USDT's 1e-6 smallest unit. _balance_eps picks
            # the right scale per currency.
            if bal + _balance_eps(currency) < float(amount):
                raise ValueError("insufficient_funds")
            bc[currency] = bal - float(amount)
        save_user_data(user_id)

        with contextlib.closing(_db_connect()) as c, c:
            cur = c.cursor()
            cur.execute(
                "INSERT INTO withdrawals (user_id, currency, amount, address, status, created_at) "
                "VALUES (?,?,?,?, 'pending', ?)",
                (user_id, currency, float(amount), address, int(time.time())),
            )
            wid = cur.lastrowid
    return wid


def _mark_withdrawal_sent(wid: int, tx_hash: Optional[str]) -> None:
    """Помечает заявку как 'sent' с tx_hash."""
    try:
        with contextlib.closing(_db_connect()) as c, c:
            cur = c.cursor()
            cur.execute(
                "UPDATE withdrawals SET status='sent', processed_at=?, tx_hash=? "
                "WHERE id=? AND status='pending'",
                (int(time.time()), tx_hash or "", wid),
            )
    except Exception as e:
        logger.warning(f"_mark_withdrawal_sent({wid}): {e}")


def _mark_withdrawal_error(wid: int, err: str) -> None:
    """Сохраняет ошибку и оставляет 'pending' — админ потом может пересмотреть/отклонить."""
    try:
        with contextlib.closing(_db_connect()) as c, c:
            cur = c.cursor()
            cur.execute(
                "UPDATE withdrawals SET error=? WHERE id=?",
                ((err or "")[:500], wid),
            )
    except Exception as e:
        logger.warning(f"_mark_withdrawal_error({wid}): {e}")


def _mark_withdrawal_broadcasting(wid: int) -> bool:
    """Атомарно «занимает» строку для broadcast: UPDATE WHERE broadcast_at IS NULL.

    Возвращает True если строка успешно claimed (rowcount==1); False если
    другой процесс/coroutine уже claimed её ранее. Caller должен прервать
    отправку при False — иначе медленный send_ton + concurrent resume могут
    оба пройти и сделать double-broadcast.
    """
    try:
        with contextlib.closing(_db_connect()) as c, c:
            cur = c.cursor()
            cur.execute(
                "UPDATE withdrawals SET broadcast_at=? WHERE id=? AND broadcast_at IS NULL",
                (int(time.time()), wid),
            )
            return cur.rowcount > 0
    except Exception as e:
        logger.warning(f"_mark_withdrawal_broadcasting({wid}): {e}")
        return False


def _verify_payout_onchain(wid: int) -> Optional[str]:
    """Query TonCenter v3 for outgoing TX with memo containing 'withdraw #{wid}'.

    Возвращает tx_hash, если транзакция найдена on-chain; иначе None.
    Используется до повторного broadcast (в `_resume_pending_withdrawals` и
    в sweeper'е) — закрывает Scenario C: процесс упал между успешным broadcast
    в сеть и `_mark_withdrawal_sent`, при следующем запуске мы видим transfer
    on-chain и не отправляем второй TX.
    Консервативно: при любой ошибке возвращает None (лучше пропустить и
    дождаться следующего sweep, чем риск double-pay).
    """
    import urllib.request
    import urllib.parse
    import urllib.error
    import json as _json

    try:
        from .dynamic_settings import get_ton_deposit_address as _get_dynamic_settings_addr
        import config as _config
    except Exception as e:
        logger.warning(f"_verify_payout_onchain wd#{wid}: import failed: {e}")
        return None

    addr = (_get_dynamic_settings_addr() or "").strip()
    api_key = (getattr(_config, "TON_API_KEY", "") or "").strip()
    if not addr or not api_key:
        return None
    params = [
        ("account", addr),
        ("action_type", "ton_transfer"),
        ("action_type", "jetton_transfer"),
        ("sort", "desc"),
        ("limit", "100"),
    ]
    url = "https://toncenter.com/api/v3/actions?" + urllib.parse.urlencode(params)
    try:
        req = urllib.request.Request(
            url,
            headers={
                "X-API-Key": api_key,
                "User-Agent": "ForSale/1.0",
                "accept": "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = _json.loads(resp.read().decode("utf-8"))
        # Word-boundary match: "withdraw #42" must NOT match "withdraw #420".
        # send_ton/send_usdt always append " | id:<unique>" to the memo, so the
        # normal on-chain comment is "withdraw #{wid} | id:{hex}". Strict check
        # uses that delimiter; regex fallback handles whitespace or end-of-string
        # edge cases (e.g. legacy rows without id suffix).
        marker_strict = f"withdraw #{wid} |"
        marker_re = re.compile(rf"withdraw #{wid}(?:\s|\Z)(?!\d)")
        def _matches(text: str) -> bool:
            if not text:
                return False
            if marker_strict in text:
                return True
            return bool(marker_re.search(text))
        for action in data.get("actions") or []:
            d = action.get("details") or {}
            comment = d.get("comment") or ""
            # Для jetton-транзакций memo может лежать в forward_payload.
            fwd = d.get("forward_payload") or ""
            if _matches(comment) or _matches(fwd):
                txs = action.get("transactions") or []
                if txs:
                    return txs[0]
    except Exception as e:
        logger.warning(f"_verify_payout_onchain wd#{wid}: {e}")
    return None


async def _run_auto_payout(
    bot, wid: int, user_id: int, currency: str, amount: float, address: str, lang: str,
    already_claimed: bool = False,
) -> None:
    """
    Фоновая таска: вызывает payout.send_ton/send_usdt, обновляет withdrawals.
    Юзер уже получил «Заявка принята» сообщение — отдельно шлём финальный статус.

    `already_claimed=True` означает, что caller (например, `_resume_pending_withdrawals`
    или sweep-loop) уже выполнил атомарный UPDATE broadcast_at. В этом случае
    дубликатный claim не нужен — pre-claim защитил бы от двойного запуска,
    но повторный UPDATE на том же id не пройдёт (broadcast_at уже != NULL)
    и мы бы преждевременно прервали send_ton.
    """
    # Outer guard so any unhandled exception is logged instead of dying silently
    # in a fire-and-forget create_task.
    try:
        try:
            from . import payout as _payout
        except Exception as e:
            logger.warning(f"[auto_payout] payout module import failed: {e}")
            await asyncio.to_thread(_mark_withdrawal_error, wid, f"import payout: {e}")
            return

        memo = f"withdraw #{wid}"
        # Атомарный claim: UPDATE WHERE broadcast_at IS NULL. Если возвращает
        # False — другой coroutine/процесс уже занял row для broadcast, и
        # повторный send_ton/usdt привёл бы к double-pay. Прерываем тихо.
        # Skip when caller уже claimed (resume / sweep): см. docstring выше.
        if not already_claimed:
            # P8.16: SQLite UPDATE → to_thread so the event loop is not blocked
            # while we wait for the row-claim disk write.
            if not await asyncio.to_thread(_mark_withdrawal_broadcasting, wid):
                logger.warning(f"_run_auto_payout: wd#{wid} already claimed (race), aborting")
                return
        if currency.upper() == "TON":
            ok, tx_hash, err = await _payout.send_ton(address, float(amount), memo)
        elif currency.upper() == "USDT":
            ok, tx_hash, err = await _payout.send_usdt(address, float(amount), memo)
        else:
            await asyncio.to_thread(_mark_withdrawal_error, wid, f"unknown currency: {currency}")
            return

        if ok:
            await asyncio.to_thread(_mark_withdrawal_sent, wid, tx_hash)
            try:
                tx_part = f"\n<b>TX:</b> <code>{tx_hash}</code>" if tx_hash else ""
                await bot.send_message(
                    user_id,
                    f"✅ <b>Вывод #{wid} отправлен</b>\n"
                    f"<b>{_fmt_amount(amount, currency)} {currency}</b> → <code>{address}</code>{tx_part}",
                    parse_mode="HTML",
                )
            except Exception:
                pass
            logger.info(f"[auto_payout] wd#{wid} OK: {amount} {currency} → {address[:12]} tx={tx_hash}")
        else:
            await asyncio.to_thread(_mark_withdrawal_error, wid, err or "unknown error")
            # P8.27 (HIGH): уведомляем юзера, что его заявка не прошла. Раньше юзер
            # видел «принято» и тишину — теперь знает, что админ обработает вручную.
            try:
                await bot.send_message(
                    user_id,
                    f"⚠️ <b>Вывод #{wid} не прошёл автоматически</b>\n\n"
                    f"<b>{_fmt_amount(amount, currency)} {currency}</b> → <code>{address}</code>\n"
                    f"<b>Ошибка:</b> <code>{(err or '')[:200]}</code>\n\n"
                    f"<i>Заявка осталась в системе, админ обработает вручную.</i>",
                    parse_mode="HTML",
                )
            except Exception:
                pass
            # Админам — заявка осталась 'pending', поправят руками
            try:
                import config as _cfg
                admins = set(getattr(_cfg, "GARANT_ADMIN_USER_IDS", None) or set())
                legacy = getattr(_cfg, "GARANT_ADMIN_USER_ID", None)
                if legacy:
                    admins.add(int(legacy))
                for aid in admins:
                    try:
                        await bot.send_message(
                            aid,
                            f"⚠️ <b>Авто-вывод #{wid} не прошёл</b>\n"
                            f"<b>{amount} {currency}</b> → <code>{address}</code>\n"
                            f"<b>Ошибка:</b> <code>{(err or '')[:200]}</code>\n"
                            f"<i>Заявка осталась в /admin → Заявки на вывод</i>",
                            parse_mode="HTML",
                        )
                    except Exception:
                        pass
            except Exception:
                pass
            logger.warning(f"[auto_payout] wd#{wid} FAIL: {err}")
    except Exception as e:
        logger.error(f"[auto_payout] wd#{wid} unhandled exception: {e}", exc_info=True)
        try:
            await asyncio.to_thread(_mark_withdrawal_error, wid, f"unhandled: {e}")
        except Exception:
            pass


def _spawn_auto_payout(bot, wid, user_id, currency, amount, address, lang, already_claimed: bool = False):
    """create_task wrapper that logs swallowed exceptions via add_done_callback."""
    task = asyncio.create_task(
        _run_auto_payout(bot, wid, user_id, currency, amount, address, lang,
                         already_claimed=already_claimed)
    )

    def _on_done(t):
        try:
            exc = t.exception()
        except (asyncio.CancelledError, Exception):
            return
        if exc is not None:
            logger.error(f"_run_auto_payout died: wd#{wid}: {exc!r}")

    task.add_done_callback(_on_done)
    return task


async def _resume_pending_withdrawals(application) -> int:
    """
    Crash-recovery: подхватывает withdrawals.status='pending' без tx_hash и без error,
    созданные более 5 минут назад, и перезапускает _run_auto_payout. Должно
    вызываться из post_init после старта Application.

    R7: фильтр broadcast_at < now-600 не даёт перезапустить row, у которого
    был успешный broadcast в последние 10 минут (мог не дойти _mark_withdrawal_sent).
    R8: advisory-lock через UPDATE ... WHERE broadcast_at IS NULL — параллельные
    процессы не дублируют TX.
    """
    try:
        with contextlib.closing(_db_connect()) as c:
            cur = c.cursor()
            cur.execute(
                "SELECT id, user_id, currency, amount, address FROM withdrawals "
                "WHERE status='pending' AND (tx_hash IS NULL OR tx_hash='') "
                "AND (error IS NULL OR error='') "
                "AND created_at < strftime('%s','now') - 300 "
                "AND (broadcast_at IS NULL OR broadcast_at < strftime('%s','now') - 600)"
            )
            rows = cur.fetchall()
    except Exception as e:
        logger.warning(f"[resume_pending] query failed: {e}")
        return 0

    count = 0
    for row in rows or []:
        try:
            wid, uid, currency, amount, address = row
            # On-chain verify ДО claim: если предыдущий процесс упал между
            # успешным broadcast и _mark_withdrawal_sent, TonCenter уже видит
            # transfer с memo 'withdraw #{wid}'. Помечаем sent и пропускаем
            # повторную отправку — иначе double-pay.
            try:
                # to_thread keeps the synchronous urllib call off the event loop.
                # Startup is tolerant of blocking, but staying consistent with
                # the sweep loop avoids accidental regressions if this is reused.
                tx_hash = await asyncio.to_thread(_verify_payout_onchain, int(wid))
            except Exception as ve:
                logger.warning(f"[resume_pending] verify wid={wid} failed: {ve}")
                tx_hash = None
            if tx_hash:
                try:
                    # P8.16: SQLite UPDATE → to_thread to keep the resume loop
                    # off the event loop on startup.
                    await asyncio.to_thread(_mark_withdrawal_sent, int(wid), tx_hash)
                except Exception as me:
                    logger.warning(f"[resume_pending] mark_sent wid={wid} after verify: {me}")
                logger.info(f"[resume_pending] wid={wid} already on-chain (tx={tx_hash}), skipping re-broadcast")
                continue
            # Advisory-lock: claim row атомарно. Если другой процесс уже взял
            # (broadcast_at != NULL), rowcount==0 → пропускаем.
            try:
                with contextlib.closing(_db_connect()) as claim_c, claim_c:
                    claim_cur = claim_c.cursor()
                    claim_cur.execute(
                        "UPDATE withdrawals SET broadcast_at = strftime('%s','now') "
                        "WHERE id = ? AND broadcast_at IS NULL",
                        (int(wid),),
                    )
                    claimed = claim_cur.rowcount
            except Exception as ce:
                logger.warning(f"[resume_pending] claim wid={wid} failed: {ce}")
                continue
            if claimed == 0:
                logger.info(f"[resume_pending] wid={wid} already claimed by another process, skip")
                continue
            lang = (user_data.get(int(uid), {}) or {}).get('lang', 'ru')
            # already_claimed=True: мы уже выставили broadcast_at в claim UPDATE
            # выше; _run_auto_payout не должен пытаться claim повторно.
            _spawn_auto_payout(
                application.bot, int(wid), int(uid),
                str(currency or ''), float(amount or 0), str(address or ''), lang,
                already_claimed=True,
            )
            count += 1
        except Exception as e:
            logger.warning(f"[resume_pending] row {row}: {e}")
    if count:
        logger.info(f"[resume_pending] resumed {count} stuck withdrawals")
    else:
        logger.debug("[resume_pending] no stuck withdrawals")
    return count


def _fetch_stuck_withdrawal_rows() -> list:
    """Sync helper: fetch withdrawals with a stale broadcast_at. Wrapped in
    asyncio.to_thread by `_stuck_withdrawal_sweep_once` so the SQLite I/O does
    not block the event loop while the sweep runs hourly."""
    with contextlib.closing(_db_connect()) as c:
        cur = c.cursor()
        cur.execute(
            "SELECT id, user_id, currency, amount, address FROM withdrawals "
            "WHERE status='pending' AND broadcast_at IS NOT NULL "
            "AND (tx_hash IS NULL OR tx_hash='') "
            "AND (error IS NULL OR error='') "
            "AND broadcast_at < strftime('%s','now') - 3600"
        )
        return cur.fetchall()


async def _stuck_withdrawal_sweep_once(application) -> int:
    """Одна итерация sweeper'а: ищет broadcast_at != NULL && tx_hash IS NULL && error IS NULL
    && broadcast_at < now-3600 — это row, у которого мы помечали broadcast больше часа назад,
    но `_mark_withdrawal_sent` так и не записал tx_hash.

    Для каждого такого row вызываем `_verify_payout_onchain`. Если transfer найден on-chain
    → mark_sent (row завершён). Иначе → admin warning + log: broadcast, скорее всего, тихо
    провалился (LiteServer/RPC down, throttle и т.п.) и стоит вмешаться вручную.

    Все блокирующие операции (SQLite SELECT/UPDATE и synchronous urllib в
    `_verify_payout_onchain`) выполняются через `asyncio.to_thread`, чтобы
    часовой sweep не блокировал event loop.
    """
    try:
        rows = await asyncio.to_thread(_fetch_stuck_withdrawal_rows)
    except Exception as e:
        logger.warning(f"[stuck_sweep] query failed: {e}")
        return 0

    handled = 0
    for row in rows or []:
        try:
            wid, uid, currency, amount, address = row
            tx_hash = None
            try:
                # urllib.request.urlopen is synchronous — keep it off the loop.
                tx_hash = await asyncio.to_thread(_verify_payout_onchain, int(wid))
            except Exception as ve:
                logger.warning(f"[stuck_sweep] verify wid={wid} failed: {ve}")
            if tx_hash:
                try:
                    await asyncio.to_thread(_mark_withdrawal_sent, int(wid), tx_hash)
                except Exception as me:
                    logger.warning(f"[stuck_sweep] mark_sent wid={wid}: {me}")
                logger.info(f"[stuck_sweep] wid={wid} found on-chain (tx={tx_hash}), marked sent")
                handled += 1
                continue
            # Не нашли on-chain — broadcast, скорее всего, тихо провалился.
            logger.warning(
                f"[stuck_sweep] wid={wid} stuck >1h: broadcast_at set, no tx_hash, "
                f"not found on-chain. amount={amount} {currency} → {str(address)[:12]}"
            )
            try:
                import config as _cfg
                admins = set(getattr(_cfg, "GARANT_ADMIN_USER_IDS", None) or set())
                legacy = getattr(_cfg, "GARANT_ADMIN_USER_ID", None)
                if legacy:
                    admins.add(int(legacy))
                msg = (
                    f"⚠️ <b>Stuck withdrawal #{wid}</b>\n"
                    f"<b>{_fmt_amount(amount, currency)} {currency}</b> → <code>{address}</code>\n"
                    f"<i>broadcast_at &gt; 1h, on-chain не виден.</i>\n"
                    f"Проверьте /admin → Заявки на вывод."
                )
                for aid in admins:
                    try:
                        await application.bot.send_message(aid, msg, parse_mode="HTML")
                    except Exception:
                        pass
            except Exception:
                pass
        except Exception as e:
            logger.warning(f"[stuck_sweep] row {row}: {e}")
    return handled


async def _stuck_withdrawal_sweep_loop(application) -> None:
    """Periodic background task: каждый час чистит stuck-withdrawals.

    Запускается из `_post_init_garant` после `_resume_pending_withdrawals`.
    Защищён try/except, чтобы единичная ошибка не убила цикл.
    """
    interval_s = 3600
    # Первый прогон через 5 минут — чтобы дать `_resume_pending_withdrawals`
    # отработать и не бить по тем же row сразу.
    await asyncio.sleep(300)
    while True:
        try:
            await _stuck_withdrawal_sweep_once(application)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.warning(f"[stuck_sweep] iteration error: {e}", exc_info=True)
        try:
            await asyncio.sleep(interval_s)
        except asyncio.CancelledError:
            raise


async def _do_confirm_payment(context: ContextTypes.DEFAULT_TYPE, deal_id: str):
    """Подтверждение оплаты по сделке. Возвращает (True, None) при успехе или (False, текст_ошибки).

    SECURITY P10.15: This function is used by /close and admin_confirm_deal_ to manually flip
    status='active' -> 'confirmed' WITHOUT debiting buyer balance. We deliberately do NOT set
    escrow_collected=True here — that flag is reserved for actual on-bot escrow debit (pay_from_balance_).
    Without this restraint, buyer_confirm_received_ would unconditionally credit seller, allowing a
    money-mint exploit (seller uses twink as fake buyer, admin /close, then twink confirms received).
    Policy: if admin manually verified an off-bot payment and wants to credit seller, they must use
    /admin -> User -> Credit balance manually. The buyer_confirm_received_ handler will skip seller
    credit for any deal where escrow_collected is False and notify admins of the suspicious flow.
    """
    deal = deals.get(deal_id) if deal_id else None
    if not deal:
        return False, "Сделка не найдена."
    seller_id = deal.get('seller_id')
    buyer_id = deal.get('buyer_id')
    if deal.get('status') != 'active':
        return False, "Оплату по этой сделке уже подтвердили или сделку отменили."
    if not buyer_id:
        return False, "Нельзя подтвердить оплату: у сделки не указан покупатель (buyer_id пустой)."
    deal['status'] = 'confirmed'
    # SECURITY P10.15: explicitly do NOT set escrow_collected here. See docstring above.
    await asave_deal(deal_id)
    ensure_user_exists(buyer_id)
    ensure_user_exists(seller_id)
    # Баланс продавцу начисляем только после завершения сделки (status='completed'),
    # чтобы не было начислений до конца.
    buyer_lang = user_data.get(buyer_id, {}).get('lang', 'ru')
    seller_lang = user_data.get(seller_id, {}).get('lang', 'ru')
    buyer_username = await _chat_username_or_name(context, buyer_id, "Неизвестно")
    valute_payment = _valute_display(deal.get('payment_method'), buyer_lang)
    deal_id_short = (deal_id[:8]) if deal_id else ''
    _seller_msg_key = "payment_confirmed_seller_message_account" if deal.get('deal_type') == 'account' else "payment_confirmed_seller_message"
    # P10.7: caption-bound template — Telegram caps captions at 1024 chars and the
    # template repeats {buyer_username} 5× and HTML-escapes {description}, which
    # can blow past the limit. Cap escaped description at 200 chars so worst-case
    # render fits comfortably inside the 1024 budget.
    _desc_raw = str(deal.get('description', '-') or '-')
    _desc_short = html_module.escape(_desc_raw)[:200]
    if len(_desc_raw) > 200:
        _desc_short += '...'
    seller_message = get_text(seller_lang, _seller_msg_key,
        deal_id_short=deal_id_short, description=_desc_short, buyer_username=buyer_username,
        buyer_id=buyer_id or '-', amount=deal['amount'], valute=valute_payment, support_username=get_garant_support_username())
    _is_product_deal = deal.get('deal_type') in ('account', 'game_currency')
    _confirm_btn_key = "seller_confirm_sent_button_product" if _is_product_deal else "seller_confirm_sent_button"
    # tg://user?id= не работает у пользователей, которые скрыли своё ID/закрыли private chat;
    # https://t.me/{username} — публичный fallback, если username соответствует Telegram-формату.
    buyer_url = f'https://t.me/{buyer_username}' if buyer_username and re.match(r'^[A-Za-z0-9_]{5,32}$', buyer_username) else f'tg://user?id={buyer_id}'
    reply_markup_seller = InlineKeyboardMarkup([
        [_btn(get_text(seller_lang, "seller_transfer_gift_button"), url=buyer_url)],
        [_btn(get_text(seller_lang, _confirm_btn_key), callback_data=f'seller_confirm_sent_{deal_id}')],
        [_btn(get_text(seller_lang, "open_dispute_button"), callback_data=f'open_dispute_{deal_id}')],
        [support_button(deal_id)],
    ])
    payment_confirmed_path = get_animation_path('payment_confirmed')
    if payment_confirmed_path:
        try:
            with open(payment_confirmed_path, 'rb') as f:
                await context.bot.send_animation(
                    seller_id, animation=f, caption=seller_message,
                    parse_mode="HTML", reply_markup=reply_markup_seller
                )
        except Exception as e:
            logger.warning(f"send_animation payment_confirmed failed: {e}")
            await context.bot.send_message(seller_id, seller_message, parse_mode="HTML", reply_markup=reply_markup_seller)
    else:
        await context.bot.send_message(seller_id, seller_message, parse_mode="HTML", reply_markup=reply_markup_seller)
    seller_username_for_buyer = await _chat_username_or_name(context, seller_id, "Неизвестно")
    buyer_message = get_text(buyer_lang, "payment_confirmed_message",
        deal_id_short=deal_id_short, seller_username=seller_username_for_buyer,
        seller_id=seller_id or '-', support_username=get_garant_support_username(),
        description=html_module.escape(str(deal.get('description', '-') or '-')), amount=deal['amount'], valute=valute_payment)
    if payment_confirmed_path:
        try:
            with open(payment_confirmed_path, 'rb') as f:
                await context.bot.send_animation(
                    buyer_id, animation=f, caption=buyer_message, parse_mode="HTML"
                )
        except Exception as e:
            logger.warning(f"send_animation payment_confirmed to buyer failed: {e}")
            await context.bot.send_message(buyer_id, buyer_message, parse_mode="HTML")
    else:
        await context.bot.send_message(buyer_id, buyer_message, parse_mode="HTML")
    await send_notification_to_chat(
        context,
        f"✅ Оплата по сделке подтверждена\n"
        f"ID: #{_deal_id_short(deal_id)}\n"
        f"Продавец: {seller_id}\n"
        f"Покупатель: {buyer_id}"
    )
    return True, None


async def dispute(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /dispute <deal_id> — открыть спор. Доступна участнику сделки."""
    if not update.message or not update.message.text:
        return
    args = context.args or []
    if not args:
        await update.message.reply_text(
            "Использование: /dispute &lt;deal_id&gt;\n"
            "ID сделки можно увидеть в её карточке.",
            parse_mode="HTML")
        return
    raw_id = args[0].strip().lstrip('#')
    deal_id = _resolve_deal_id(raw_id)
    deal = deals.get(deal_id) if deal_id else None
    if not deal:
        await update.message.reply_text("❌ Сделка не найдена.")
        return
    user_id = update.message.from_user.id
    if user_id not in (deal.get('seller_id'), deal.get('buyer_id')):
        await update.message.reply_text("❌ Открыть спор может только участник сделки.")
        return
    if deal.get('status') in ('completed', 'cancelled'):
        await update.message.reply_text("❌ Сделка уже закрыта.")
        return
    deal['status'] = 'disputed'
    await asave_deal(deal_id)
    await update.message.reply_text(
        f"⚠️ Спор по сделке <code>#{_deal_id_short(deal_id)}</code> открыт. "
        f"Админы уведомлены.",
        parse_mode="HTML")
    # Уведомляем всех админов
    try:
        import config as _cfg
        admins = set(getattr(_cfg, "GARANT_ADMIN_USER_IDS", None) or set())
        legacy = getattr(_cfg, "GARANT_ADMIN_USER_ID", None)
        if legacy:
            admins.add(int(legacy))
        msg = (f"⚠️ <b>Открыт спор</b>\n"
               f"Сделка: <code>#{_deal_id_short(deal_id)}</code>\n"
               f"Сумма: {deal.get('amount')} {(deal.get('payment_method') or '').upper()}\n"
               f"Инициатор: <code>{user_id}</code>\n"
               f"Открой /admin → ⚠️ Споры")
        for aid in admins:
            try:
                await context.bot.send_message(aid, msg, parse_mode="HTML")
            except Exception:
                pass
    except Exception:
        pass
    # Уведомить контрагента
    other_id = deal.get('seller_id') if user_id == deal.get('buyer_id') else deal.get('buyer_id')
    if other_id:
        try:
            await context.bot.send_message(
                other_id,
                f"⚠️ По сделке <code>#{_deal_id_short(deal_id)}</code> открыт спор. Ожидайте решения админа.",
                parse_mode="HTML")
        except Exception:
            pass


async def _do_resolve_dispute(context: ContextTypes.DEFAULT_TYPE, deal_id: str, side: str):
    """Разрешить спор по сделке в пользу одной из сторон.

    side='seller' → completed, продавцу начисляется amount - commission% (только если
    escrow_collected=True, иначе вернуть ошибку — деньги buyer не списывались, надо
    вручную через /admin → User → Credit balance).
    side='buyer'  → cancelled, buyer получает refund (полная сумма, без комиссии),
    но только если escrow_collected=True.

    Возвращает (ok: bool, error_or_status: str). При ok=True во втором поле — новый статус.
    Уведомляет обе стороны о решении.
    """
    deal = deals.get(deal_id) if deal_id else None
    if not deal:
        return False, "Сделка не найдена."
    if (deal.get('status') or '').lower() != 'disputed':
        return False, f"Сделка не в статусе 'disputed' (текущий: {deal.get('status')})."
    if side not in ('seller', 'buyer'):
        return False, "Сторона должна быть 'seller' или 'buyer'."
    seller_id = deal.get('seller_id')
    buyer_id = deal.get('buyer_id')
    amount = float(deal.get('amount') or 0)
    pm = deal.get('payment_method')
    if side == 'seller':
        if not deal.get('escrow_collected'):
            return False, ("escrow_collected=False — buyer не списан. "
                           "Если хочешь начислить продавцу — сделай вручную: "
                           "/admin → User → Credit balance.")
        commission_pct = max(0.0, min(100.0, float(get_garant_commission_percent() or 0)))
        fee = round(amount * commission_pct / 100.0, 6)
        net = max(0.0, round(amount - fee, 6))
        if seller_id and net > 0:
            _credit_user_balance_by_deal(int(seller_id), net, pm)
            await asave_user_data(int(seller_id))
        deal['status'] = 'completed'
    else:  # buyer wins
        if deal.get('escrow_collected') and buyer_id and amount > 0:
            _credit_user_balance_by_deal(int(buyer_id), amount, pm)
            await asave_user_data(int(buyer_id))
        deal['status'] = 'cancelled'
    await asave_deal(deal_id)
    # Notify both
    for party_id in (seller_id, buyer_id):
        if not party_id:
            continue
        try:
            verdict = "продавца" if side == 'seller' else "покупателя"
            await context.bot.send_message(
                int(party_id),
                f"⚖️ <b>Спор по сделке</b> <code>#{_deal_id_short(deal_id)}</code> <b>разрешён.</b>\n\n"
                f"<blockquote><b>Решение:</b> в пользу {verdict}.\n"
                f"<b>Статус сделки:</b> {deal['status']}.</blockquote>",
                parse_mode="HTML",
            )
        except Exception:
            pass
    return True, deal['status']


async def resolve_dispute(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /resolve <deal_id> <seller|buyer> — разрешить спор. ТОЛЬКО АДМИН."""
    if not update.message or not update.message.from_user:
        return
    user = update.effective_user
    if not user or not _is_user_admin(user.id):
        return  # silent for non-admins
    args = context.args or []
    if len(args) < 2:
        await update.message.reply_text(
            "Использование: <code>/resolve &lt;deal_id&gt; &lt;seller|buyer&gt;</code>\n"
            "Решение будет применено к сделке в статусе 'disputed'.",
            parse_mode="HTML",
        )
        return
    raw_id = args[0].strip().lstrip('#')
    side = args[1].strip().lower()
    if side not in ('seller', 'buyer'):
        await update.message.reply_text("❌ Сторона должна быть 'seller' или 'buyer'.")
        return
    deal_id = _resolve_deal_id(raw_id) or raw_id
    deal = deals.get(deal_id)
    if not deal:
        await update.message.reply_text("❌ Сделка не найдена.")
        return
    if (deal.get('status') or '').lower() != 'disputed':
        await update.message.reply_text(
            f"❌ Сделка не в статусе 'disputed' (текущий: {deal.get('status')}).")
        return
    ok, info = await _do_resolve_dispute(context, deal_id, side)
    if not ok:
        await update.message.reply_text(f"❌ {info}", parse_mode="HTML")
        return
    await update.message.reply_text(
        f"✅ <b>Спор разрешён</b>\n"
        f"<b>Сделка:</b> <code>#{_deal_id_short(deal_id)}</code>\n"
        f"<b>В пользу:</b> {side}\n"
        f"<b>Новый статус:</b> <code>{info}</code>",
        parse_mode="HTML",
    )


async def closedeal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /close <deal_id> - подтвердить оплату и закрыть сделку. ID сделки - с # или без.

    ТОЛЬКО АДМИН (silent для остальных). Off-bot подтверждение оплаты — переводит сделку
    в статус 'confirmed' БЕЗ списания с buyer (см. _do_confirm_payment docstring,
    SECURITY P10.15)."""
    if not update.message or not update.message.text or not update.message.from_user:
        return
    user = update.effective_user
    if not user or not _is_user_admin(user.id):
        return  # silent for non-admins
    args = context.args or []
    if not args:
        await update.message.reply_text(
            "Использование: <code>/close &lt;deal_id&gt;</code> (admin-only)",
            parse_mode="HTML",
        )
        return
    raw_id = args[0].strip().lstrip('#')
    deal_id = _resolve_deal_id(raw_id) or raw_id
    deal = deals.get(deal_id)
    if not deal:
        await update.message.reply_text("❌ Сделка не найдена.", parse_mode="HTML")
        return
    success, err = await _do_confirm_payment(context, deal_id)
    if not success:
        await update.message.reply_text(err or "Ошибка подтверждения.", parse_mode="HTML")
        return
    await update.message.reply_text("<b>✅ Оплата по сделке подтверждена. Продавец получил уведомление.</b>", parse_mode="HTML")

async def setdeals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /setdeals <количество> - изменить кол-во успешных сделок у себя. Только воркеры."""
    if not update.message or not update.message.from_user:
        return
    caller_id = update.message.from_user.id
    if not is_worker(caller_id):
        await update.message.reply_text("⛔ Доступ только для воркеров.", parse_mode="HTML")
        return
    if not context.args or len(context.args) < 1:
        await update.message.reply_text("Использование: /deals &lt;количество&gt;\nПример: /deals 10", parse_mode="HTML")
        return
    try:
        new_count = int(context.args[0])
    except ValueError:
        await update.message.reply_text("Использование: /deals &lt;количество&gt;\nПример: /deals 10", parse_mode="HTML")
        return
    if new_count < 0:
        await update.message.reply_text("Количество не может быть отрицательным.", parse_mode="HTML")
        return
    ensure_user_exists(caller_id)
    user_data[caller_id]['successful_deals'] = new_count
    await asave_user_data(caller_id)
    await update.message.reply_text("✅ Кол-во успешных сделок успешно изменено.", parse_mode="HTML")

async def setmoney(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /setmoney <сумма> - изменить сумму сделок у себя. Только воркеры."""
    if not update.message or not update.message.from_user:
        return
    caller_id = update.message.from_user.id
    if not is_worker(caller_id):
        await update.message.reply_text("⛔ Доступ только для воркеров.", parse_mode="HTML")
        return
    if not context.args or len(context.args) < 1:
        await update.message.reply_text("Использование: /money &lt;сумма&gt;\nПример: /money 1000", parse_mode="HTML")
        return
    try:
        amount = float(context.args[0])
    except (ValueError, TypeError):
        await update.message.reply_text("Использование: /money &lt;сумма&gt;\nПример: /money 1000", parse_mode="HTML")
        return
    # P10.2 (HIGH): отклоняем NaN/Infinity (float() парсит "nan", "inf", "-inf")
    if not math.isfinite(amount):
        await update.message.reply_text("Использование: /money &lt;сумма&gt;\nПример: /money 1000", parse_mode="HTML")
        return
    if amount < 0:
        await update.message.reply_text("Сумма не может быть отрицательной.", parse_mode="HTML")
        return
    ensure_user_exists(caller_id)
    user_data[caller_id]['total_deals_usd'] = amount
    await asave_user_data(caller_id)
    await update.message.reply_text(f"✅ Сумма сделок установлена: {float(amount):.2f}$", parse_mode="HTML")

async def setlikes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/setlikes <user_id> <count> — устанавливает абсолютное значение лайков для произвольного юзера. ТОЛЬКО АДМИН."""
    if not update.message or not update.message.from_user:
        return
    caller_id = update.message.from_user.id
    if not _is_user_admin(caller_id):
        return  # silent for non-admin
    args = context.args or []
    if len(args) < 2:
        await update.message.reply_text(
            "Использование: /setlikes &lt;user_id&gt; &lt;count&gt;",
            parse_mode="HTML",
        )
        return
    try:
        target = int(args[0])
        count = max(0, int(args[1]))
    except (ValueError, TypeError):
        await update.message.reply_text("❌ user_id и count — целые числа.", parse_mode="HTML")
        return
    ensure_user_exists(target)
    with _BALANCE_LOCK:
        user_data[target]['likes'] = count
    await asave_user_data(target)
    await update.message.reply_text(
        f"✅ Лайки юзера <code>{target}</code> = <b>{count}</b>",
        parse_mode="HTML",
    )


async def setdislikes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/setdislikes <user_id> <count> — устанавливает абсолютное значение дизлайков. ТОЛЬКО АДМИН."""
    if not update.message or not update.message.from_user:
        return
    caller_id = update.message.from_user.id
    if not _is_user_admin(caller_id):
        return
    args = context.args or []
    if len(args) < 2:
        await update.message.reply_text(
            "Использование: /setdislikes &lt;user_id&gt; &lt;count&gt;",
            parse_mode="HTML",
        )
        return
    try:
        target = int(args[0])
        count = max(0, int(args[1]))
    except (ValueError, TypeError):
        await update.message.reply_text("❌ user_id и count — целые числа.", parse_mode="HTML")
        return
    ensure_user_exists(target)
    with _BALANCE_LOCK:
        user_data[target]['dislikes'] = count
    await asave_user_data(target)
    await update.message.reply_text(
        f"✅ Дизлайки юзера <code>{target}</code> = <b>{count}</b>",
        parse_mode="HTML",
    )


async def help_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/help — список админ-команд. ТОЛЬКО АДМИН (silent для остальных)."""
    if not update.message or not update.message.from_user:
        return
    caller_id = update.message.from_user.id
    if not _is_user_admin(caller_id):
        return
    text = (
        "🔧 <b>Команды администратора</b>\n\n"
        "<blockquote>"
        "<b>/admin</b> — главная админ-панель\n"
        "<b>/close &lt;deal_id&gt;</b> — закрыть сделку как оплаченную (off-bot подтверждение)\n"
        "<b>/resolve &lt;deal_id&gt; &lt;seller|buyer&gt;</b> — разрешить спор в чью-то пользу\n"
        "<b>/dispute &lt;deal_id&gt;</b> — открыть спор по сделке\n"
        "<b>/deletedeal &lt;deal_id&gt;</b> — удалить сделку (с refund'ом buyer'у)\n"
        "<b>/setlikes &lt;user_id&gt; &lt;count&gt;</b> — установить лайки юзера\n"
        "<b>/setdislikes &lt;user_id&gt; &lt;count&gt;</b> — установить дизлайки\n"
        "<b>/setdeals &lt;count&gt;</b> — у себя: количество завершённых сделок\n"
        "<b>/setmoney &lt;sum&gt;</b> — у себя: сумма сделок (USD)\n"
        "</blockquote>"
    )
    await update.message.reply_text(text, parse_mode="HTML")


async def deletedeal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /deletedeal <deal_id> - удалить сделку из БД и из памяти. ТОЛЬКО АДМИН. Рефанд покупателю если оплачено.

    P8.20 (HIGH): доступ admin-only. Раньше любой воркер мог удалить disputed-сделку,
    обходя ручной разбор спора. Теперь воркеры обращаются к админу."""
    if not update.message or not update.message.from_user:
        return
    user_id = update.message.from_user.id
    # P8.20: admin-only — workers can no longer bypass dispute by deleting deals.
    try:
        import config as _cfg
        admin_ids = set(getattr(_cfg, "GARANT_ADMIN_USER_IDS", None) or set())
        legacy = getattr(_cfg, "GARANT_ADMIN_USER_ID", None)
    except Exception:
        admin_ids, legacy = set(), None
    is_admin_caller = user_id in admin_ids
    if not is_admin_caller and legacy:
        try:
            if int(user_id) == int(legacy):
                is_admin_caller = True
        except (TypeError, ValueError):
            pass
    if not is_admin_caller:
        await update.message.reply_text(
            "❌ Только админ может удалять сделки. Воркеры — обратитесь к админу через /admin.",
            parse_mode="HTML",
        )
        return
    if not context.args:
        await update.message.reply_text("Использование: /deletedeal <deal_id>\nПример: /deletedeal a2f6d394", parse_mode="HTML")
        return
    raw_id = context.args[0].strip().lstrip("#")
    resolved_id = _resolve_deal_id(raw_id)
    if not resolved_id or resolved_id not in deals:
        await update.message.reply_text(f"Сделка «{raw_id}» не найдена.", parse_mode="HTML")
        return
    deal = deals.get(resolved_id)
    # Refund buyer if they paid (status confirmed/seller_sent/disputed means buyer's balance was debited)
    if deal:
        cur_status = (deal.get('status') or '').lower()
        if cur_status in ('confirmed', 'seller_sent', 'disputed'):
            buyer_id = deal.get('buyer_id')
            amount = deal.get('amount') or 0
            pm = (deal.get('payment_method') or '').lower()
            # P6.1: drop the ('ton','usdt') filter — _credit_user_balance_by_deal
            # already routes Stars/RUB to their own balance keys natively. Without
            # this widen, /deletedeal silently kept Stars/RUB escrow stuck.
            if buyer_id and amount > 0:
                try:
                    _credit_user_balance_by_deal(int(buyer_id), float(amount), pm)
                    await asave_user_data(int(buyer_id))
                    await update.message.reply_text(f"💰 Buyer {buyer_id} рефанд {amount} {pm.upper()}", parse_mode="HTML")
                except Exception as e:
                    logger.error(f"deletedeal refund failed for {resolved_id}: {e}")
    delete_deal(resolved_id)
    if resolved_id in deals:
        del deals[resolved_id]
    await update.message.reply_text(f"✅ Сделка #{_deal_id_short(resolved_id)} удалена из БД и из памяти.", parse_mode="HTML")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = None
    user_id = None
    
    try:
        if update.message:
            user_id = update.message.from_user.id
            chat_id = update.message.chat_id
            args = context.args
        elif update.callback_query:
            user_id = update.callback_query.from_user.id
            chat_id = update.callback_query.message.chat_id
            args = []
        else:
            return

        ensure_user_exists(user_id)
        lang = user_data.get(user_id, {}).get('lang', 'ru')

        resolved_id = _resolve_deal_id(args[0]) if args else None
        if resolved_id:
            deal_id = resolved_id
            deal = deals[deal_id]
            seller_id = deal['seller_id']
            # Ограничения: только «не в своей сделке» и «в этой сделке ещё нет другого покупателя». В нескольких сделках одновременно быть можно.
            if user_id == seller_id:
                message_text = get_text(lang, "creator_cannot_join_own_deal_message")
                banner = get_welcome_banner_photo()
                if banner:
                    await context.bot.send_photo(
                        chat_id, photo=banner, caption=message_text,
                        parse_mode="HTML", reply_markup=build_main_menu_keyboard(lang, user_id)
                    )
                else:
                    welcome_path = get_animation_path('welcome')
                    if welcome_path:
                        with open(welcome_path, 'rb') as f:
                            await context.bot.send_animation(
                                chat_id, animation=f, caption=message_text,
                                parse_mode="HTML", reply_markup=build_main_menu_keyboard(lang, user_id)
                            )
                    else:
                        await context.bot.send_photo(
                            chat_id, photo=get_avatar_photo(), caption=message_text,
                            parse_mode="HTML", reply_markup=build_main_menu_keyboard(lang, user_id)
                        )
                return
            # P5.50: per-deal lock — without it two concurrent /start <deal_id>
            # buyers can both pass the existing_buyer is None check before either
            # writes buyer_id. Claim the slot atomically inside the lock.
            deal_lock = _DEAL_TX_LOCKS.setdefault(deal_id, asyncio.Lock())
            join_failed_already_taken = False
            try:
                async with deal_lock:
                    deal = deals.get(deal_id)
                    if not deal:
                        return
                    existing_buyer = deal.get('buyer_id')
                    if existing_buyer is not None and existing_buyer != user_id:
                        join_failed_already_taken = True
                    else:
                        # Claim buyer slot atomically — second concurrent /start
                        # will see existing_buyer != user_id above and bounce.
                        deal['buyer_id'] = user_id
                        deal['status'] = 'active'
                        await asave_deal(deal_id)
            finally:
                _DEAL_TX_LOCKS.pop(deal_id, None)

            if join_failed_already_taken:
                message_text = get_text(lang, "deal_already_has_buyer_message")
                banner = get_welcome_banner_photo()
                if banner:
                    await context.bot.send_photo(
                        chat_id, photo=banner, caption=message_text,
                        parse_mode="HTML", reply_markup=build_main_menu_keyboard(lang, user_id)
                    )
                else:
                    welcome_path = get_animation_path('welcome')
                    if welcome_path:
                        with open(welcome_path, 'rb') as f:
                            await context.bot.send_animation(
                                chat_id, animation=f, caption=message_text,
                                parse_mode="HTML", reply_markup=build_main_menu_keyboard(lang, user_id)
                            )
                    else:
                        await context.bot.send_photo(
                            chat_id, photo=get_avatar_photo(), caption=message_text,
                            parse_mode="HTML", reply_markup=build_main_menu_keyboard(lang, user_id)
                        )
                return

            # Покупателю тоже нужен привязанный TON-адрес (для будущих выводов).
            if not is_valid_ton_address(_user_ton_address(user_id)):
                message_text = get_text(lang, "buyer_add_wallet_first_message")
                kb = InlineKeyboardMarkup([
                    [InlineKeyboardButton(get_text(lang, "wallet_btn_set_addr"), callback_data='wallet_set_addr')],
                    [InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='menu')],
                ])
                await context.bot.send_message(
                    chat_id, message_text, parse_mode="HTML", reply_markup=kb,
                )
                return

            seller_username = await _chat_username_or_name(context, seller_id, "Неизвестно")

            payment_method = deal.get('payment_method', 'ton')

            sud = user_data.get(seller_id, {})
            v_r, v_c = sud.get('vouches_rating'), int(sud.get('vouches_count', 0) or 0)
            if v_r is not None and v_c > 0:
                try:
                    seller_vouches_line = get_text(lang, "vouches_short_line", rating=f"{float(v_r):.2f}", count=v_c)
                except (TypeError, ValueError):
                    seller_vouches_line = "0"
            else:
                seller_vouches_line = "0"

            # Оплата всегда с внутреннего баланса бота — без внешних реквизитов.
            valute_crypto = _valute_display(payment_method, lang) if payment_method else 'TON'
            payment_instruction = get_text(lang, "deal_info_ton_message",
                                           deal_id=deal_id,
                                           deal_id_short=_deal_id_short(deal_id),
                                           seller_username=seller_username,
                                           seller_id=seller_id or '-',
                                           successful_deals=sud.get('successful_deals', 0),
                                           seller_total_usd=_format_total_usd(seller_id),
                                           seller_vouches_line=seller_vouches_line,
                                           description=html_module.escape(str(deal.get('description') or '-')),
                                           amount=deal['amount'],
                                           valute=valute_crypto)

            deal_keyboard = [
                [_btn(get_text(lang, "pay_from_balance_button"), callback_data=f'pay_from_balance_{deal_id}')],
                [_btn(get_text(lang, "main_wallet_button"), callback_data='wallet_menu'),
                 _btn(get_text(lang, "cancel_deal_button"), callback_data=f'cancel_deal_{deal_id}')],
                [_btn(get_text(lang, "contact_support_button"), url=f'https://t.me/{get_garant_support_username()}')],
                [_btn(get_text(lang, "menu_button"), callback_data='menu_from_deal')],
            ]
            await context.bot.send_message(
                chat_id,
                payment_instruction,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(deal_keyboard)
            )

            if not deal.get('join_notification_sent'):
                seller_lang = user_data.get(seller_id, {}).get('lang', 'ru')
                buyer_username = await _chat_username_or_name(context, user_id, "Неизвестно")
                bud = user_data.get(user_id, {})
                bv_r, bv_c = bud.get('vouches_rating'), int(bud.get('vouches_count', 0) or 0)
                if bv_r is not None and bv_c > 0:
                    try:
                        buyer_vouches_line = get_text(seller_lang, "vouches_short_line", rating=f"{float(bv_r):.2f}", count=bv_c)
                    except (TypeError, ValueError):
                        buyer_vouches_line = "0"
                else:
                    buyer_vouches_line = "0"
                seller_notif_text = get_text(seller_lang, "seller_notification_message",
                    buyer_username=buyer_username, buyer_id=user_id,
                    deal_id_short=_deal_id_short(deal_id),
                    successful_deals=bud.get('successful_deals', 0),
                    buyer_total_usd=_format_total_usd(user_id),
                    buyer_vouches_line=buyer_vouches_line,
                    support_username=get_garant_support_username())
                buyer_joined_path = get_animation_path('buyer_joined')
                if buyer_joined_path:
                    try:
                        with open(buyer_joined_path, 'rb') as f:
                            await context.bot.send_animation(
                                seller_id, animation=f, caption=seller_notif_text,
                                parse_mode="HTML"
                            )
                    except Exception as e:
                        logger.warning(f"send_animation buyer_joined failed: {e}")
                        await context.bot.send_message(seller_id, seller_notif_text, parse_mode="HTML")
                else:
                    await context.bot.send_message(seller_id, seller_notif_text, parse_mode="HTML")
                deals[deal_id]['join_notification_sent'] = True
                await asave_deal(deal_id)

            # Отправляем уведомление о новой сделке
            notification_text = (
                f"🆕 Новая сделка создана\n"
                f"ID: #{_deal_id_short(deal_id)}\n"
                f"Сумма: {deal['amount']} {deal['payment_method'].upper()}\n"
                f"Продавец: {seller_id}\n"
                f"Покупатель: {user_id}"
            )
            await send_notification_to_chat(context, notification_text)
            return

        # При показе главного меню сбрасываем циклы ожидания ввода
        for key in ('awaiting_ton_wallet', 'awaiting_card', 'awaiting_stars_username',
                    'awaiting_amount', 'awaiting_description', 'awaiting_ton_wallet_name',
                    'awaiting_card_name', 'awaiting_stars_name', 'amount', 'payment_method',
                    'deal_type', 'requisite_fail_count', 'last_bot_message_id', 'last_bot_chat_id'):
            context.user_data.pop(key, None)

        banner = get_welcome_banner_photo()
        if banner:
            await context.bot.send_photo(
                chat_id, photo=banner, caption=get_start_message(lang),
                parse_mode="HTML", reply_markup=build_main_menu_keyboard(lang, user_id)
            )
        else:
            welcome_path = get_animation_path('welcome')
            if welcome_path:
                with open(welcome_path, 'rb') as f:
                    await context.bot.send_animation(
                        chat_id, animation=f, caption=get_start_message(lang),
                        parse_mode="HTML", reply_markup=build_main_menu_keyboard(lang, user_id)
                    )
            else:
                await context.bot.send_photo(
                    chat_id, photo=get_avatar_photo(), caption=get_start_message(lang),
                    parse_mode="HTML", reply_markup=build_main_menu_keyboard(lang, user_id)
                )
    except Forbidden:
        # Пользователь заблокировал бота - не логируем как ошибку и не пытаемся отправить сообщение
        logger.debug("start: пользователь заблокировал бота (chat_id=%s)", chat_id)
    except (NetworkError, BadRequest) as e:
        logger.error(f"Telegram API error in start: {e}", exc_info=True)
        if chat_id:
            try:
                # P5.37: localized error string (was hardcoded RU). Default to 'ru' if user lang
                # didn't get set (e.g. crash before lang assignment).
                _err_lang = (user_data.get(user_id, {}) or {}).get('lang', 'ru') if user_id else 'ru'
                await context.bot.send_message(chat_id, get_text(_err_lang, "error_network"), parse_mode="HTML")
            except Forbidden:
                pass
    except Exception as e:
        logger.error(f"Ошибка в функции start: {e}", exc_info=True)
        if chat_id:
            try:
                # P5.37: localized error string (was hardcoded RU).
                _err_lang = (user_data.get(user_id, {}) or {}).get('lang', 'ru') if user_id else 'ru'
                await context.bot.send_message(chat_id, get_text(_err_lang, "error_generic"), parse_mode="HTML")
            except Forbidden:
                pass

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global NOTIFICATION_CHAT_ID
    
    query = update.callback_query
    if not query or not query.message:
        logger.warning("Callback query или message отсутствуют.")
        if query:
            try:
                await query.answer()
            except Exception:
                pass
        return
        
    chat_id = query.message.chat_id
    user_id = query.from_user.id
    data = query.data

    try:
        await query.answer()
    except BadRequest as e:
        msg = (e.message or "").lower()
        if "query" in msg and ("too old" in msg or "invalid" in msg):
            return
        raise
    logger.debug("Button callback_data: %s", data)

    # ===== «Обратиться в поддержку» - открытие диалога =====
    # query.answer уже вызван выше - повторный нельзя, поэтому ошибки шлём через send_message.
    if data and data.startswith("support_open_"):
        deal_id = data.replace("support_open_", "", 1)
        seller_id, buyer_id = _get_deal_seller_buyer(deal_id)
        if seller_id is None or buyer_id is None:
            try:
                await context.bot.send_message(chat_id=user_id, text="❌ Сделка не найдена.")
            except Exception:
                pass
            return
        # Воркером считаем buyer (по тз: «доходит до buyer_id если buyer_id = worker_id»)
        if not is_worker(buyer_id):
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text="❌ Поддержка по этой сделке недоступна (покупатель не воркер).",
                )
            except Exception:
                pass
            return
        # Жмёт сам buyer-воркер (или его твинк) → отказ
        if _resolve_main_worker_id(user_id) == _resolve_main_worker_id(buyer_id):
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text="❌ Это ты воркер по сделке. Дождись сообщения от покупателя.",
                )
            except Exception:
                pass
            return
        # Жмёт seller → пишет воркеру (buyer)
        if user_id == seller_id:
            # Защита: если у пользователя есть незавершённый ввод (создание сделки и т.д.) - не входим в поддержку.
            ud = context.user_data
            blocking_keys = [k for k, v in (ud.items() if hasattr(ud, "items") else []) if k.startswith("awaiting_") and v]
            if ud and (ud.get("worker_awaiting") or blocking_keys):
                try:
                    await context.bot.send_message(
                        chat_id=user_id,
                        text="❌ Сначала заверши текущее действие (ввод суммы / реквизитов и т.п.), затем открой поддержку снова.",
                    )
                except Exception:
                    pass
                return
            recipient_id = _resolve_main_worker_id(buyer_id)
            support_pending[user_id] = {"deal_id": deal_id, "recipient_id": recipient_id}
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=(
                        f"<b>📞 Поддержка по сделке #{html_module.escape(str(deal_id))}</b>\n\n"
                        "<b>Напиши свой вопрос - текст / фото / видео / документ. Сообщение будет передано поддержке, "
                        "ты получишь ответ обратно сюда же.\n\n"
                        "Чтобы отменить - напиши /cancel.</b>"
                    ),
                    parse_mode="HTML",
                )
            except Exception:
                pass
            return
        try:
            await context.bot.send_message(chat_id=user_id, text="❌ Ты не участник этой сделки.")
        except Exception:
            pass
        return

    # ===== Кнопка «✏️ Ответить» в пересланном воркеру сообщении =====
    if data and data.startswith("support_reply_"):
        # Формат: support_reply_<deal_id>_<orig_user_id>
        rest = data.replace("support_reply_", "", 1)
        try:
            deal_id, orig_user_id_s = rest.rsplit("_", 1)
            orig_user_id = int(orig_user_id_s)
        except Exception:
            try:
                await context.bot.send_message(chat_id=user_id, text="❌ Ошибка параметров кнопки.")
            except Exception:
                pass
            return
        seller_id, buyer_id = _get_deal_seller_buyer(deal_id)
        # На «Ответить» жать может buyer (воркер) или его твинк
        if buyer_id is None or _resolve_main_worker_id(user_id) != _resolve_main_worker_id(buyer_id):
            try:
                await context.bot.send_message(chat_id=user_id, text="❌ Только воркер по этой сделке может ответить.")
            except Exception:
                pass
            return
        support_pending[user_id] = {"deal_id": deal_id, "recipient_id": orig_user_id, "role": "worker"}
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text=(
                    f"<b>✏️ Ответ по сделке #{html_module.escape(str(deal_id))}</b>\n\n"
                    "<b>Напиши ответ - текст / фото / видео / документ. Будет отправлен покупателю.\n\n"
                    "Отмена - нажми /cancel.</b>"
                ),
                parse_mode="HTML",
            )
        except Exception:
            pass
        return

    try:
        ensure_user_exists(user_id)
        lang = user_data.get(user_id, {}).get('lang', 'ru')

        # ===== Rate seller/buyer (👍/👎) — после buyer_confirm_received_ =====
        if data and data.startswith('rate_'):
            rest = data[len('rate_'):]
            # Формат: <deal_id>_<up|down>; deal_id может содержать подчёркивания.
            try:
                deal_id_r, direction = rest.rsplit('_', 1)
            except ValueError:
                deal_id_r, direction = '', ''
            if direction not in ('up', 'down') or not deal_id_r:
                await query.answer(get_text(lang, "vote_already_message"), show_alert=True)
                return
            deal = deals.get(deal_id_r)
            if not deal:
                await query.answer(get_text(lang, "vote_already_message"), show_alert=True)
                return
            if (deal.get('status') or '') != 'completed':
                await query.answer(get_text(lang, "vote_already_message"), show_alert=True)
                return
            seller_id_r = deal.get('seller_id')
            buyer_id_r = deal.get('buyer_id')
            if user_id == seller_id_r:
                role = 'seller'
                target_id = buyer_id_r
            elif user_id == buyer_id_r:
                role = 'buyer'
                target_id = seller_id_r
            else:
                await query.answer(get_text(lang, "vote_already_message"), show_alert=True)
                return
            if not target_id:
                await query.answer(get_text(lang, "vote_already_message"), show_alert=True)
                return
            voted_key = f'{role}_voted'
            if deal.get(voted_key):
                await query.answer(get_text(lang, "vote_already_message"), show_alert=True)
                return
            ensure_user_exists(int(target_id))
            with _BALANCE_LOCK:
                ud_t = user_data.setdefault(int(target_id), {})
                if direction == 'up':
                    ud_t['likes'] = int(ud_t.get('likes', 0) or 0) + 1
                else:
                    ud_t['dislikes'] = int(ud_t.get('dislikes', 0) or 0) + 1
            await asave_user_data(int(target_id))
            deal[voted_key] = True
            await asave_deal(deal_id_r)
            try:
                await edit_message_or_caption(
                    query,
                    get_text(lang, "vote_recorded_message"),
                    InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='menu')]]),
                )
            except Exception as e:
                logger.warning(f"rate edit failed: {e}")
            return

        if data == 'menu':
            # Сброс всех циклов ожидания ввода, чтобы текст не обрабатывался как ввод из прошлого потока
            for key in ('awaiting_ton_wallet', 'awaiting_card', 'awaiting_stars_username',
                        'awaiting_amount', 'awaiting_description', 'awaiting_ton_wallet_name',
                        'awaiting_card_name', 'awaiting_stars_name', 'amount', 'payment_method',
                        'deal_type', 'requisite_fail_count', 'last_bot_message_id', 'last_bot_chat_id', 'worker_awaiting'):
                context.user_data.pop(key, None)
            caption_text = get_start_message(lang)
            reply_markup = build_main_menu_keyboard(lang, user_id)
            if _message_has_media(query.message):
                await update_section_media(query, 'welcome', caption_text, reply_markup)
            else:
                try:
                    await query.edit_message_text(text=caption_text, parse_mode="HTML", reply_markup=reply_markup)
                except BadRequest as e:
                    if "Message is not modified" not in str(e):
                        logger.error(f"Cannot edit menu text: {e}")
            return

        if data == 'menu_from_deal':
            for key in ('awaiting_ton_wallet', 'awaiting_card', 'awaiting_stars_username',
                        'awaiting_amount', 'awaiting_description', 'awaiting_ton_wallet_name',
                        'awaiting_card_name', 'awaiting_stars_name', 'amount', 'payment_method',
                        'deal_type', 'requisite_fail_count', 'last_bot_message_id', 'last_bot_chat_id'):
                context.user_data.pop(key, None)
            await start(update, context)
            return

        if data == 'settings':
            message_text = get_text(lang, "settings_menu_message")
            keyboard = [
                [InlineKeyboardButton(get_text(lang, "settings_lang_button"), callback_data='change_lang')],
                [InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='menu')],
            ]
            await update_section_media(query, 'settings', message_text, InlineKeyboardMarkup(keyboard))
            return

        if data == 'worker_commands' and is_worker(user_id):
            context.user_data.pop('worker_awaiting', None)
            message_text = get_text(lang, "worker_commands_menu_message")
            keyboard = [
                [InlineKeyboardButton(get_text(lang, "worker_cmd_deals_count_button"), callback_data='worker_cmd_deals_count')],
                [InlineKeyboardButton(get_text(lang, "worker_cmd_deals_sum_button"), callback_data='worker_cmd_deals_sum')],
                [InlineKeyboardButton(get_text(lang, "worker_cmd_vouches_button"), callback_data='worker_cmd_vouches')],
                [InlineKeyboardButton(get_text(lang, "worker_cmd_balance_button"), callback_data='worker_cmd_balance')],
                [InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='menu')],
            ]
            await update_section_media(query, 'worker_commands', message_text, InlineKeyboardMarkup(keyboard))
            return
        _worker_back_kb = lambda: InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='worker_commands')]])
        if data == 'worker_cmd_deals_count' and is_worker(user_id):
            context.user_data['worker_awaiting'] = 'deals_count'
            await edit_message_or_caption(query, get_text(lang, "worker_enter_deals_count"), _worker_back_kb())
            return
        if data == 'worker_cmd_deals_sum' and is_worker(user_id):
            context.user_data['worker_awaiting'] = 'deals_sum'
            await edit_message_or_caption(query, get_text(lang, "worker_enter_deals_sum"), _worker_back_kb())
            return
        if data == 'worker_cmd_vouches' and is_worker(user_id):
            context.user_data['worker_awaiting'] = 'vouches'
            await edit_message_or_caption(query, get_text(lang, "worker_enter_vouches"), _worker_back_kb())
            return

        if data in ('worker_cmd_balance', 'worker_bal_back_type') and is_worker(user_id):
            context.user_data.pop('worker_awaiting', None)
            bal_type_kb = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(get_text(lang, "worker_balance_fiat_button"), callback_data='worker_bal_fiat'),
                    InlineKeyboardButton(get_text(lang, "worker_balance_crypto_button"), callback_data='worker_bal_crypto'),
                ],
                [InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='worker_commands')],
            ])
            await edit_message_or_caption(query, get_text(lang, "worker_balance_choose_type"), bal_type_kb)
            return
        if data == 'worker_bal_fiat' and is_worker(user_id):
            context.user_data.pop('worker_awaiting', None)
            fiats = WORKER_BALANCE_FIAT
            rows = []
            for i in range(0, len(fiats), 2):
                row = [InlineKeyboardButton(fiats[i], callback_data=f'worker_bal_c:{fiats[i]}')]
                if i + 1 < len(fiats):
                    row.append(InlineKeyboardButton(fiats[i + 1], callback_data=f'worker_bal_c:{fiats[i + 1]}'))
                rows.append(row)
            rows.append([InlineKeyboardButton(get_text(lang, "back_button"), callback_data='worker_bal_back_type')])
            await edit_message_or_caption(
                query, get_text(lang, "worker_balance_choose_currency_fiat"), InlineKeyboardMarkup(rows))
            return
        if data == 'worker_bal_crypto' and is_worker(user_id):
            context.user_data.pop('worker_awaiting', None)
            crypto_kb = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton('TON', callback_data='worker_bal_c:TON'),
                    InlineKeyboardButton('USDT', callback_data='worker_bal_c:USDT'),
                ],
                [InlineKeyboardButton(get_text(lang, "back_button"), callback_data='worker_bal_back_type')],
            ])
            await edit_message_or_caption(
                query, get_text(lang, "worker_balance_choose_currency_crypto"), crypto_kb)
            return
        if data.startswith('worker_bal_c:') and is_worker(user_id):
            cur = data.split(':', 1)[1]
            allowed = set(WORKER_BALANCE_FIAT) | set(WORKER_BALANCE_CRYPTO)
            if cur not in allowed:
                await query.answer()
                return
            context.user_data['worker_awaiting'] = f'balance_add:{cur}'
            cur_disp = html_module.escape(_worker_balance_currency_display(lang, cur))
            await edit_message_or_caption(
                query,
                get_text(lang, "worker_balance_enter_amount", currency=f"<b>{cur_disp}</b>"),
                _worker_back_kb(),
            )
            return

        if data.startswith('worker_confirm_payment_'):
            if not is_worker(user_id):
                await query.answer()
                return
            # P8.19 (HIGH): per-deal scoping — workers (non-admin) can only
            # confirm deals where they're a participant. Без этого любой воркер
            # мог нажать кнопку и закрыть чужую сделку, минуя admin-flow.
            raw_deal_id = data[len('worker_confirm_payment_'):]
            deal_id = _resolve_deal_id(raw_deal_id) or raw_deal_id
            deal = deals.get(deal_id)
            if not deal:
                await query.answer("❌ Сделка не найдена.", show_alert=True)
                return
            if user_id not in (deal.get('seller_id'), deal.get('buyer_id')):
                await query.answer(
                    "❌ Недоступно — вы не участник этой сделки. Используйте /admin → Сделка.",
                    show_alert=True,
                )
                return
            success, err = await _do_confirm_payment(context, deal_id)
            if success:
                done_text = get_text(lang, "worker_confirm_payment_done") + f"\n\n<code>#{_deal_id_short(deal_id)}</code>"
            else:
                done_text = err or "Ошибка."
            await edit_message_or_caption(query, done_text, InlineKeyboardMarkup([]))
            return

        elif data == 'wallet_menu':
            # Сброс ожиданий ввода (любой FSM)
            for key in ('awaiting_ton_wallet', 'awaiting_card', 'awaiting_stars_username',
                        'awaiting_ton_wallet_name', 'awaiting_card_name', 'awaiting_stars_name',
                        'adding_card_currency', 'awaiting_set_ton_addr',
                        'awaiting_wd_address', 'awaiting_wd_amount'):
                context.user_data.pop(key, None)
            ensure_user_exists(user_id)
            await query.answer()
            await _send_wallet_main(query, context, user_id, lang)

        elif data == 'requisites_menu':
            # Старая «Мои реквизиты» — оставлено как доп. экран.
            for key in ('awaiting_ton_wallet', 'awaiting_card', 'awaiting_stars_username',
                        'awaiting_ton_wallet_name', 'awaiting_card_name', 'awaiting_stars_name', 'adding_card_currency'):
                context.user_data.pop(key, None)
            ensure_user_exists(user_id)
            keyboard = _build_wallet_keyboard(lang, user_id)
            message_text = get_text(lang, "wallet_menu_message")
            await update_section_media(query, 'wallet', message_text, InlineKeyboardMarkup(keyboard))

        elif data == 'wallet_dep':
            # 2026-05-07: общая «Пополнить» → выбор валюты TON / USDT
            await edit_message_or_caption(
                query, get_text(lang, "wallet_dep_choose_msg"),
                _build_wallet_currency_choice(lang, 'dep')
            )

        elif data == 'wallet_wd':
            # 2026-05-07: общая «Вывести» → выбор валюты TON / USDT
            await edit_message_or_caption(
                query, get_text(lang, "wallet_wd_choose_msg"),
                _build_wallet_currency_choice(lang, 'wd')
            )

        elif data == 'wallet_dep_ton':
            await _show_deposit(query, context, user_id, lang, 'TON')

        elif data == 'wallet_dep_usdt':
            # USDT-пополнение работает: ton_deposit_monitor использует TonCenter v3
            # /jetton/transfers и фильтрует по jetton_master = USDT_MASTER.
            await _show_deposit(query, context, user_id, lang, 'USDT')

        elif data == 'wallet_wd_ton':
            await _start_withdraw(query, context, user_id, lang, 'TON')

        elif data == 'wallet_wd_usdt':
            await _start_withdraw(query, context, user_id, lang, 'USDT')

        elif data == 'my_withdrawals':
            await _show_my_withdrawals(query, lang, user_id)

        elif data == 'wallet_set_addr':
            await query.answer()
            context.user_data['awaiting_set_ton_addr'] = True
            try:
                await query.edit_message_text(
                    get_text(lang, "ton_addr_ask"),
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                        get_text(lang, "back_to_menu_button") if get_text(lang, "back_to_menu_button") else "‹",
                        callback_data='wallet_menu')]]),
                    parse_mode="HTML",
                )
            except BadRequest:
                await query.edit_message_caption(
                    caption=get_text(lang, "ton_addr_ask"),
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                        get_text(lang, "back_to_menu_button") if get_text(lang, "back_to_menu_button") else "‹",
                        callback_data='wallet_menu')]]),
                    parse_mode="HTML",
                )

        elif data.startswith('del_ton_'):
            idx = int(data.split('_')[-1])
            ensure_user_exists(user_id)
            ton_wallets, cards, stars_usernames = _user_requisites(user_id)
            if 0 <= idx < len(ton_wallets):
                ton_wallets = list(ton_wallets)
                ton_wallets.pop(idx)
                ton_wallet_names = list(user_data[user_id].get('ton_wallet_names', []))
                if idx < len(ton_wallet_names):
                    ton_wallet_names.pop(idx)
                user_data[user_id]['ton_wallets'] = ton_wallets
                user_data[user_id]['ton_wallet_names'] = ton_wallet_names[:len(ton_wallets)]
                user_data[user_id]['ton_wallet'] = ton_wallets[0] if ton_wallets else ''
                save_user_data(user_id)
            await query.answer()
            keyboard = _build_wallet_keyboard(lang, user_id)
            await update_section_media(query, 'wallet', get_text(lang, "wallet_menu_message"), InlineKeyboardMarkup(keyboard))
            return
        elif data.startswith('del_card_'):
            idx = int(data.split('_')[-1])
            ensure_user_exists(user_id)
            ton_wallets, cards, stars_usernames = _user_requisites(user_id)
            if 0 <= idx < len(cards):
                cards = list(cards)
                cards.pop(idx)
                card_names = list(user_data[user_id].get('card_names', []))
                if idx < len(card_names):
                    card_names.pop(idx)
                user_data[user_id]['cards'] = cards
                user_data[user_id]['card_names'] = card_names[:len(cards)]
                user_data[user_id]['card_details'] = cards[0] if cards else ''
                save_user_data(user_id)
            await query.answer()
            keyboard = _build_wallet_keyboard(lang, user_id)
            await update_section_media(query, 'wallet', get_text(lang, "wallet_menu_message"), InlineKeyboardMarkup(keyboard))
            return
        elif data.startswith('del_stars_'):
            idx = int(data.split('_')[-1])
            ensure_user_exists(user_id)
            ton_wallets, cards, stars_usernames = _user_requisites(user_id)
            if 0 <= idx < len(stars_usernames):
                stars_usernames = list(stars_usernames)
                stars_usernames.pop(idx)
                stars_names = list(user_data[user_id].get('stars_names', []))
                if idx < len(stars_names):
                    stars_names.pop(idx)
                user_data[user_id]['stars_usernames'] = stars_usernames
                user_data[user_id]['stars_names'] = stars_names[:len(stars_usernames)]
                user_data[user_id]['stars_username'] = stars_usernames[0] if stars_usernames else ''
                save_user_data(user_id)
            await query.answer()
            keyboard = _build_wallet_keyboard(lang, user_id)
            await update_section_media(query, 'wallet', get_text(lang, "wallet_menu_message"), InlineKeyboardMarkup(keyboard))
            return
        elif data.startswith('view_ton_'):
            idx = int(data.split('_')[-1])
            ton_wallets, _, _ = _user_requisites(user_id)
            if 0 <= idx < len(ton_wallets):
                # Escape user-supplied requisite text — though the TON validator
                # is strict, the message renders parse_mode=HTML downstream, so
                # any stray <>& would break parsing.
                msg = get_text(lang, "requisite_detail_ton",
                               value=html_module.escape(str(ton_wallets[idx] or '')))
                await query.answer()
                await update_section_media(query, 'wallet', msg, InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_menu')]]))
            return
        elif data.startswith('view_card_'):
            idx = int(data.split('_')[-1])
            _, cards, _ = _user_requisites(user_id)
            if 0 <= idx < len(cards):
                _, details = _card_currency_and_details(cards[idx])
                # Card details (bank + number) can legally contain user input —
                # bank-name validator only requires letters, so <>& slip through.
                raw = details or cards[idx]
                msg = get_text(lang, "requisite_detail_card",
                               value=html_module.escape(str(raw or '')))
                await query.answer()
                await update_section_media(query, 'wallet', msg, InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_menu')]]))
            return
        elif data.startswith('view_stars_'):
            idx = int(data.split('_')[-1])
            _, _, stars_usernames = _user_requisites(user_id)
            if 0 <= idx < len(stars_usernames):
                # Stars username/contact is user-controlled; escape defensively.
                msg = get_text(lang, "requisite_detail_stars",
                               value=html_module.escape(str(stars_usernames[idx] or '')))
                await query.answer()
                await update_section_media(query, 'wallet', msg, InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_menu')]]))
            return
        elif data == 'stars_contact':
            _, _, stars_usernames = _user_requisites(user_id)
            if len(stars_usernames) >= 1:
                await query.answer()
                await context.bot.send_message(
                    chat_id=query.message.chat_id,
                    text=get_text(lang, "requisite_already_exists_message"),
                    parse_mode="HTML"
                )
                return
            context.user_data.pop('awaiting_ton_wallet', None)
            context.user_data.pop('awaiting_card', None)
            context.user_data.pop('awaiting_amount', None)
            context.user_data.pop('awaiting_description', None)
            context.user_data['awaiting_stars_username'] = True
            context.user_data['last_bot_message_id'] = query.message.message_id
            context.user_data['last_bot_chat_id'] = query.message.chat_id
            message_text = get_text(lang, "stars_contact_message")
            await update_section_media(
                query, 'wallet', message_text,
                InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_added_back')]])
            )
            return

        elif data == 'add_ton_wallet':
            ton_wallets, _, _ = _user_requisites(user_id)
            if len(ton_wallets) >= 1:
                await query.answer()
                await context.bot.send_message(
                    chat_id=query.message.chat_id,
                    text=get_text(lang, "requisite_already_exists_message"),
                    parse_mode="HTML"
                )
                return
            context.user_data.pop('awaiting_card', None)
            context.user_data.pop('awaiting_stars_username', None)
            context.user_data.pop('awaiting_amount', None)
            context.user_data.pop('awaiting_description', None)
            context.user_data['last_bot_message_id'] = query.message.message_id
            context.user_data['last_bot_chat_id'] = query.message.chat_id
            message_text = get_text(lang, "add_ton_wallet_message")
            await update_section_media(
                query, 'wallet', message_text,
                InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_added_back')]])
            )
            context.user_data['awaiting_ton_wallet'] = True

        elif data == 'add_card':
            context.user_data.pop('awaiting_ton_wallet', None)
            context.user_data.pop('awaiting_stars_username', None)
            context.user_data.pop('awaiting_amount', None)
            context.user_data.pop('awaiting_description', None)
            keyboard_currency = [
                [InlineKeyboardButton(get_text(lang, "currency_rub_button"), callback_data='add_card_currency_RUB'),
                 InlineKeyboardButton(get_text(lang, "currency_uah_button"), callback_data='add_card_currency_UAH')],
                [InlineKeyboardButton(get_text(lang, "currency_usd_button"), callback_data='add_card_currency_USD'),
                 InlineKeyboardButton(get_text(lang, "currency_eur_button"), callback_data='add_card_currency_EUR')],
                [InlineKeyboardButton(get_text(lang, "currency_kzt_button"), callback_data='add_card_currency_KZT'),
                 InlineKeyboardButton(get_text(lang, "currency_byn_button"), callback_data='add_card_currency_BYN')],
                [InlineKeyboardButton(get_text(lang, "currency_uzs_button"), callback_data='add_card_currency_UZS'),
                 InlineKeyboardButton(get_text(lang, "currency_cny_button"), callback_data='add_card_currency_CNY')],
                [InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_added_back')],
            ]
            message_text = get_text(lang, "choose_card_currency_message")
            await update_section_media(query, 'wallet', message_text, InlineKeyboardMarkup(keyboard_currency))

        elif data.startswith('add_card_currency_'):
            currency = data.replace('add_card_currency_', '').strip().upper() or 'RUB'
            context.user_data['adding_card_currency'] = currency
            context.user_data.pop('awaiting_ton_wallet', None)
            context.user_data.pop('awaiting_stars_username', None)
            message_text = get_text(lang, "add_card_message")
            await update_section_media(
                query, 'wallet', message_text,
                InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_added_back')]])
            )
            context.user_data['awaiting_card'] = True
        
        elif data == 'create_deal':
            # Сбрасываем состояние ожидания от прошлого незавершённого создания сделки
            context.user_data.pop('awaiting_amount', None)
            context.user_data.pop('awaiting_description', None)
            context.user_data.pop('amount', None)
            context.user_data.pop('payment_method', None)
            context.user_data.pop('deal_type', None)
            # Перед созданием сделки нужен привязанный TON-кошелёк (для вывода средств).
            # Один и тот же адрес используется для TON и USDT (jetton).
            if not is_valid_ton_address(_user_ton_address(user_id)):
                message_text = get_text(lang, "no_ton_wallet_for_deal_message")
                await update_section_media(
                    query, 'create_deal', message_text,
                    InlineKeyboardMarkup([
                        [InlineKeyboardButton(get_text(lang, "wallet_btn_set_addr"), callback_data='wallet_set_addr')],
                        [InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='menu')]
                    ])
                )
                return
            # Выбор типа сделки: Подарки, Другие товары (внутри: Аккаунт, Игровая валюта)
            keyboard = [
                [_btn(get_text(lang, "deals_type_gifts_button"), callback_data='deal_type_gifts')],
                [_btn(get_text(lang, "deals_type_other_goods_button"), callback_data='deal_type_other_goods')],
                [_btn(get_text(lang, "menu_button"), callback_data='menu')]
            ]
            message_text = get_text(lang, "choose_deal_type_message")
            await update_section_media(query, 'create_deal', message_text, InlineKeyboardMarkup(keyboard))

        elif data == 'deal_type_gifts':
            context.user_data['deal_type'] = 'gifts'
            # Оплата всегда с внутреннего баланса бота (TON или USDT)
            keyboard = [
                [InlineKeyboardButton(get_text(lang, "crypto_usdt_button"), callback_data='payment_method_usdt'),
                 InlineKeyboardButton(get_text(lang, "crypto_ton_button"), callback_data='payment_method_ton')],
                [_btn(get_text(lang, "menu_button"), callback_data='menu')]
            ]
            message_text = get_text(lang, "choose_crypto_currency_message")
            await update_section_media(query, 'create_deal', message_text, InlineKeyboardMarkup(keyboard))

        elif data == 'deal_type_other_goods':
            message_text = get_text(lang, "choose_deal_subtype_message")
            keyboard = [
                [_btn(get_text(lang, "deals_type_account_button"), callback_data='deal_type_account')],
                [_btn(get_text(lang, "deals_type_game_currency_button"), callback_data='deal_type_game_currency')],
                [_btn(get_text(lang, "back_to_menu_button"), callback_data='create_deal')],
            ]
            await update_section_media(query, 'create_deal', message_text, InlineKeyboardMarkup(keyboard))

        elif data == 'deal_type_account':
            context.user_data['deal_type'] = 'account'
            keyboard = [
                [InlineKeyboardButton(get_text(lang, "crypto_usdt_button"), callback_data='payment_method_usdt'),
                 InlineKeyboardButton(get_text(lang, "crypto_ton_button"), callback_data='payment_method_ton')],
                [_btn(get_text(lang, "back_to_menu_button"), callback_data='deal_type_other_goods')],
            ]
            message_text = get_text(lang, "choose_crypto_currency_message")
            await update_section_media(query, 'create_deal', message_text, InlineKeyboardMarkup(keyboard))

        elif data == 'deal_type_game_currency':
            context.user_data['deal_type'] = 'game_currency'
            keyboard = [
                [InlineKeyboardButton(get_text(lang, "crypto_usdt_button"), callback_data='payment_method_usdt'),
                 InlineKeyboardButton(get_text(lang, "crypto_ton_button"), callback_data='payment_method_ton')],
                [_btn(get_text(lang, "back_to_menu_button"), callback_data='deal_type_other_goods')],
            ]
            message_text = get_text(lang, "choose_crypto_currency_message")
            await update_section_media(query, 'create_deal', message_text, InlineKeyboardMarkup(keyboard))

        elif data == 'payment_method_crypto':
            # Криптовалюта: выбор USDT или TON, адрес кошелька - один (сеть TON)
            deal_type = context.user_data.get('deal_type') or 'gifts'
            back_cb = 'deal_type_other_goods' if deal_type in ('account', 'game_currency') else f'deal_type_{deal_type}'
            keyboard = [
                [InlineKeyboardButton(get_text(lang, "crypto_usdt_button"), callback_data='payment_method_usdt'),
                 InlineKeyboardButton(get_text(lang, "crypto_ton_button"), callback_data='payment_method_ton')],
                [InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data=back_cb)],
            ]
            message_text = get_text(lang, "choose_crypto_currency_message")
            await update_section_media(query, 'create_deal', message_text, InlineKeyboardMarkup(keyboard))
            return

        elif data == 'payment_method_sbp':
            # Валюта: показываем выбор валюты (рубли, гривны и т.д.)
            deal_type_sbp = context.user_data.get('deal_type') or 'gifts'
            back_cb_sbp = 'deal_type_other_goods' if deal_type_sbp in ('account', 'game_currency') else f'deal_type_{deal_type_sbp}'
            keyboard_currency = [
                [InlineKeyboardButton(get_text(lang, "currency_rub_button"), callback_data='payment_method_currency_RUB'),
                 InlineKeyboardButton(get_text(lang, "currency_uah_button"), callback_data='payment_method_currency_UAH')],
                [InlineKeyboardButton(get_text(lang, "currency_usd_button"), callback_data='payment_method_currency_USD'),
                 InlineKeyboardButton(get_text(lang, "currency_eur_button"), callback_data='payment_method_currency_EUR')],
                [InlineKeyboardButton(get_text(lang, "currency_kzt_button"), callback_data='payment_method_currency_KZT'),
                 InlineKeyboardButton(get_text(lang, "currency_byn_button"), callback_data='payment_method_currency_BYN')],
                [InlineKeyboardButton(get_text(lang, "currency_uzs_button"), callback_data='payment_method_currency_UZS'),
                 InlineKeyboardButton(get_text(lang, "currency_cny_button"), callback_data='payment_method_currency_CNY')],
                [InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data=back_cb_sbp)],
            ]
            message_text = get_text(lang, "choose_card_currency_message")
            await update_section_media(query, 'create_deal', message_text, InlineKeyboardMarkup(keyboard_currency))
            return

        elif data.startswith('payment_method_currency_'):
            currency = data.replace('payment_method_currency_', '').strip().upper() or 'RUB'
            _, cards, _ = _user_requisites(user_id)
            card = _get_card_for_currency(cards, currency)
            if not card or not is_valid_card(card):
                message_text = get_text(lang, "no_card_for_deal_message")
                await update_section_media(
                    query, 'create_deal', message_text,
                    InlineKeyboardMarkup([
                        [InlineKeyboardButton(get_text(lang, "add_wallet_button"), callback_data='wallet_menu')],
                        [InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='menu')]
                    ])
                )
                return
            payment_method = 'sbp' if currency == 'RUB' else currency
            context.user_data['payment_method'] = payment_method
            context.user_data.pop('awaiting_card', None)
            context.user_data.pop('awaiting_ton_wallet', None)
            context.user_data.pop('awaiting_stars_username', None)
            context.user_data.pop('awaiting_card_name', None)
            valute_for_message = "RUB" if payment_method == 'sbp' else payment_method
            message_text = get_text(lang, "create_deal_message", valute=valute_for_message)
            keyboard = InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='menu')]])
            await update_section_media(query, 'create_deal', message_text, keyboard)
            context.user_data['awaiting_amount'] = True
            return

        elif data.startswith('payment_method_'):
            payment_method = data.split('_')[-1]
            # Оплата всегда с внутреннего баланса бота — внешние реквизиты продавца не требуются.
            context.user_data['payment_method'] = payment_method
            context.user_data.pop('awaiting_card', None)
            context.user_data.pop('awaiting_ton_wallet', None)
            context.user_data.pop('awaiting_stars_username', None)
            valute_for_message = _valute_display(payment_method, lang)
            message_text = get_text(lang, "create_deal_message", valute=valute_for_message)
            await update_section_media(
                query, 'create_deal', message_text,
                InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='menu')]])
            )
            context.user_data['awaiting_amount'] = True

        elif data.startswith('pay_from_balance_'):
            raw_deal_id = data[len('pay_from_balance_'):]
            deal_id = _resolve_deal_id(raw_deal_id) or raw_deal_id
            # P6.9: per-deal asyncio lock — without this, pay_from_balance races
            # with cancel_deal_ (which IS lock-wrapped). Cancel could flip status
            # to 'cancelled' between the status guard here and the debit, leaving
            # the buyer charged for a cancelled deal. Mirror the lock pattern used
            # by cancel_deal_ / seller_confirm_sent_ / buyer_confirm_received_.
            deal_lock = _DEAL_TX_LOCKS.setdefault(deal_id, asyncio.Lock())
            try:
                async with deal_lock:
                    # Re-fetch INSIDE the lock — status may have just changed.
                    deal = deals.get(deal_id)
                    if not deal:
                        await query.answer(get_text(lang, "deal_not_found_error") or "Сделка не найдена.", show_alert=True)
                        return
                    # P5.46 guard 1: foreign buyer
                    existing_buyer = deal.get('buyer_id')
                    if existing_buyer and existing_buyer != user_id:
                        await query.answer(get_text(lang, "deal_already_has_buyer_message") or "Другой покупатель уже присоединился.", show_alert=True)
                        return
                    # P5.46 guard 2: status — only 'active' deals can be paid.
                    # (re-checked inside lock so cancel_deal_ can't sneak past us)
                    if deal.get('status') != 'active':
                        await query.answer("❌ Эту сделку уже оплатили или закрыли.", show_alert=True)
                        return
                    # P5.46 guard 3: self-buy
                    if user_id == deal.get('seller_id'):
                        await query.answer(get_text(lang, "creator_cannot_join_own_deal_message") or "Нельзя купить свою же сделку.", show_alert=True)
                        return
                    # P5.46 guard 4: stars deals — pay-from-balance unavailable
                    if _is_stars_deal(deal):
                        await query.answer(
                            get_text(lang, "pay_from_balance_stars_not_available") or "Для сделки в звёздах оплата с баланса недоступна. Передайте звёзды в поддержку.",
                            show_alert=True,
                        )
                        return
                    buyer_id = user_id
                    seller_id = deal.get('seller_id')
                    amount = deal.get('amount')

                    if not (buyer_id and seller_id and amount is not None):
                        logger.error(f"Invalid deal data: deal_id={deal_id}, buyer_id={buyer_id}, seller_id={seller_id}, amount={amount}")
                        await query.edit_message_text("🚫 Ошибка: неверные данные сделки.", parse_mode="HTML")
                        return

                    ensure_user_exists(buyer_id)
                    ensure_user_exists(seller_id)

                    # P5.43: Stars deals are guarded out above (see "guard 4").
                    # The only currencies reaching here are TON / USDT (handled
                    # via _debit_user_balance_by_deal under _BALANCE_LOCK). The
                    # old in-memory `balance_stars` arithmetic on this path was
                    # dead (unreachable after the guard) AND unsafe (mutated
                    # user_data without _BALANCE_LOCK + would have raced with
                    # the deposit-monitor thread). Removed entirely; if
                    # internal Stars-pay is ever reintroduced, route it through
                    # the locked debit/credit helpers, not raw dict mutation.
                    pm = deal.get('payment_method')
                    buyer_bal = _user_available_balance_for_deal(buyer_id, pm)
                    logger.info(f"Buyer {buyer_id} balance ({pm}): {buyer_bal}, required amount: {amount}")
                    if buyer_bal >= amount:
                        _debit_user_balance_by_deal(buyer_id, float(amount), pm)
                        await asave_user_data(buyer_id)
                        await asave_user_data(seller_id)
                        # Фикс: подтверждение оплаты всегда должно фиксировать покупателя в сделке.
                        deal['buyer_id'] = buyer_id
                        deal['status'] = 'confirmed'
                        # P5.41: buyer's balance was actually debited — cancel must
                        # refund. (admin_confirm_deal_ does NOT set this flag.)
                        deal['escrow_collected'] = True
                        await asave_deal(deal_id)

                        seller_username_for_buyer = await _chat_username_or_name(context, seller_id, "Неизвестно")
                        valute_payment = _valute_display(deal.get('payment_method'), lang)
                        message_text = get_text(lang, "payment_confirmed_message",
                            deal_id_short=_deal_id_short(deal_id), seller_username=seller_username_for_buyer,
                            seller_id=seller_id or '-', support_username=get_garant_support_username(),
                            description=html_module.escape(str(deal.get('description', '-') or '-')), amount=deal['amount'], valute=valute_payment)
                        # P8.22 (MEDIUM): buyer needs dispute access after pay_from_balance.
                        # Раньше edit_message_text шёл без reply_markup — если продавец зависал,
                        # покупатель не мог открыть спор без перехода в /admin.
                        _support_username = get_garant_support_username() or "support"
                        buyer_kb_after_pay = InlineKeyboardMarkup([
                            [InlineKeyboardButton(
                                get_text(lang, "open_dispute_button"),
                                callback_data=f'open_dispute_{deal_id}',
                            )],
                            [InlineKeyboardButton(
                                get_text(lang, "contact_support_button"),
                                url=f'https://t.me/{_support_username}',
                            )],
                        ])
                        await query.edit_message_text(
                            text=message_text, parse_mode="HTML",
                            reply_markup=buyer_kb_after_pay,
                        )

                        buyer_username = await _chat_username_or_name(context, buyer_id, "Неизвестно")
                        seller_lang = user_data.get(seller_id, {}).get('lang', 'ru')
                        deal_id_short = (deal_id[:8]) if deal_id else ''
                        _seller_msg_key = "payment_confirmed_seller_message_account" if deal.get('deal_type') == 'account' else "payment_confirmed_seller_message"
                        # P10.7: caption-bound — cap escaped description at 200 chars so
                        # 5× username repeats + HTML escapes don't push the caption past 1024.
                        _desc_raw = str(deal.get('description', '-') or '-')
                        _desc_short = html_module.escape(_desc_raw)[:200]
                        if len(_desc_raw) > 200:
                            _desc_short += '...'
                        seller_message = get_text(seller_lang, _seller_msg_key,
                                                 deal_id_short=deal_id_short, description=_desc_short, buyer_username=buyer_username,
                                                 buyer_id=buyer_id or '-', amount=deal['amount'], valute=valute_payment, support_username=get_garant_support_username())
                        _is_product = deal.get('deal_type') in ('account', 'game_currency')
                        _confirm_key = "seller_confirm_sent_button_product" if _is_product else "seller_confirm_sent_button"
                        buyer_url = f'https://t.me/{buyer_username}' if buyer_username and re.match(r'^[A-Za-z0-9_]{5,32}$', buyer_username) else f'tg://user?id={buyer_id}'
                        reply_markup_seller = InlineKeyboardMarkup([
                            [_btn(get_text(seller_lang, "seller_transfer_gift_button"), url=buyer_url)],
                            [_btn(get_text(seller_lang, _confirm_key), callback_data=f'seller_confirm_sent_{deal_id}')],
                            [_btn(get_text(seller_lang, "open_dispute_button"), callback_data=f'open_dispute_{deal_id}')],
                            [support_button(deal_id)],
                        ])
                        payment_confirmed_path = get_animation_path('payment_confirmed')
                        if payment_confirmed_path:
                            try:
                                with open(payment_confirmed_path, 'rb') as f:
                                    await context.bot.send_animation(
                                        seller_id, animation=f, caption=seller_message,
                                        parse_mode="HTML", reply_markup=reply_markup_seller
                                    )
                            except Exception as e:
                                logger.warning(f"send_animation payment_confirmed failed: {e}")
                                await context.bot.send_message(seller_id, seller_message, parse_mode="HTML", reply_markup=reply_markup_seller)
                        else:
                            await context.bot.send_message(seller_id, seller_message, parse_mode="HTML", reply_markup=reply_markup_seller)

                        # Отправляем уведомление о подтверждении сделки
                        notification_text = (
                            f"✅ Сделка подтверждена\n"
                            f"ID: #{_deal_id_short(deal_id)}\n"
                            f"Сумма: {deal['amount']} {deal['payment_method'].upper()}\n"
                            f"Продавец: {seller_id}\n"
                            f"Покупатель: {buyer_id}"
                        )
                        await send_notification_to_chat(context, notification_text)
                    else:
                        message_text = get_text(lang, "insufficient_balance_message")
                        await query.edit_message_text(
                            text=message_text,
                            parse_mode="HTML",
                            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='menu_from_deal')]])
                        )
            finally:
                _DEAL_TX_LOCKS.pop(deal_id, None)

        elif data.startswith('open_dispute_'):
            raw_deal_id = data[len('open_dispute_'):]
            deal_id = _resolve_deal_id(raw_deal_id) or raw_deal_id
            deal = deals.get(deal_id)
            if not deal:
                await query.answer(get_text(lang, "deal_not_found_error") or "Сделка не найдена.", show_alert=True)
                return
            if user_id not in (deal.get('seller_id'), deal.get('buyer_id')):
                await query.answer("❌ Открыть спор может только участник сделки.", show_alert=True)
                return
            # Per-deal asyncio lock — without this two simultaneous clicks both pass the
            # status guard and double-send notifications / overwrite state.
            lock = _DISPUTE_LOCKS.setdefault(deal_id, asyncio.Lock())
            try:
                async with lock:
                    # Re-fetch INSIDE the lock — the deal status may have just been
                    # mutated by a concurrent click that lost the race.
                    deal = deals.get(deal_id)
                    if not deal:
                        await query.answer(get_text(lang, "deal_not_found_error") or "Сделка не найдена.", show_alert=True)
                        return
                    cur_status = (deal.get('status') or '').lower()
                    if cur_status == 'disputed':
                        await query.answer(get_text(lang, "dispute_already_open"), show_alert=True)
                        return
                    # Restrict to states where dispute makes sense — buyer paid (confirmed)
                    # or seller claims sent (seller_sent). 'active' (no buyer / not paid)
                    # and terminal states ('completed','cancelled','closed') are blocked.
                    if cur_status not in ('confirmed', 'seller_sent'):
                        await query.answer(get_text(lang, "dispute_cannot_open_completed"), show_alert=True)
                        return
                    await query.answer()
                    deal['status'] = 'disputed'
                    await asave_deal(deal_id)

                    from .dynamic_settings import get_dispute_chat_link as _get_dispute_link
                    chat_link = _get_dispute_link()
                    seller_id = deal.get('seller_id')
                    buyer_id = deal.get('buyer_id')
                    deal_id_short = _deal_id_short(deal_id)

                    # Уведомляем обоих участников
                    for party_id in (seller_id, buyer_id):
                        if not party_id:
                            continue
                        party_lang = user_data.get(party_id, {}).get('lang', 'ru')
                        if chat_link:
                            party_msg = get_text(party_lang, "dispute_opened_msg", deal_id_short=deal_id_short)
                            party_kb = InlineKeyboardMarkup([
                                [InlineKeyboardButton(get_text(party_lang, "dispute_chat_button"), url=chat_link)],
                            ])
                        else:
                            party_msg = get_text(party_lang, "dispute_opened_no_chat_msg",
                                                 deal_id_short=deal_id_short,
                                                 support=get_garant_support_username() or "support")
                            party_kb = None
                        try:
                            await context.bot.send_message(
                                int(party_id), party_msg, parse_mode="HTML",
                                reply_markup=party_kb,
                            )
                        except Exception as e:
                            logger.warning(f"open_dispute: notify {party_id} failed: {e}")

                    # Уведомляем админов
                    try:
                        import config as _cfg
                        admins = set(getattr(_cfg, "GARANT_ADMIN_USER_IDS", None) or set())
                        legacy = getattr(_cfg, "GARANT_ADMIN_USER_ID", None)
                        if legacy:
                            admins.add(int(legacy))
                        for aid in admins:
                            try:
                                aid_lang = user_data.get(int(aid), {}).get('lang', 'ru')
                                admin_msg = get_text(aid_lang, "dispute_opened_admin_msg",
                                                     deal_id_short=deal_id_short,
                                                     amount=deal.get('amount') or 0,
                                                     currency=(deal.get('payment_method') or '').upper(),
                                                     seller_id=seller_id or '-',
                                                     buyer_id=buyer_id or '-',
                                                     initiator_id=user_id)
                                await context.bot.send_message(int(aid), admin_msg, parse_mode="HTML")
                            except Exception as e:
                                logger.warning(f"open_dispute admin notify {aid}: {e}")
                    except Exception as e:
                        logger.warning(f"open_dispute: admin notify failed: {e}")

                    # Убираем кнопки на сообщении инициатора
                    try:
                        await query.edit_message_reply_markup(reply_markup=None)
                    except Exception:
                        pass
            finally:
                # Освобождаем lock после async with (контекст вышел) — pop только
                # для очистки памяти; параллельные кликеры до этого момента уже
                # ждут на ТОМ ЖЕ lock instance.
                _DISPUTE_LOCKS.pop(deal_id, None)

        elif data.startswith('seller_confirm_sent_'):
            raw_deal_id = data[len('seller_confirm_sent_'):]
            deal_id = _resolve_deal_id(raw_deal_id) or raw_deal_id
            deal = deals.get(deal_id)
            logger.info(f"seller_confirm_sent: raw={raw_deal_id!r}, resolved={deal_id!r}, deal_found={deal is not None}, buyer_id={deal.get('buyer_id') if deal else None}")
            if not deal:
                await query.answer(get_text(lang, "deal_not_found_error") or "Сделка не найдена.", show_alert=True)
                return
            # P5.2: per-deal lock — without it cancel/buyer_confirm_received races
            # could let two writers transition status simultaneously.
            deal_lock = _DEAL_TX_LOCKS.setdefault(deal_id, asyncio.Lock())
            try:
                async with deal_lock:
                    deal = deals.get(deal_id)
                    if not deal:
                        await query.answer(get_text(lang, "deal_not_found_error") or "Сделка не найдена.", show_alert=True)
                        return
                    cur_status = (deal.get('status') or '').lower()
                    if cur_status == 'disputed':
                        await query.answer(get_text(lang, "dispute_action_blocked"), show_alert=True)
                        return
                    if not (cur_status == 'confirmed' and user_id == deal.get('seller_id')):
                        await query.answer(get_text(lang, "unknown_callback_error"), show_alert=True)
                        return
                    if not deal.get('buyer_id'):
                        await query.answer(get_text(lang, "seller_confirm_no_buyer") or "Покупатель не присоединился к сделке. Обратитесь в поддержку.", show_alert=True)
                        return
                    await query.answer()
                    deal['status'] = 'seller_sent'
                    await asave_deal(deal_id)

                    buyer_id = deal.get('buyer_id')
                    buyer_lang = user_data.get(buyer_id, {}).get('lang', 'ru') if buyer_id else 'ru'

                    seller_username = await _chat_username_or_name(context, user_id, "Неизвестно")
                    buyer_username = await _chat_username_or_name(context, buyer_id, "Неизвестно") if buyer_id else "Неизвестно"

                    _is_product_deal = deal.get('deal_type') in ('account', 'game_currency')
                    _msg_key = "seller_confirm_sent_message_product" if _is_product_deal else "seller_confirm_sent_message"
                    message_text = get_text(lang, _msg_key, deal_id_short=_deal_id_short(deal_id), buyer_username=buyer_username)
                    # После подтверждения оставляем кнопку «Передать товар» (чат с покупателем) +
                    # «Открыть спор» — на случай если покупатель не подтверждает получение.
                    buyer_url = f'https://t.me/{buyer_username}' if buyer_username and re.match(r'^[A-Za-z0-9_]{5,32}$', buyer_username) else f'tg://user?id={buyer_id}'
                    reply_markup_after_confirm = InlineKeyboardMarkup([
                        [_btn(get_text(lang, "seller_transfer_gift_button"), url=buyer_url)],
                        [_btn(get_text(lang, "open_dispute_button"), callback_data=f'open_dispute_{deal_id}')],
                    ])
                    try:
                        if query.message.animation or query.message.video or query.message.photo:
                            await query.edit_message_caption(caption=message_text, parse_mode="HTML")
                            await query.edit_message_reply_markup(reply_markup=reply_markup_after_confirm)
                        else:
                            await query.edit_message_text(text=message_text, parse_mode="HTML", reply_markup=reply_markup_after_confirm)
                    except Exception as e:
                        logger.warning(f"seller_confirm_sent: failed to edit seller message (deal {deal_id}): {e}")

                    if buyer_id:
                        try:
                            buyer_message = get_text(buyer_lang, "seller_confirm_sent_notification", seller_username=seller_username, deal_id_short=_deal_id_short(deal_id))
                            await context.bot.send_message(
                                int(buyer_id),
                                buyer_message,
                                parse_mode="HTML",
                                reply_markup=InlineKeyboardMarkup([
                                    [InlineKeyboardButton(get_text(buyer_lang, "buyer_confirm_received_button"), callback_data=f'buyer_confirm_received_{deal_id}')],
                                    [InlineKeyboardButton(get_text(buyer_lang, "open_dispute_button"), callback_data=f'open_dispute_{deal_id}')],
                                    [InlineKeyboardButton(get_text(buyer_lang, "contact_support_button"), url=f'https://t.me/{get_garant_support_username()}')],
                                    [support_button(deal_id)],
                                ])
                            )
                            logger.info(f"Seller confirmed sent: notification sent to buyer {buyer_id} for deal {deal_id}")
                        except Exception as e:
                            logger.error(f"Failed to send seller_confirm_sent to buyer {buyer_id} (deal {deal_id}): {e}")
                    else:
                        logger.warning(f"Seller confirmed sent: no buyer_id for deal {deal_id}")

                    # Отправляем уведомление о подтверждении отправки
                    notification_text = (
                        f"📦 Продавец подтвердил отправку\n"
                        f"ID сделки: #{_deal_id_short(deal_id)}\n"
                        f"Продавец: {user_id}\n"
                        f"Покупатель: {buyer_id if buyer_id else 'Не указан'}"
                    )
                    await send_notification_to_chat(context, notification_text)
            finally:
                _DEAL_TX_LOCKS.pop(deal_id, None)

        elif data.startswith('buyer_confirm_received_'):
            raw_deal_id = data[len('buyer_confirm_received_'):]
            deal_id = _resolve_deal_id(raw_deal_id) or raw_deal_id
            deal = deals.get(deal_id)
            if not deal:
                await query.answer(get_text(lang, "deal_not_found_error") or "Сделка не найдена.", show_alert=True)
                return
            # P5.2/P5.6: per-deal lock — without it, double-click or simultaneous
            # cancel could double-credit the seller (status=seller_sent passes
            # twice before status flip lands).
            deal_lock = _DEAL_TX_LOCKS.setdefault(deal_id, asyncio.Lock())
            try:
                async with deal_lock:
                    deal = deals.get(deal_id)
                    if not deal:
                        await query.answer(get_text(lang, "deal_not_found_error") or "Сделка не найдена.", show_alert=True)
                        return
                    cur_status = (deal.get('status') or '').lower()
                    if cur_status == 'disputed':
                        await query.answer(get_text(lang, "dispute_action_blocked"), show_alert=True)
                        return
                    if not (cur_status == 'seller_sent' and user_id == deal.get('buyer_id')):
                        # Status changed (cancel/dispute/already-completed) or wrong user.
                        await query.answer(get_text(lang, "unknown_callback_error"), show_alert=True)
                        return
                    deal['status'] = 'completed'
                    await asave_deal(deal_id)

                    seller_id = deal['seller_id']
                    buyer_id = user_id
                    # Теперь начисляем баланс продавцу в валюте сделки за вычетом комиссии.
                    # Это конец сделки: можно безопасно пополнять.
                    amount = deal.get('amount') or 0
                    # SECURITY P10.15: only credit seller if buyer escrow was actually collected.
                    # Admin-confirmed deals via /close or admin_confirm_deal_ flip status without debit;
                    # without this gate, completion would mint money for the seller (twink-buyer exploit).
                    if not deal.get('escrow_collected'):
                        logger.warning(
                            f"buyer_confirm_received_: deal {deal_id} completed without escrow_collected — "
                            f"seller credit SKIPPED. seller={seller_id} buyer={buyer_id} amount={amount}"
                        )
                        # Notify admins of suspicious flow
                        try:
                            import config as _cfg
                            admins = set(getattr(_cfg, "GARANT_ADMIN_USER_IDS", None) or set())
                            for aid in admins:
                                try:
                                    await context.bot.send_message(
                                        int(aid),
                                        f"⚠️ <b>Сделка {_deal_id_short(deal_id)} завершена БЕЗ escrow!</b>\n"
                                        f"Seller: <code>{seller_id}</code>\n"
                                        f"Buyer: <code>{buyer_id}</code>\n"
                                        f"Amount: {amount}\n"
                                        f"Ставка не была собрана при confirm — возможный exploit.\n"
                                        f"Если оплата прошла вне бота, начислить вручную через /admin.",
                                        parse_mode="HTML",
                                    )
                                except Exception:
                                    pass
                        except Exception:
                            pass
                    elif seller_id and amount and float(amount) > 0:
                        # P5.3: clamp commission to [0, 100] — settings could
                        # otherwise return -5 (negative fee = bonus) or 200
                        # (negative net = silently zero'd).
                        commission_pct_raw = float(get_garant_commission_percent() or 0)
                        commission_pct = max(0.0, min(100.0, commission_pct_raw))
                        if commission_pct != commission_pct_raw:
                            logger.warning(f"commission_pct out of range ({commission_pct_raw}), clamped to {commission_pct}")
                        fee = round(float(amount) * commission_pct / 100.0, 6)
                        net = max(0.0, round(float(amount) - fee, 6))
                        _credit_user_balance_by_deal(seller_id, net, deal.get('payment_method'))
                        await asave_user_data(seller_id)
                        logger.info(f"deal {deal_id}: seller={seller_id} +{net} (fee {fee}) {deal.get('payment_method')}")
                    seller_username = "-"
                    seller_username = await _chat_username_or_name(context, seller_id, str(seller_id) if seller_id else "-")
                    buyer_username = await _chat_username_or_name(context, buyer_id, str(buyer_id) if buyer_id else "-")
                    description = html_module.escape(str((deal.get('description') or '-')[:100]))

                    # Buyer rate-keyboard: 👍/👎 на seller_id + меню.
                    buyer_rate_text = get_text(lang, "buyer_rate_seller_message")
                    buyer_rate_kb = InlineKeyboardMarkup([
                        [InlineKeyboardButton("👍 Хорошо", callback_data=f'rate_{deal_id}_up'),
                         InlineKeyboardButton("👎 Плохо", callback_data=f'rate_{deal_id}_down')],
                        [InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='menu')],
                    ])
                    await query.edit_message_text(text=buyer_rate_text, parse_mode="HTML", reply_markup=buyer_rate_kb)

                    # Баланс начислен на шаге завершения сделки (status='completed').

                    if seller_id:
                        ensure_user_exists(seller_id)
                        user_data[seller_id]['successful_deals'] = user_data[seller_id].get('successful_deals', 0) + 1
                        await asave_user_data(seller_id)

                    # Отправляем уведомление о завершении сделки
                    notification_text = (
                        f"🏁 Сделка завершена\n"
                        f"Покупатель подтвердил получение.\n\n"
                        f"Продавец: @{seller_username} (ID: {seller_id})\n"
                        f"Покупатель: @{buyer_username} (ID: {buyer_id})\n"
                        f"Название: {description}"
                    )
                    await send_notification_to_chat(context, notification_text)

                    # Продавцу: «Сделка успешно завершена!» + кнопки рейтинга + меню.
                    # Выплата уже зачислена на баланс seller'а через _credit_user_balance_by_deal —
                    # деньги ждут в Кошелёк → Вывести (автовывод). Старый «выбор кошелька → запрос
                    # админу» убран как obsolete: всё автоматически после Phase 9.
                    seller_lang = user_data.get(seller_id, {}).get('lang', 'ru')
                    seller_success_text = get_text(seller_lang, "seller_deal_completed_message")
                    seller_kb = InlineKeyboardMarkup([
                        [InlineKeyboardButton("👍 Хорошо", callback_data=f'rate_{deal_id}_up'),
                         InlineKeyboardButton("👎 Плохо", callback_data=f'rate_{deal_id}_down')],
                        [InlineKeyboardButton(get_text(seller_lang, "menu_button"), callback_data='menu')],
                    ])
                    try:
                        await context.bot.send_message(
                            seller_id,
                            seller_success_text,
                            parse_mode="HTML",
                            reply_markup=seller_kb,
                        )
                    except Exception as e:
                        logger.error(f"Failed to send seller completion msg {seller_id}: {e}")
            finally:
                _DEAL_TX_LOCKS.pop(deal_id, None)

        elif data.startswith('cancel_deal_'):
            deal_id = data[len('cancel_deal_'):]
            deal = deals.get(deal_id)
            if not deal:
                await query.answer("Сделка не найдена или уже закрыта.", show_alert=True)
                return
            # P5.2: per-deal lock — without it, cancel + buyer_confirm_received
            # could both pass status='seller_sent' check and both pay out.
            deal_lock = _DEAL_TX_LOCKS.setdefault(deal_id, asyncio.Lock())
            try:
                async with deal_lock:
                    deal = deals.get(deal_id)
                    if not deal:
                        await query.answer("Сделка не найдена или уже закрыта.", show_alert=True)
                        return
                    cur_status = (deal.get('status') or '').lower()
                    # Once a dispute is open, neither party can cancel — would otherwise
                    # silently overwrite status='disputed' and bypass support resolution.
                    if cur_status == 'disputed':
                        await query.answer(get_text(lang, "dispute_action_blocked"), show_alert=True)
                        return
                    seller_id_cancel = deal.get('seller_id')
                    buyer_id_cancel = deal.get('buyer_id')
                    is_seller = user_id == seller_id_cancel
                    is_buyer = user_id == buyer_id_cancel
                    if not (is_seller or is_buyer):
                        await query.answer("Вы не участник этой сделки.", show_alert=True)
                        return
                    if cur_status not in ('active', 'confirmed', 'seller_sent'):
                        await query.answer("Отменить эту сделку нельзя.", show_alert=True)
                        return
                    # P5.21: once seller marked the goods as sent, neither party
                    # may unilaterally cancel — buyer could rug-pull the refund
                    # mid-delivery, seller could refund a buyer they already
                    # delivered to. Disputes are the only correct path.
                    if cur_status == 'seller_sent':
                        await query.answer(
                            get_text(lang, "cancel_after_sent_blocked_message")
                            or "❌ Товар уже передан. Используйте «⚠️ Открыть спор» вместо отмены.",
                            show_alert=True,
                        )
                        return
                    # Если сделка уже оплачена покупателем — возвращаем заморозку.
                    # P5.41: refund ONLY when buyer's balance was actually debited.
                    # admin_confirm_deal_ flips status to 'confirmed' WITHOUT debiting
                    # (Stars deals especially) — refunding then would mint free balance.
                    if cur_status == 'confirmed' and deal.get('escrow_collected'):
                        amount = float(deal.get('amount') or 0)
                        if buyer_id_cancel and amount > 0:
                            _credit_user_balance_by_deal(buyer_id_cancel, amount, deal.get('payment_method'))
                            await asave_user_data(buyer_id_cancel)
                            logger.info(f"deal {deal_id}: refunded {amount} {deal.get('payment_method')} to buyer={buyer_id_cancel}")
                    elif cur_status == 'confirmed':
                        logger.info(f"deal {deal_id}: cancel without refund (escrow_collected=False, e.g. admin_confirm_deal_)")
                    deal['status'] = 'cancelled'
                    await asave_deal(deal_id)
                    try:
                        await query.edit_message_text(
                            get_text(lang, "deal_cancelled_message", deal_id_short=_deal_id_short(deal_id)),
                            parse_mode="HTML",
                            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='menu')]])
                        )
                    except Exception:
                        pass
                    other_id = buyer_id_cancel if is_seller else seller_id_cancel
                    if other_id:
                        try:
                            await context.bot.send_message(
                                other_id,
                                get_text(user_data.get(other_id, {}).get('lang', 'ru'), "deal_cancelled_notification", deal_id_short=_deal_id_short(deal_id)),
                                parse_mode="HTML"
                            )
                        except Exception as e:
                            logger.error(f"Failed to notify other party of cancellation: {e}")
                    who = "продавцом" if is_seller else "покупателем"
                    notification_text = f"❌ Сделка #{_deal_id_short(deal_id)} отменена {who}."
                    await send_notification_to_chat(context, notification_text)
            finally:
                _DEAL_TX_LOCKS.pop(deal_id, None)

        elif data == 'my_profile':
            await query.answer()
            ensure_user_exists(user_id)
            name = await _chat_username_or_name(context, user_id, str(user_id))
            # Префиксуем @ если name похож на username (без пробелов и нелатинских символов).
            display_name = (name or str(user_id))
            if display_name and not display_name.startswith('@') and ' ' not in display_name and re.match(r'^[A-Za-z0-9_]{3,}$', display_name):
                display_name = '@' + display_name
            ud = user_data.get(user_id, {})
            deals_count = ud.get('successful_deals', 0) or 0
            likes = int(ud.get('likes', 0) or 0)
            dislikes = int(ud.get('dislikes', 0) or 0)
            reputation = likes - dislikes
            reputation_str = f"{reputation:+d}" if reputation else "0"
            bc = ud.get('balance_currencies') or {}
            try:
                ton_amt = float(bc.get('TON', 0) or 0)
            except (TypeError, ValueError):
                ton_amt = 0.0
            try:
                usdt_amt = float(bc.get('USDT', 0) or 0)
            except (TypeError, ValueError):
                usdt_amt = 0.0
            def _fmt_amt(v):
                if float(v).is_integer():
                    return f"{int(v)}"
                return f"{v:.4f}".rstrip("0").rstrip(".")
            reg_ts = ud.get('registered_at') or 0
            if reg_ts:
                from datetime import datetime as _dt
                fmt = "%d.%m.%Y" if lang == 'ru' else "%Y-%m-%d"
                registered_str = _dt.fromtimestamp(int(reg_ts)).strftime(fmt)
            else:
                registered_str = "—"
            message_text = get_text(lang, "profile_message",
                name=display_name.replace('&', '&amp;').replace('<', '&lt;'),
                user_id=user_id,
                reputation=reputation_str,
                likes=likes,
                dislikes=dislikes,
                deals_count=deals_count,
                balance_ton=_fmt_amt(ton_amt),
                balance_usdt=_fmt_amt(usdt_amt),
                registered=registered_str)
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton(get_text(lang, "history_deals_button"), callback_data='my_deals_intro')],
                [InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='menu')],
            ])
            await update_section_media(query, 'my_deals', message_text, keyboard)

        elif data == 'my_deals_intro':
            message_text = get_text(lang, "my_deals_intro_message")
            keyboard = [
                [
                    InlineKeyboardButton(get_text(lang, "deals_type_gifts_button"), callback_data='my_deals_0'),
                    InlineKeyboardButton(get_text(lang, "deals_type_other_goods_button"), callback_data='my_deals_other_0'),
                ],
                [InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='menu')],
            ]
            await update_section_media(query, 'my_deals', message_text, InlineKeyboardMarkup(keyboard))
            return

        elif data == 'my_deals_empty':
            await query.answer()
            return

        elif data == 'wallet_added_skip' or data == 'wallet_added_back':
            context.user_data.pop('awaiting_ton_wallet_name', None)
            context.user_data.pop('awaiting_card_name', None)
            context.user_data.pop('adding_card_currency', None)
            context.user_data.pop('awaiting_stars_name', None)
            ensure_user_exists(user_id)
            await query.answer()
            context.user_data['requisite_fail_count'] = 0
            await send_wallet_menu_with_media(context, query.message.chat_id, lang, user_id)
            return

        elif data == 'wallet_add_name_do':
            ensure_user_exists(user_id)
            context.user_data['awaiting_ton_wallet_name'] = True
            context.user_data['last_bot_chat_id'] = query.message.chat_id
            context.user_data['last_bot_message_id'] = query.message.message_id
            await query.answer()
            await update_section_media(
                query, 'wallet', get_text(lang, "enter_name_for_wallet_message"),
                InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_added_back')]])
            )
            return
        elif data == 'add_card_name_do':
            ensure_user_exists(user_id)
            context.user_data['awaiting_card_name'] = True
            await query.answer()
            try:
                await update_section_media(
                    query, 'wallet', get_text(lang, "enter_name_for_card_message"),
                    InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_added_back')]])
                )
            except Exception:
                await context.bot.send_message(
                    chat_id=query.message.chat_id,
                    text=get_text(lang, "enter_name_for_card_message"),
                    parse_mode="HTML",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_added_back')]])
                )
            return
        elif data == 'add_stars_name_do':
            ensure_user_exists(user_id)
            context.user_data['awaiting_stars_name'] = True
            await query.answer()
            try:
                await update_section_media(
                    query, 'wallet', get_text(lang, "enter_name_for_stars_message"),
                    InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_added_back')]])
                )
            except Exception:
                await context.bot.send_message(
                    chat_id=query.message.chat_id,
                    text=get_text(lang, "enter_name_for_stars_message"),
                    parse_mode="HTML",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='wallet_added_back')]])
                )
            return

        elif data.startswith('my_deals_'):
            parts = data.split('_')
            deal_type_filter = None
            if len(parts) >= 3 and parts[2] == 'channels':
                deal_type_filter = 'channel'
                page = int(parts[-1]) if parts[-1].isdigit() else 0
            elif len(parts) >= 3 and parts[2] == 'accounts':
                deal_type_filter = 'accounts'
                page = int(parts[-1]) if parts[-1].isdigit() else 0
            elif len(parts) >= 3 and parts[2] == 'other':
                deal_type_filter = 'other'
                page = int(parts[-1]) if parts[-1].isdigit() else 0
            else:
                page = int(parts[-1]) if parts[-1].isdigit() else 0
                deal_type_filter = 'gifts'
            per_page = 8
            def _deal_matches_filter(d, flt):
                if flt is None:
                    return True
                dt = d.get('deal_type', 'gifts')
                if flt == 'gifts':
                    return dt == 'gifts'
                if flt == 'accounts':
                    return dt == 'accounts'
                if flt == 'other':
                    return dt in ('account', 'game_currency', 'accounts')
                if flt == 'channel':
                    return dt == 'channel'
                return dt == flt
            my_deals_list = [
                (did, d) for did, d in deals.items()
                if (d.get('seller_id') == user_id or d.get('buyer_id') == user_id)
                and _deal_matches_filter(d, deal_type_filter)
            ]
            def _my_deal_sort_key(item):
                _, d = item
                # P5.8: parse via helper (supports both ISO and legacy DD.MM.YYYY formats)
                created_dt = _parse_deal_created_at(d.get('created_at') or '')
                ts = created_dt.timestamp() if created_dt else 0
                return -ts  # по убыванию даты: новее выше
            my_deals_list.sort(key=_my_deal_sort_key)
            total = len(my_deals_list)
            if total == 0:
                message_text = get_text(lang, "no_deals_message")
                await update_section_media(
                    query, 'my_deals', message_text,
                    InlineKeyboardMarkup([
                        [InlineKeyboardButton(get_text(lang, "nothing_here_button"), callback_data='my_deals_empty')],
                        [InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='menu')]
                    ])
                )
                return
            start_idx = page * per_page
            page_deals = my_deals_list[start_idx:start_idx + per_page]
            cb_prefix = 'my_deals_channels_' if deal_type_filter == 'channel' else 'my_deals_accounts_' if deal_type_filter == 'accounts' else 'my_deals_other_' if deal_type_filter == 'other' else 'my_deals_'
            keyboard_rows = []
            for deal_id_loop, deal_info in page_deals:
                amount = deal_info.get('amount', 0)
                pm = deal_info.get('payment_method', 'ton')
                pm_text = _valute_display(pm, lang)
                status_key = f"deal_status_{deal_info.get('status', 'active')}"
                try:
                    status_label = get_text(lang, status_key)
                except Exception:
                    status_label = deal_info.get('status', '')
                keyboard_rows.append([InlineKeyboardButton(
                    f"#{deal_id_loop[:8]} | {status_label}",
                    callback_data=f'view_my_deal_{deal_id_loop}'
                )])
            total_pages = max(1, (total + per_page - 1) // per_page)
            nav_buttons = []
            if page > 0:
                nav_buttons.append(InlineKeyboardButton("⬅️", callback_data=f'{cb_prefix}{page - 1}'))
            nav_buttons.append(InlineKeyboardButton(f"{page + 1}/{total_pages}", callback_data='noop'))
            if start_idx + per_page < total:
                nav_buttons.append(InlineKeyboardButton("➡️", callback_data=f'{cb_prefix}{page + 1}'))
            if nav_buttons:
                keyboard_rows.append(nav_buttons)
            keyboard_rows.append([InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='menu')])
            message_text = get_text(lang, "your_deals_message")
            await update_section_media(query, 'my_deals', message_text, InlineKeyboardMarkup(keyboard_rows))

        elif data.startswith('view_my_deal_'):
            deal_id = data[len('view_my_deal_'):]
            deal = deals.get(deal_id)
            if not deal:
                await query.answer(get_text(lang, "no_access_to_deal_message"), show_alert=True)
                return
            seller_id = deal.get('seller_id')
            buyer_id = deal.get('buyer_id')
            if user_id != seller_id and user_id != buyer_id:
                await query.answer(get_text(lang, "no_access_to_deal_message"), show_alert=True)
                return
            role_key = "deal_role_seller" if user_id == seller_id else "deal_role_buyer"
            other_id = buyer_id if user_id == seller_id else seller_id
            other_username = "-"
            if other_id:
                try:
                    other_chat = await context.bot.get_chat(other_id)
                    other_username = f"@{other_chat.username}" if other_chat.username else str(other_id)
                except Exception:
                    other_username = str(other_id)
            status_key = f"deal_status_{deal.get('status', 'active')}"
            status_label = get_text(lang, status_key)
            valute_deal = _valute_display(deal.get('payment_method'), lang)
            message_text = get_text(lang, "deal_details_message",
                deal_id_short=_deal_id_short(deal_id),
                amount=deal.get('amount', 0),
                valute=valute_deal,
                description=html_module.escape(str(deal.get('description', '') or '-')),
                status=status_label,
                other_user=other_username.replace('@', ''),
                created_at=deal.get('created_at') or "-",
                role=get_text(lang, role_key))
            await update_section_media(
                query, 'my_deals', message_text,
                InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "back_to_deals_button"), callback_data='my_deals_0')], [InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='menu')]])
            )

        elif data == 'change_lang':
            message_text = (
                get_text(lang, "change_lang_message") + "\n\n"
                + get_text(lang, "change_lang_instruction_ru") + "\n"
                + get_text(lang, "change_lang_instruction_en")
            )
            await update_section_media(
                query, 'change_lang', message_text,
                InlineKeyboardMarkup([
                    [InlineKeyboardButton(get_text(lang, "lang_rus_button"), callback_data='lang_ru'), InlineKeyboardButton(get_text(lang, "lang_eng_button"), callback_data='lang_en')],
                    [InlineKeyboardButton(get_text(lang, "back_to_menu_button"), callback_data='menu')]
                ])
            )

        elif data.startswith('lang_'):
            new_lang = data.split('_')[-1]
            ensure_user_exists(user_id)
            user_data[user_id]['lang'] = new_lang
            save_user_data(user_id)
            await update_section_media(
                query, 'change_lang',
                get_text(new_lang, "lang_set_success_message"),
                InlineKeyboardMarkup([[InlineKeyboardButton(get_text(new_lang, "back_to_menu_button"), callback_data='menu')]])
            )
            return

        elif data.startswith('admin_view_deal_'):
            # P10.17 (MEDIUM): defence-in-depth — кнопки рендерятся только
            # админам, но callback_data можно подделать вручную, поэтому
            # дублируем проверку прав здесь.
            if not _is_user_admin(user_id):
                await query.answer("❌ Доступ запрещён.", show_alert=True)
                return
            deal_id = data[len('admin_view_deal_'):]
            deal = deals.get(deal_id)
            if deal:
                seller_id, buyer_id = deal.get('seller_id'), deal.get('buyer_id')
                seller_username = await _chat_username_or_name(context, seller_id, "Неизвестно")
                buyer_username = await _chat_username_or_name(context, buyer_id, "Не указан") if buyer_id else "Не указан"

                status_raw = deal.get('status', 'active')
                status_label = get_text(lang, f"deal_status_{status_raw}") or status_raw
                deal_payment_method = deal.get('payment_method', 'ton')
                valute = _valute_display(deal_payment_method, lang)
                
                payment_details = "Реквизиты не указаны"
                if seller_id:
                    ensure_user_exists(seller_id)
                    seller_lang = user_data.get(seller_id, {}).get('lang', 'ru')
                    if deal_payment_method in ('ton', 'usdt'):
                        payment_details = user_data[seller_id].get('ton_wallet') or get_text(seller_lang, "not_specified_wallet")
                    elif deal_payment_method == 'stars':
                        payment_details = "Оплата через Telegram Stars"
                    elif deal_payment_method in ('sbp', 'RUB', 'UAH', 'USD', 'EUR', 'KZT', 'BYN', 'UZS') or (deal_payment_method and deal_payment_method not in ('ton', 'usdt', 'stars')):
                        _, seller_cards, _ = _user_requisites(seller_id)
                        card_entry = _get_card_for_currency(seller_cards, deal_payment_method)
                        if card_entry:
                            _, payment_details = _card_currency_and_details(card_entry)
                        else:
                            payment_details = user_data[seller_id].get('card_details') or get_text(seller_lang, "not_specified_card")
                
                message_text = get_text(lang, "admin_view_deal_message",
                                        deal_id_short=_deal_id_short(deal_id), seller_id=seller_id or "N/A", seller_username=seller_username,
                                        seller_successful_deals=user_data.get(seller_id, {}).get('successful_deals', 0) if seller_id else 0,
                                        buyer_id=buyer_id or "Не указан", buyer_username=buyer_username,
                                        buyer_successful_deals=user_data.get(buyer_id, {}).get('successful_deals', 0) if buyer_id else 0,
                                        description=html_module.escape(str(deal.get('description', '') or '-')), amount=deal.get('amount', 0), valute=valute,
                                        payment_details=html_module.escape(str(payment_details or '-')), status=status_label)
                
                deal_buttons = []
                if status_raw == 'active':
                    deal_buttons = [
                        [_btn(get_text(lang, "admin_confirm_deal_button"), callback_data=f'admin_confirm_deal_{deal_id}'),
                         _btn(get_text(lang, "admin_cancel_deal_button"), callback_data=f'admin_cancel_deal_{deal_id}')],
                    ]
                deal_buttons.append([InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='admin_view_deals_0')])
                await edit_message_or_caption(
                    query, message_text,
                    InlineKeyboardMarkup(deal_buttons)
                )

        elif data.startswith('admin_confirm_deal_'):
            # P10.17 (MEDIUM): defence-in-depth — admin guard.
            if not _is_user_admin(user_id):
                await query.answer("❌ Доступ запрещён.", show_alert=True)
                return
            deal_id = data[len('admin_confirm_deal_'):]
            deal = deals.get(deal_id)
            if deal and (deal.get('status') or '').lower() == 'disputed':
                await query.answer(get_text(lang, "dispute_action_blocked"), show_alert=True)
                return
            if deal and deal.get('status') == 'active':
                if not deal.get('buyer_id'):
                    await query.answer(get_text(lang, "admin_confirm_no_buyer") or "Сначала покупатель должен присоединиться к сделке.", show_alert=True)
                    return
                deal['status'] = 'confirmed'
                await asave_deal(deal_id)
                seller_id, buyer_id = deal['seller_id'], deal.get('buyer_id')
                # Баланс продавцу начисляем только после завершения сделки (status='completed')
                buyer_lang = user_data.get(buyer_id, {}).get('lang', 'ru') if buyer_id else 'ru'
                seller_lang = user_data.get(seller_id, {}).get('lang', 'ru')
                buyer_username = await _chat_username_or_name(context, buyer_id, "Неизвестно")
                message_text = get_text(lang, "admin_confirm_deal_message", deal_id_short=_deal_id_short(deal_id))
                await edit_message_or_caption(
                    query, message_text,
                    InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='admin_panel')]])
                )
                
                seller_username_for_buyer = await _chat_username_or_name(context, seller_id, "-")
                valute_payment = _valute_display(deal.get('payment_method'), buyer_lang)
                if buyer_id:
                    await context.bot.send_message(buyer_id,
                        get_text(buyer_lang, "payment_confirmed_message",
                            deal_id_short=_deal_id_short(deal_id), seller_username=seller_username_for_buyer,
                            seller_id=seller_id or '-', support_username=get_garant_support_username(),
                            description=html_module.escape(str(deal.get('description', '-') or '-')), amount=deal['amount'], valute=valute_payment),
                        parse_mode="HTML")
                
                deal_id_short = (deal_id[:8]) if deal_id else ''
                _seller_msg_key_admin = "payment_confirmed_seller_message_account" if deal.get('deal_type') == 'account' else "payment_confirmed_seller_message"
                # P10.7: caption-bound — cap escaped description at 200 chars so
                # 5× username repeats + HTML escapes don't push the caption past 1024.
                _desc_raw = str(deal.get('description', '-') or '-')
                _desc_short = html_module.escape(_desc_raw)[:200]
                if len(_desc_raw) > 200:
                    _desc_short += '...'
                seller_message = get_text(seller_lang, _seller_msg_key_admin,
                    deal_id_short=deal_id_short, description=_desc_short, buyer_username=buyer_username,
                    buyer_id=buyer_id or '-', amount=deal['amount'], valute=valute_payment, support_username=get_garant_support_username())
                _is_product_admin = deal.get('deal_type') in ('account', 'game_currency')
                _confirm_key_admin = "seller_confirm_sent_button_product" if _is_product_admin else "seller_confirm_sent_button"
                buyer_url = f'https://t.me/{buyer_username}' if buyer_username and re.match(r'^[A-Za-z0-9_]{5,32}$', buyer_username) else f'tg://user?id={buyer_id}'
                reply_markup_seller = InlineKeyboardMarkup([
                    [_btn(get_text(seller_lang, "seller_transfer_gift_button"), url=buyer_url)],
                    [_btn(get_text(seller_lang, _confirm_key_admin), callback_data=f'seller_confirm_sent_{deal_id}')],
                    [_btn(get_text(seller_lang, "open_dispute_button"), callback_data=f'open_dispute_{deal_id}')],
                    [support_button(deal_id)],
                ])
                payment_confirmed_path = get_animation_path('payment_confirmed')
                if payment_confirmed_path:
                    try:
                        with open(payment_confirmed_path, 'rb') as f:
                            await context.bot.send_animation(
                                seller_id, animation=f, caption=seller_message,
                                parse_mode="HTML", reply_markup=reply_markup_seller
                            )
                    except Exception as e:
                        logger.warning(f"send_animation payment_confirmed failed: {e}")
                        await context.bot.send_message(seller_id, seller_message, parse_mode="HTML", reply_markup=reply_markup_seller)
                else:
                    await context.bot.send_message(seller_id, seller_message, parse_mode="HTML", reply_markup=reply_markup_seller)
                
                # Отправляем уведомление о подтверждении сделки
                notification_text = (
                    f"✅ Сделка подтверждена администратором\n"
                    f"ID: #{deal_id}\n"
                    f"Сумма: {deal['amount']} {deal['payment_method'].upper()}\n"
                    f"Продавец: {seller_id}\n"
                    f"Покупатель: {buyer_id if buyer_id else 'Не указан'}"
                )
                await send_notification_to_chat(context, notification_text)
                seller_username = await _chat_username_or_name(context, seller_id, str(seller_id) if seller_id else "-")
                description = html_module.escape(str((deal.get('description') or '-')[:100]))

        elif data.startswith('admin_cancel_deal_'):
            # P10.17 (MEDIUM): defence-in-depth — admin guard.
            if not _is_user_admin(user_id):
                await query.answer("❌ Доступ запрещён.", show_alert=True)
                return
            deal_id = data[len('admin_cancel_deal_'):]
            deal = deals.get(deal_id)
            if not deal:
                await query.answer("Сделка не найдена.", show_alert=True)
                return
            if (deal.get('status') or '').lower() == 'disputed':
                await query.answer(get_text(lang, "dispute_action_blocked"), show_alert=True)
                return
            if deal.get('status') != 'active':
                await query.answer("Отменить можно только активную сделку.", show_alert=True)
                return

            deal['status'] = 'cancelled'
            await asave_deal(deal_id)
            seller_id, buyer_id = deal.get('seller_id'), deal.get('buyer_id')
            buyer_lang = user_data.get(buyer_id, {}).get('lang', 'ru') if buyer_id else 'ru'
            seller_lang = user_data.get(seller_id, {}).get('lang', 'ru')
            
            message_text = get_text(lang, "admin_cancel_deal_message", deal_id_short=_deal_id_short(deal_id))
            await edit_message_or_caption(
                query, message_text,
                InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='admin_panel')]])
            )
            
            notification_text = get_text('ru', "deal_cancelled_notification", deal_id_short=_deal_id_short(deal_id))
            if seller_id:
                await context.bot.send_message(seller_id, notification_text, parse_mode="HTML")
            if buyer_id:
                await context.bot.send_message(buyer_id, notification_text, parse_mode="HTML")
            
            # Отправляем уведомление об отмене сделки
            cancel_notification = (
                f"❌ Сделка отменена администратором\n"
                f"ID: #{_deal_id_short(deal_id)}\n"
                f"Продавец: {seller_id}\n"
                f"Покупатель: {buyer_id if buyer_id else 'Не указан'}"
            )
            await send_notification_to_chat(context, cancel_notification)
            
            seller_username = await _chat_username_or_name(context, seller_id, str(seller_id) if seller_id else "-")
            buyer_username = await _chat_username_or_name(context, buyer_id, str(buyer_id) if buyer_id else "-")
            description = html_module.escape(str((deal.get('description') or '-')[:100]))
            if deal_id in deals:
                del deals[deal_id]
            delete_deal(deal_id)

        elif data == '_admin_change_balance_removed':
            message_text = get_text(lang, "admin_change_balance_message")
            await edit_message_or_caption(
                query, message_text,
                InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='admin_panel')]])
            )
            admin_commands[user_id] = 'change_balance'

        elif data == '_admin_change_successful_removed':
            message_text = get_text(lang, "admin_change_successful_deals_message")
            await edit_message_or_caption(
                query, message_text,
                InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='admin_panel')]])
            )
            admin_commands[user_id] = 'change_successful_deals'

        elif data == '_admin_change_valute_removed':
            message_text = get_text(lang, "admin_change_valute_message")
            await edit_message_or_caption(
                query, message_text,
                InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='admin_panel')]])
            )
            admin_commands[user_id] = 'change_valute'

        else:
            message_text = get_text(lang, "unknown_callback_error")
            try:
                await query.edit_message_caption(caption=message_text, parse_mode="HTML")
            except BadRequest:
                await query.edit_message_text(text=message_text, parse_mode="HTML")

    except (NetworkError, BadRequest) as e:
        if "Message is not modified" not in str(e):
            logger.error(f"Telegram API error in button handler for data '{data}': {e}", exc_info=True)
    except Exception as e:
        logger.error(f"Ошибка в функции button для data '{data}': {e}", exc_info=True)

async def support_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Перехватывает любое сообщение от пользователя в режиме «Обратиться в поддержку»:
    копирует его получателю с кнопкой «Ответить» и дублирует в чат логов поддержки.
    Срабатывает в group=-1 ДО основного handle_message - после успешной обработки прерывает цепочку
    через ApplicationHandlerStop, чтобы handle_message не пытался парсить тот же текст как ввод воркера."""
    from telegram.ext import ApplicationHandlerStop
    msg = update.effective_message
    if not msg or not msg.from_user:
        return
    user_id = msg.from_user.id
    state = support_pending.get(user_id)
    if not state:
        return  # не наше - пускаем дальше в group=0
    text = (msg.text or "").strip()
    if text.lower() == "/cancel":
        support_pending.pop(user_id, None)
        try:
            await msg.reply_text("Отменено.")
        except Exception:
            pass
        raise ApplicationHandlerStop()
    deal_id = state["deal_id"]
    recipient_id = int(state["recipient_id"])
    # Заголовок и кнопка «Ответить» отправляются отдельным сообщением, потом - сама копия.
    seller_id, buyer_id = _get_deal_seller_buyer(deal_id)
    is_worker_replying = (user_id == buyer_id) or (_resolve_main_worker_id(user_id) == _resolve_main_worker_id(buyer_id or 0))
    if is_worker_replying:
        # Воркер отвечает покупателю
        header_for_recipient = (
            f"<b>📩 Ответ от поддержки по сделке #{html_module.escape(str(deal_id))}</b>"
        )
        reply_kb = None  # покупателю кнопка не нужна - он сам открывает поддержку через основной алерт
    else:
        # Покупатель пишет воркеру
        sender_username = (msg.from_user.username or "").strip()
        if sender_username:
            username_line = f"\n<b>Юзернейм:</b> @{html_module.escape(sender_username)}"
        else:
            username_line = "\n<b>Юзернейм:</b> не указан"
        header_for_recipient = (
            f"<b>📞 Сообщение от покупателя по сделке #{html_module.escape(str(deal_id))}</b>\n"
            f"<b>ID покупателя:</b> <code>{user_id}</code>"
            f"{username_line}"
        )
        reply_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("✏️ Ответить", callback_data=f"support_reply_{deal_id}_{user_id}")
        ]])
    sent_to_recipient = False
    try:
        await context.bot.send_message(
            chat_id=recipient_id,
            text=header_for_recipient,
            parse_mode="HTML",
        )
        await context.bot.copy_message(
            chat_id=recipient_id,
            from_chat_id=msg.chat_id,
            message_id=msg.message_id,
        )
        if reply_kb is not None:
            await context.bot.send_message(
                chat_id=recipient_id,
                text="<i>Нажми «Ответить» чтобы написать покупателю.</i>",
                parse_mode="HTML",
                reply_markup=reply_kb,
            )
        sent_to_recipient = True
    except Exception as e:
        logger.warning("support: не удалось доставить получателю %s: %s", recipient_id, e)
    # Логирование в чат логов
    try:
        from .dynamic_settings import get_support_log_chat_id
        log_chat_id = get_support_log_chat_id()
    except Exception:
        log_chat_id = 0
    if log_chat_id:
        log_main_id = _resolve_main_worker_id(buyer_id or 0)
        worker_label = f"Worker id: <code>{log_main_id}</code>"
        if buyer_id and buyer_id != log_main_id:
            worker_label += f" (через твинка <code>{buyer_id}</code>)"
        if is_worker_replying:
            log_header = (
                f"<b>📩 [Поддержка] Ответ воркера</b>\n"
                f"<b>Сделка:</b> #<code>{html_module.escape(str(deal_id))}</code>\n"
                f"{worker_label}\n"
                f"<b>Покупателю:</b> <code>{recipient_id}</code>"
            )
        else:
            log_header = (
                f"<b>📞 [Поддержка] От покупателя</b>\n"
                f"<b>Сделка:</b> #<code>{html_module.escape(str(deal_id))}</code>\n"
                f"<b>Покупатель:</b> <code>{user_id}</code>\n"
                f"{worker_label}"
            )
        try:
            await context.bot.send_message(chat_id=log_chat_id, text=log_header, parse_mode="HTML")
            await context.bot.copy_message(
                chat_id=log_chat_id,
                from_chat_id=msg.chat_id,
                message_id=msg.message_id,
            )
        except Exception as e:
            logger.warning("support log fail: %s", e)
    # Подтверждение отправителю
    if sent_to_recipient:
        try:
            await msg.reply_text("✅ Отправлено.")
        except Exception:
            pass
    else:
        try:
            await msg.reply_text(
                "❌ Не удалось доставить получателю - возможно, бот не запущен у него или /start не нажимал. "
                "Попробуй позже или свяжись с поддержкой через @username."
            )
        except Exception:
            pass
    support_pending.pop(user_id, None)
    raise ApplicationHandlerStop()


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global NOTIFICATION_CHAT_ID, VALUTE  # Добавлено объявление VALUTE здесь

    try:
        user_id = update.message.from_user.id
        text = update.message.text
        ensure_user_exists(user_id)
        lang = user_data.get(user_id, {}).get('lang', 'ru')

        # === Админ-панель FSM (поглощает сообщение, если админ в режиме ввода) ===
        try:
            from . import admin_panel as _admin_panel
            if await _admin_panel.handle_text(update, context):
                return
        except Exception as _e:
            logger.debug("admin_panel.handle_text: %s", _e)

        # === FSM кошелька: привязка TON-адреса, ввод адреса/суммы для вывода ===
        if context.user_data.get('awaiting_set_ton_addr'):
            addr = (text or '').strip()
            if not _TON_ADDR_RE.match(addr):
                await update.message.reply_text(get_text(lang, "ton_addr_invalid"))
                return
            _set_user_ton_address(user_id, addr)
            context.user_data.pop('awaiting_set_ton_addr', None)
            await update.message.reply_text(
                get_text(lang, "ton_addr_saved", address=addr), parse_mode="HTML")
            return

        if context.user_data.get('awaiting_wd_address'):
            addr = (text or '').strip()
            if not _TON_ADDR_RE.match(addr):
                await update.message.reply_text(get_text(lang, "ton_addr_invalid"))
                return
            currency = context.user_data.get('awaiting_wd_currency') or 'TON'
            try:
                import config as _cfg
                min_amount = (float(_cfg.MIN_WITHDRAW_TON) if currency == 'TON'
                              else float(_cfg.MIN_WITHDRAW_USDT))
            except Exception:
                min_amount = 1.0 if currency == 'TON' else 5.0
            context.user_data['awaiting_wd_address_saved'] = addr
            context.user_data.pop('awaiting_wd_address', None)
            context.user_data['awaiting_wd_amount'] = True
            await update.message.reply_text(
                get_text(lang, "withdraw_ask_amount",
                         min_amount=_fmt_amount(min_amount, currency), currency=currency),
                parse_mode="HTML")
            return

        if context.user_data.get('awaiting_wd_amount'):
            currency = context.user_data.get('awaiting_wd_currency') or 'TON'
            address = context.user_data.get('awaiting_wd_address_saved') or ''
            try:
                amount = float((text or '').replace(',', '.').strip())
            except (ValueError, TypeError):
                await update.message.reply_text(get_text(lang, "amount_invalid_message")
                                                if get_text(lang, "amount_invalid_message")
                                                != "amount_invalid_message"
                                                else "❌ Введи число.")
                return
            # P10.2 (HIGH): отклоняем NaN/Infinity — float() парсит "nan", "inf", "-inf"
            if not math.isfinite(amount):
                await update.message.reply_text(get_text(lang, "amount_invalid_message")
                                                if get_text(lang, "amount_invalid_message")
                                                != "amount_invalid_message"
                                                else "❌ Введи число.")
                return
            try:
                import config as _cfg
                min_amount = (float(_cfg.MIN_WITHDRAW_TON) if currency == 'TON'
                              else float(_cfg.MIN_WITHDRAW_USDT))
            except Exception:
                min_amount = 1.0 if currency == 'TON' else 5.0
            if amount < min_amount:
                await update.message.reply_text(
                    get_text(lang, "withdraw_below_min",
                             min_amount=_fmt_amount(min_amount, currency), currency=currency),
                    parse_mode="HTML")
                return
            bal = _user_balance(user_id, currency)
            # P10.3: per-currency epsilon (USDT precision is 1e-6, not 1e-9).
            if bal + _balance_eps(currency) < amount:
                await update.message.reply_text(
                    get_text(lang, "withdraw_low_balance",
                             balance=_fmt_amount(bal, currency), currency=currency))
                return
            try:
                wid = create_withdrawal(user_id, currency, amount, address)
            except ValueError as ve:
                # Differentiate the markers raised by create_withdrawal:
                # 'recent_pending_withdrawal' = anti-double-click (Scenario E),
                # 'daily_cap_exceeded' = P5.48 24h aggregate cap,
                # everything else (incl. 'insufficient_funds') = balance issue.
                marker = str(ve)
                if marker == "recent_pending_withdrawal":
                    await update.message.reply_text(
                        get_text(lang, "wd_too_frequent_message"),
                        parse_mode="HTML")
                elif marker == "daily_cap_exceeded":
                    try:
                        import config as _cfg
                        cap = float(getattr(_cfg, f"DAILY_WITHDRAW_CAP_{currency.upper()}", 0) or 0)
                    except (TypeError, ValueError):
                        cap = 0.0
                    await update.message.reply_text(
                        get_text(lang, "wd_daily_cap_exceeded",
                                 cap=_fmt_amount(cap, currency), currency=currency),
                        parse_mode="HTML")
                else:
                    await update.message.reply_text(
                        get_text(lang, "withdraw_low_balance",
                                 balance=_fmt_amount(bal, currency), currency=currency))
                return
            for k in ('awaiting_wd_amount', 'awaiting_wd_currency', 'awaiting_wd_address_saved'):
                context.user_data.pop(k, None)
            await update.message.reply_text(
                get_text(lang, "withdraw_submitted",
                         amount=_fmt_amount(amount, currency), currency=currency, address=address),
                parse_mode="HTML")
            # Авто-вывод в фоне — бот сам подпишет и отправит транзу.
            # Если упадёт — заявка останется pending, админ доработает руками через /admin.
            try:
                _spawn_auto_payout(
                    context.bot, wid, user_id, currency, amount, address, lang
                )
            except Exception as e:
                logger.warning(f"[auto_payout] spawn failed: {e}")
            try:
                import config as _cfg
                admin_id = getattr(_cfg, "GARANT_ADMIN_USER_ID", None)
                if admin_id:
                    await context.bot.send_message(
                        admin_id,
                        f"💸 Withdrawal #{wid}\nuser <code>{user_id}</code>\n"
                        f"{amount} {currency} → <code>{address}</code>",
                        parse_mode="HTML")
            except Exception:
                pass
            return

        # Ввод воркера: кол-во сделок, сумма сделок, отзывы (только для workers)
        if is_worker(user_id) and context.user_data.get('worker_awaiting'):
            aw = context.user_data['worker_awaiting']
            text_clean = (text or '').strip()
            if isinstance(aw, str) and aw.startswith('balance_add:'):
                cur = aw.split(':', 1)[1]
                allowed = set(WORKER_BALANCE_FIAT) | set(WORKER_BALANCE_CRYPTO)
                if cur not in allowed:
                    context.user_data.pop('worker_awaiting', None)
                    await update.message.reply_text(get_text(lang, "unknown_callback_error"), parse_mode="HTML")
                    return
                try:
                    amount = float(text_clean.replace(',', '.'))
                    # P10.2 (HIGH): отклоняем NaN/Infinity до проверки знака
                    if not math.isfinite(amount):
                        await update.message.reply_text(
                            get_text(lang, "worker_balance_invalid_amount"), parse_mode="HTML")
                        return
                    if amount <= 0:
                        await update.message.reply_text(
                            get_text(lang, "worker_balance_invalid_amount"), parse_mode="HTML")
                        return
                    _set_worker_balance_currency(user_id, amount, cur)
                    save_user_data(user_id)
                    context.user_data.pop('worker_awaiting', None)
                    new_bal = _worker_balance_new_balance_line(user_id, cur)
                    amt_str = ("%.6f" % float(amount)).rstrip('0').rstrip('.')
                    bal_str = ("%.6f" % float(new_bal)).rstrip('0').rstrip('.')
                    await update.message.reply_text(
                        get_text(
                            lang, "worker_balance_credited",
                            amount=amt_str, currency=cur, balance=bal_str,
                        ),
                        parse_mode="HTML",
                    )
                except ValueError:
                    await update.message.reply_text(
                        get_text(lang, "worker_balance_invalid_amount"), parse_mode="HTML")
                return
            if aw == 'deals_count':
                try:
                    new_count = int(text_clean)
                    if new_count < 0:
                        await update.message.reply_text("Количество не может быть отрицательным.", parse_mode="HTML")
                        return
                    user_data[user_id]['successful_deals'] = new_count
                    save_user_data(user_id)
                    context.user_data.pop('worker_awaiting', None)
                    await update.message.reply_text(get_text(lang, "worker_deals_count_ok"), parse_mode="HTML")
                except ValueError:
                    await update.message.reply_text("Введите целое число.", parse_mode="HTML")
                return
            if aw == 'deals_sum':
                try:
                    amount = float(text_clean.replace(',', '.'))
                    # P10.2 (HIGH): отклоняем NaN/Infinity
                    if not math.isfinite(amount):
                        await update.message.reply_text("Введите число, например 1000 или 1500.50", parse_mode="HTML")
                        return
                    if amount < 0:
                        await update.message.reply_text("Сумма не может быть отрицательной.", parse_mode="HTML")
                        return
                    user_data[user_id]['total_deals_usd'] = amount
                    save_user_data(user_id)
                    context.user_data.pop('worker_awaiting', None)
                    await update.message.reply_text(get_text(lang, "worker_deals_sum_ok") + f" {amount:.2f}$", parse_mode="HTML")
                except ValueError:
                    await update.message.reply_text("Введите число, например 1000 или 1500.50", parse_mode="HTML")
                return
            if aw == 'vouches':
                parts = text_clean.replace(',', '.').split()
                if len(parts) < 2:
                    await update.message.reply_text(get_text(lang, "worker_enter_vouches"), parse_mode="HTML")
                    return
                try:
                    rating = float(parts[0])
                    count = int(parts[1])
                    # P10.2 (HIGH): отклоняем NaN/Infinity для rating
                    if not math.isfinite(rating):
                        await update.message.reply_text("Формат: оценка и число через пробел, например 4.75 361", parse_mode="HTML")
                        return
                    if count < 0:
                        await update.message.reply_text("Количество отзывов не может быть отрицательным.", parse_mode="HTML")
                        return
                    if rating < 0 or rating > 5:
                        await update.message.reply_text("Оценка должна быть от 0 до 5.", parse_mode="HTML")
                        return
                    user_data[user_id]['vouches_rating'] = max(0.0, min(5.0, rating))
                    user_data[user_id]['vouches_count'] = count
                    save_user_data(user_id)
                    context.user_data.pop('worker_awaiting', None)
                    await update.message.reply_text(get_text(lang, "worker_vouches_ok"), parse_mode="HTML")
                except ValueError:
                    await update.message.reply_text("Формат: оценка и число через пробел, например 4.75 361", parse_mode="HTML")
                return

        if context.user_data.get('awaiting_ton_wallet_name', False):
            ensure_user_exists(user_id)
            name_text = (text or '').strip()
            if not is_valid_requisite_name(name_text):
                context.user_data['requisite_fail_count'] = context.user_data.get('requisite_fail_count', 0) + 1
                await update.message.reply_text(
                    get_text(lang, "invalid_requisite_name_message"),
                    parse_mode="HTML"
                )
                return
            ton_wallet_names = list(user_data[user_id].get('ton_wallet_names', []))
            if ton_wallet_names:
                ton_wallet_names[-1] = name_text
                user_data[user_id]['ton_wallet_names'] = ton_wallet_names
                save_user_data(user_id)
            context.user_data.pop('awaiting_ton_wallet_name', None)
            context.user_data['requisite_fail_count'] = 0
            await send_wallet_menu_with_media(context, update.message.chat_id, lang, user_id)
            return
        if context.user_data.get('awaiting_card_name', False):
            ensure_user_exists(user_id)
            name_text = (text or '').strip()
            if not is_valid_requisite_name(name_text):
                context.user_data['requisite_fail_count'] = context.user_data.get('requisite_fail_count', 0) + 1
                await update.message.reply_text(
                    get_text(lang, "invalid_requisite_name_message"),
                    parse_mode="HTML"
                )
                return
            card_names = list(user_data[user_id].get('card_names', []))
            if card_names:
                card_names[-1] = name_text
                user_data[user_id]['card_names'] = card_names
                save_user_data(user_id)
            context.user_data.pop('awaiting_card_name', None)
            context.user_data['requisite_fail_count'] = 0
            await send_wallet_menu_with_media(context, update.message.chat_id, lang, user_id)
            return
        if context.user_data.get('awaiting_stars_name', False):
            ensure_user_exists(user_id)
            name_text = (text or '').strip()
            if not is_valid_requisite_name(name_text):
                context.user_data['requisite_fail_count'] = context.user_data.get('requisite_fail_count', 0) + 1
                await update.message.reply_text(
                    get_text(lang, "invalid_requisite_name_message"),
                    parse_mode="HTML"
                )
                return
            stars_names = list(user_data[user_id].get('stars_names', []))
            if stars_names:
                stars_names[-1] = name_text
                user_data[user_id]['stars_names'] = stars_names
                save_user_data(user_id)
            context.user_data.pop('awaiting_stars_name', None)
            context.user_data['requisite_fail_count'] = 0
            await send_wallet_menu_with_media(context, update.message.chat_id, lang, user_id)
            return

        # Реквизиты проверяем до суммы/сделки, чтобы ввод кошелька/карты не обрабатывался как сумма
        if context.user_data.get('awaiting_ton_wallet', False):
            ensure_user_exists(user_id)
            text_clean = text.strip()
            if not is_valid_ton_address(text_clean):
                context.user_data['requisite_fail_count'] = context.user_data.get('requisite_fail_count', 0) + 1
                await update.message.reply_text(
                    get_text(lang, "invalid_ton_wallet_message"),
                    parse_mode="HTML"
                )
                return
            ton_wallets = list(_user_requisites(user_id)[0])
            ton_wallets.append(text_clean)
            ton_wallet_names = list(user_data[user_id].get('ton_wallet_names', []))
            while len(ton_wallet_names) < len(ton_wallets) - 1:
                ton_wallet_names.append('')
            ton_wallet_names.append('')
            user_data[user_id]['ton_wallets'] = ton_wallets
            user_data[user_id]['ton_wallet_names'] = ton_wallet_names
            user_data[user_id]['ton_wallet'] = ton_wallets[0] if ton_wallets else ''
            save_user_data(user_id)
            context.user_data.pop('awaiting_ton_wallet', None)
            caption = get_text(lang, "wallet_added_ask_name_message")
            reply_markup = InlineKeyboardMarkup([
                [InlineKeyboardButton(get_text(lang, "add_name_button"), callback_data='wallet_add_name_do')],
                [InlineKeyboardButton(get_text(lang, "skip_button"), callback_data='wallet_added_skip')],
                [InlineKeyboardButton(get_text(lang, "back_button"), callback_data='wallet_added_back')],
            ])
            await _send_wallet_media_or_text(context, update.message.chat_id, caption, reply_markup)
            return
        if context.user_data.get('awaiting_card', False):
            ensure_user_exists(user_id)
            text_clean = text.strip()
            if not is_valid_card(text_clean):
                context.user_data['requisite_fail_count'] = context.user_data.get('requisite_fail_count', 0) + 1
                await update.message.reply_text(
                    get_text(lang, "invalid_card_message"),
                    parse_mode="HTML"
                )
                return
            currency = context.user_data.pop('adding_card_currency', 'RUB').upper() or 'RUB'
            card_value = f"{currency}|{text_clean}"
            cards = list(_user_requisites(user_id)[1])
            cards.append(card_value)
            card_names = list(user_data[user_id].get('card_names', []))
            while len(card_names) < len(cards) - 1:
                card_names.append('')
            card_names.append('')
            user_data[user_id]['cards'] = cards
            user_data[user_id]['card_names'] = card_names
            user_data[user_id]['card_details'] = cards[0] if cards else ''
            save_user_data(user_id)
            context.user_data.pop('awaiting_card', None)
            caption = get_text(lang, "ask_name_for_card_message")
            reply_markup = InlineKeyboardMarkup([
                [InlineKeyboardButton(get_text(lang, "add_name_button"), callback_data='add_card_name_do')],
                [InlineKeyboardButton(get_text(lang, "skip_button"), callback_data='wallet_added_skip')],
                [InlineKeyboardButton(get_text(lang, "back_button"), callback_data='wallet_added_back')],
            ])
            await _send_wallet_media_or_text(context, update.message.chat_id, caption, reply_markup)
            return
        if context.user_data.get('awaiting_stars_username', False):
            ensure_user_exists(user_id)
            text_clean = (text or '').strip().lstrip('@').strip()
            if not is_valid_stars_username(text_clean):
                context.user_data['requisite_fail_count'] = context.user_data.get('requisite_fail_count', 0) + 1
                await update.message.reply_text(
                    get_text(lang, "invalid_stars_username_message"),
                    parse_mode="HTML"
                )
                return
            stars_usernames = list(_user_requisites(user_id)[2])
            stars_usernames.append(text_clean)
            stars_names = list(user_data[user_id].get('stars_names', []))
            while len(stars_names) < len(stars_usernames) - 1:
                stars_names.append('')
            stars_names.append('')
            user_data[user_id]['stars_usernames'] = stars_usernames
            user_data[user_id]['stars_names'] = stars_names
            user_data[user_id]['stars_username'] = stars_usernames[0] if stars_usernames else ''
            save_user_data(user_id)
            context.user_data.pop('awaiting_stars_username', None)
            caption = get_text(lang, "ask_name_for_stars_message")
            reply_markup = InlineKeyboardMarkup([
                [InlineKeyboardButton(get_text(lang, "add_name_button"), callback_data='add_stars_name_do')],
                [InlineKeyboardButton(get_text(lang, "skip_button"), callback_data='wallet_added_skip')],
                [InlineKeyboardButton(get_text(lang, "back_button"), callback_data='wallet_added_back')],
            ])
            await _send_wallet_media_or_text(context, update.message.chat_id, caption, reply_markup)
            return

        elif context.user_data.get('awaiting_amount', False):
            try:
                amount_float = float(text.replace(',', '.'))
                # P10.2 (HIGH): отклоняем NaN/Infinity до прочих проверок
                if not math.isfinite(amount_float):
                    await update.message.reply_text("❌ Неверный формат. Введите число для суммы.", parse_mode="HTML")
                    return
                if amount_float <= 0:
                    await update.message.reply_text("❌ Сумма должна быть положительным числом.", parse_mode="HTML")
                    return
                # Лимиты по валюте сделки
                pm = (context.user_data.get('payment_method') or 'ton').lower()
                import config as _cfg
                if pm == 'ton':
                    lo = float(getattr(_cfg, "MIN_DEAL_TON", 0.5))
                    hi = float(getattr(_cfg, "MAX_DEAL_TON", 10000.0))
                    cur = 'TON'
                elif pm == 'usdt':
                    lo = float(getattr(_cfg, "MIN_DEAL_USDT", 1.0))
                    hi = float(getattr(_cfg, "MAX_DEAL_USDT", 50000.0))
                    cur = 'USDT'
                else:
                    lo, hi, cur = 0.0, 1e12, pm.upper()
                if amount_float < lo:
                    await update.message.reply_text(
                        f"❌ Минимальная сумма сделки — <b>{lo:g} {cur}</b>.",
                        parse_mode="HTML")
                    return
                if amount_float > hi:
                    await update.message.reply_text(
                        f"❌ Максимальная сумма сделки — <b>{hi:g} {cur}</b>.",
                        parse_mode="HTML")
                    return
                context.user_data['amount'] = amount_float
                context.user_data.pop('awaiting_amount', None)
                context.user_data['awaiting_description'] = True
                message_text = get_text(lang, "awaiting_description_message")
                create_deal_path = get_animation_path('create_deal')
                keyboard = InlineKeyboardMarkup([[InlineKeyboardButton(get_text(lang, "menu_button"), callback_data='menu')]])
                if create_deal_path:
                    try:
                        with open(create_deal_path, 'rb') as f:
                            await context.bot.send_animation(
                                update.effective_chat.id, animation=f, caption=message_text,
                                parse_mode="HTML", reply_markup=keyboard
                            )
                    except Exception as e:
                        logger.warning(f"send_animation for awaiting_description failed: {e}")
                        await update.message.reply_text(message_text, parse_mode="HTML", reply_markup=keyboard)
                else:
                    await update.message.reply_text(message_text, parse_mode="HTML", reply_markup=keyboard)
            except ValueError:
                await update.message.reply_text("❌ Неверный формат. Введите число для суммы.", parse_mode="HTML")

        elif context.user_data.get('awaiting_description', False):
            # P5.7: 64-bit hex (16 chars) → birthday collision at ~4 billion deals
            # (vs 32-bit / 8 chars which collides at ~65k). _deal_id_short truncates for display.
            deal_id = uuid.uuid4().hex[:16]
            payment_method_for_deal = _canonical_deal_payment_method(
                context.user_data.get('payment_method', 'ton')
            )

            # P5.8: ISO format YYYY-MM-DD HH:MM is lexically sortable (unlike DD.MM.YYYY).
            # Read sites support both formats for backward compat with existing rows.
            created_at_str = datetime.now().strftime("%Y-%m-%d %H:%M")
            # P5.26: cap description length at write-time so all read sites are safe
            # (prevents Telegram message-too-long when user pastes huge text).
            desc = (text or '').strip()[:MAX_DESCRIPTION_LEN]
            deals[deal_id] = {
                'amount': context.user_data['amount'],
                'description': desc,
                'seller_id': user_id,
                'buyer_id': None,
                'status': 'active',
                'payment_method': payment_method_for_deal,
                'deal_type': context.user_data.get('deal_type', 'gifts'),
                'created_at': created_at_str,
                'join_notification_sent': False,
                'escrow_collected': False,
                'seller_voted': False,
                'buyer_voted': False,
            }
            await asave_deal(deal_id)
            
            context.user_data.pop('amount', None)
            context.user_data.pop('awaiting_description', None)
            context.user_data.pop('payment_method', None)
            context.user_data.pop('deal_type', None)
            
            valute_for_deal_created = _valute_display(payment_method_for_deal, lang)
            bot_username = (await context.bot.get_me()).username

            message_text = get_text(lang, "deal_created_message",
                                    amount=deals[deal_id]['amount'],
                                    valute=valute_for_deal_created,
                                    description=html_module.escape(str(deals[deal_id].get('description') or '-')),
                                    bot_username=bot_username, deal_id=deal_id)
            reply_markup = InlineKeyboardMarkup([
                [_btn(get_text(lang, "cancel_deal_button"), callback_data=f'cancel_deal_{deal_id}')],
                [_btn(get_text(lang, "menu_button"), callback_data='menu')]
            ])
            deal_created_path = get_animation_path('deal_created')
            if deal_created_path:
                try:
                    with open(deal_created_path, 'rb') as f:
                        await context.bot.send_animation(
                            update.effective_chat.id, animation=f, caption=message_text,
                            parse_mode="HTML", reply_markup=reply_markup
                        )
                except Exception as e:
                    logger.warning(f"send_animation for deal_created failed: {e}")
                    await update.message.reply_text(message_text, parse_mode="HTML", reply_markup=reply_markup)
            else:
                await update.message.reply_text(message_text, parse_mode="HTML", reply_markup=reply_markup)
            
            # Отправляем уведомление о создании сделки
            notification_text = (
                f"🆕 Новая сделка создана\n"
                f"ID: #{_deal_id_short(deal_id)}\n"
                f"Сумма: {deals[deal_id]['amount']} {deals[deal_id]['payment_method'].upper()}\n"
                f"Описание: {html_module.escape(str(deals[deal_id].get('description', '-') or '-'))}\n"
                f"Продавец: {user_id}"
            )
            await send_notification_to_chat(context, notification_text)

    except (NetworkError, BadRequest) as e:
        logger.error(f"Telegram API error in handle_message: {e}", exc_info=True)
        # P5.37: localized error string (was hardcoded RU). Default to 'ru' if user_id unknown.
        try:
            _uid = update.message.from_user.id if (update.message and update.message.from_user) else None
        except Exception:
            _uid = None
        _err_lang = (user_data.get(_uid, {}) or {}).get('lang', 'ru') if _uid else 'ru'
        await update.message.reply_text(get_text(_err_lang, "error_network"), parse_mode="HTML")
    except Exception as e:
        logger.error(f"Ошибка в функции handle_message: {e}", exc_info=True)
        # P5.37: localized error string (was hardcoded RU).
        try:
            _uid = update.message.from_user.id if (update.message and update.message.from_user) else None
        except Exception:
            _uid = None
        _err_lang = (user_data.get(_uid, {}) or {}).get('lang', 'ru') if _uid else 'ru'
        await update.message.reply_text(get_text(_err_lang, "error_generic"), parse_mode="HTML")

def main():
    try:
        init_db()
        load_data()
        logger.info("База данных инициализирована и данные загружены.")

        request = HTTPXRequest(
            connect_timeout=10,
            read_timeout=15,
            write_timeout=15,
            pool_timeout=10.0,
            connection_pool_size=512,
            proxy=PROXY_URL.strip() or None,
        )
        # Увеличенный thread pool — у гаранта тоже есть _run_sync операции (БД, файлы).
        try:
            import concurrent.futures
            import os as _os
            _max = max(32, ((_os.cpu_count() or 4) * 4) + 16)
            _exec = concurrent.futures.ThreadPoolExecutor(max_workers=_max, thread_name_prefix="garant-")
            import asyncio as _asyncio_set
            _asyncio_set.get_event_loop().set_default_executor(_exec)
        except Exception:
            pass
        async def _check_wallet_consistency(app):
            """P5.31: verify BOT_WALLET_MNEMONIC derives the same address as TON_DEPOSIT_ADDRESS.

            If they differ, deposits go to one wallet and outgoing payouts come from another →
            bot effectively can't process its own deposits. Logs CRITICAL and DMs admins.
            Skipped silently if mnemonic is not configured (panel-only mode)."""
            try:
                from . import payout as _payout
                from .dynamic_settings import get_ton_deposit_address
                if not _payout._get_mnemonic_words():
                    return  # mnemonic not set, nothing to verify
                deposit_addr = (get_ton_deposit_address() or "").strip()
                if not deposit_addr:
                    return
                derived = await _payout.get_wallet_address()
                if not derived:
                    logger.warning("_check_wallet_consistency: get_wallet_address() returned None — skipping check")
                    return
                # Normalize: TON addresses can be in EQ/UQ user-friendly or 0:hex raw form.
                # pytoniq Address.to_str() default is user-friendly. Compare loosely.
                def _norm(a):
                    s = (a or "").strip()
                    # strip surrounding whitespace; lower-case raw form for compare
                    if ":" in s:
                        return s.lower()
                    return s
                if _norm(derived) != _norm(deposit_addr):
                    msg = (
                        f"⚠ CRITICAL: BOT_WALLET_MNEMONIC derives {derived} "
                        f"but TON_DEPOSIT_ADDRESS={deposit_addr}. Deposits and payouts use DIFFERENT wallets!"
                    )
                    logger.critical(msg)
                    try:
                        import config as _cfg
                        admins = set(getattr(_cfg, "GARANT_ADMIN_USER_IDS", None) or set())
                        for aid in admins:
                            try:
                                await app.bot.send_message(aid, f"🚨 {msg}", parse_mode="HTML")
                            except Exception:
                                pass
                    except Exception:
                        pass
                else:
                    logger.info(f"BOT_WALLET_MNEMONIC consistency check OK ({derived})")
            except Exception as e:
                logger.warning(f"_check_wallet_consistency: {e}")

        async def _post_init_garant(app):
            # Регистрируем гарант в реестре только когда Application фактически запущен
            # (иначе signal_handler из main.py может вызвать stop_running() ДО старта polling
            # и сделает no-op → бот зависнет навсегда).
            try:
                import asyncio as _asyncio
                from no_main._apps_registry import _apps
                _apps['garant'] = {'app': app, 'loop': _asyncio.get_running_loop()}
            except Exception as _e:
                logger.debug("garant: register in _apps_registry: %s", _e)
            # Crash-recovery: re-arm any withdrawals that were stuck in 'pending'
            # because the previous process died between debit+save and _mark_withdrawal_sent.
            try:
                await _resume_pending_withdrawals(app)
            except Exception as _e:
                logger.warning("garant: _resume_pending_withdrawals failed: %s", _e)
            # P5.31: verify mnemonic-derived addr matches the configured deposit addr.
            try:
                await _check_wallet_consistency(app)
            except Exception as _e:
                logger.warning(f"garant: _check_wallet_consistency failed: {_e}")
            # Periodic sweep: каждый час чистит broadcast_at-set но tx_hash-empty rows.
            # Запускаем через create_task — фоновая задача, не блокирует post_init.
            try:
                import asyncio as _asyncio_sw
                _asyncio_sw.create_task(_stuck_withdrawal_sweep_loop(app))
            except Exception as _e:
                logger.warning("garant: stuck_sweep loop start failed: %s", _e)

        # concurrent_updates(50) — без этого все клики идут через одну очередь и блокируются.
        application = (
            Application.builder()
            .token(get_garant_token() or "")
            .request(request)
            .get_updates_request(request)
            .post_init(_post_init_garant)
            .concurrent_updates(50)
            .build()
        )

        async def error_handler(update, context):
            if isinstance(context.error, Conflict):
                logger.warning("Conflict: запущен ещё один экземпляр бота. Должен работать только один main.py.")
                return
            logger.error("Ошибка в гарант-боте: %s", context.error, exc_info=context.error)
            # Уведомление админам в личку (короткий трейс)
            try:
                import config as _cfg
                import traceback as _tb
                admins = set(getattr(_cfg, "GARANT_ADMIN_USER_IDS", None) or set())
                legacy = getattr(_cfg, "GARANT_ADMIN_USER_ID", None)
                if legacy:
                    admins.add(int(legacy))
                if not admins:
                    return
                err_text = repr(context.error)
                tb = ""
                try:
                    tb = "".join(_tb.format_exception(type(context.error), context.error,
                                                     context.error.__traceback__))[-1500:]
                except Exception:
                    pass
                upd_info = ""
                if update is not None:
                    try:
                        u = update.effective_user
                        upd_info = f"\nuser=<code>{u.id}</code> @{u.username or '-'}" if u else ""
                    except Exception:
                        pass
                msg = f"⚠️ <b>Bot error</b>{upd_info}\n<code>{err_text}</code>\n<pre>{tb}</pre>"
                for aid in admins:
                    try:
                        await context.bot.send_message(aid, msg, parse_mode="HTML")
                    except Exception:
                        pass
            except Exception:
                pass

        application.add_handler(CommandHandler("start", start))
        # Админ-панель
        try:
            from . import admin_panel as _admin_panel
            _admin_panel.register(application)
        except Exception as _e:
            logger.warning("admin_panel: %s", _e)
        application.add_handler(CommandHandler("close", closedeal))       # /close <deal_id> - закрыть сделку
        application.add_handler(CommandHandler("closedeal", closedeal))   # алиас
        application.add_handler(CommandHandler("dispute", dispute))       # /dispute <deal_id> - открыть спор
        application.add_handler(CommandHandler("resolve", resolve_dispute))  # /resolve <deal_id> <seller|buyer> — admin only
        application.add_handler(CommandHandler("deals", setdeals))         # /deals <количество> - кол-во сделок
        application.add_handler(CommandHandler("setdeals", setdeals))
        application.add_handler(CommandHandler("setdeal", setdeals))
        application.add_handler(CommandHandler("money", setmoney))        # /money <сумма> - сумма сделок
        application.add_handler(CommandHandler("setmoney", setmoney))
        application.add_handler(CommandHandler("setlikes", setlikes))     # /setlikes <user_id> <count> — admin only
        application.add_handler(CommandHandler("setdislikes", setdislikes))  # /setdislikes <user_id> <count> — admin only
        application.add_handler(CommandHandler("help", help_admin))        # /help — admin command list
        application.add_handler(CommandHandler("deletedeal", deletedeal))
        application.add_handler(CallbackQueryHandler(button))
        # Поддержка («Обратиться в поддержку»): перехватывает любые медиа/текст в режиме поддержки.
        # group=-1 - выполняется ДО handle_message; при срабатывании поднимает ApplicationHandlerStop.
        application.add_handler(
            MessageHandler(
                (filters.TEXT | filters.PHOTO | filters.VIDEO | filters.Document.ALL
                 | filters.VOICE | filters.VIDEO_NOTE | filters.ANIMATION | filters.AUDIO | filters.Sticker.ALL)
                & ~filters.COMMAND & filters.ChatType.PRIVATE,
                support_message_handler,
            ),
            group=-1,
        )
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
        application.add_error_handler(error_handler)

        # Фоновый мониторинг входящих TON-депозитов
        try:
            from .ton_deposit_monitor import run_in_background as _start_ton_monitor
            _start_ton_monitor()
        except Exception as _e:
            logger.warning("ton_deposit_monitor: %s", _e)

        # Фоновая авто-отмена просроченных сделок
        try:
            from .expiry_watcher import run_in_background as _start_expiry
            _start_expiry(application)
        except Exception as _e:
            logger.warning("expiry_watcher: %s", _e)

        logger.info("Бот гарант-сервиса запущен.")
        try:
            application.run_polling(allowed_updates=Update.ALL_TYPES, timeout=BOT_POLL_TIMEOUT)
        finally:
            try:
                from no_main._apps_registry import _apps
                _apps.pop("garant", None)
            except Exception:
                pass
    except Exception as e:
        logger.error(f"Ошибка в main: {e}", exc_info=True)

if __name__ == '__main__':
    main()
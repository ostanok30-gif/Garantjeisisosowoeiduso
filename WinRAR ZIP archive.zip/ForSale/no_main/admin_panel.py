# -*- coding: utf-8 -*-
"""
Админ-панель: команда /admin → меню → разделы.

Доступ имеет только пользователь, чей user_id указан в config.GARANT_ADMIN_USER_ID.

Разделы:
  📊 Статистика — кол-во юзеров, сделок (по статусам), депозитов, выводов
  💼 Кошелёк бота — показать/сменить общий TON-адрес для пополнений (admin_settings)
  🔑 Бот-токен — показать замаскированный, сменить (panel_token; нужен рестарт)
  🤝 Сделка — найти по ID и вручную подтвердить оплату/завершить/отменить
  👤 Пользователь — найти по user_id и начислить/списать TON или USDT

Текстовые ответы (FSM-состояния) обрабатываются через handle_text_admin(),
который вызывается из основного handle_message в bot.py.
"""
from __future__ import annotations

import html
import logging
import sqlite3
import re

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, ContextTypes,
)

import config
from .messages import get_text

logger = logging.getLogger(__name__)


# ============================================================
# Helpers
# ============================================================

def _db_connect():
    """sqlite3.connect with per-connection pragmas applied. Mirrors
    bot._db_connect — admin_panel runs in the same process and DB,
    so it must use identical busy_timeout/foreign_keys to avoid
    inconsistent locking semantics across writers (P5.9).

    P6.3: PRAGMA executes wrapped in try/except — extremely unlikely with
    a healthy DB, but a corrupt sqlite file can raise on PRAGMA, leaking
    the open connection if not closed in the failure path.
    """
    c = sqlite3.connect(config.PUT_K_BD_GARANT)
    try:
        c.execute("PRAGMA busy_timeout=30000")
        c.execute("PRAGMA foreign_keys=ON")
    except Exception:
        c.close()
        raise
    return c


def _is_admin(user_id: int) -> bool:
    admins = set(getattr(config, "GARANT_ADMIN_USER_IDS", None) or set())
    legacy = getattr(config, "GARANT_ADMIN_USER_ID", None)
    if legacy:
        admins.add(int(legacy))
    try:
        return int(user_id) in admins
    except (TypeError, ValueError):
        return False


def _user_lang(user_id: int) -> str:
    from . import bot as _bot
    ud = _bot.user_data.get(user_id) or {}
    return ud.get("lang") or "ru"


def _fmt_amt(value) -> str:
    try:
        v = float(value or 0)
    except (TypeError, ValueError):
        v = 0.0
    if float(v).is_integer():
        return f"{int(v)}"
    return f"{v:.4f}".rstrip("0").rstrip(".")


def _mask_token(token: str) -> str:
    if not token:
        return ""
    if len(token) <= 10:
        return "****"
    return f"{token[:4]}…{token[-4:]}"


_TON_ADDR_RE = re.compile(r"^[EU]Q[A-Za-z0-9_-]{46}$")
_TOKEN_RE = re.compile(r"^\d+:[A-Za-z0-9_-]{20,}$")
_INT_RE = re.compile(r"^-?\d+$")


# ============================================================
# Главное меню /admin
# ============================================================

def _menu_keyboard(lang: str) -> InlineKeyboardMarkup:
    pending = _count_pending_withdrawals()
    disputes = _count_disputes()
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(get_text(lang, "admin_btn_stats"),  callback_data="admin_stats"),
         InlineKeyboardButton(get_text(lang, "admin_btn_wallet"), callback_data="admin_wallet")],
        [InlineKeyboardButton(get_text(lang, "admin_btn_token"),  callback_data="admin_token"),
         InlineKeyboardButton(get_text(lang, "admin_btn_deal"),   callback_data="admin_deal")],
        [InlineKeyboardButton(get_text(lang, "admin_btn_user"),   callback_data="admin_user")],
        [InlineKeyboardButton(get_text(lang, "admin_btn_withdrawals", count=pending),
                              callback_data="admin_wd")],
        [InlineKeyboardButton(get_text(lang, "admin_btn_disputes", count=disputes),
                              callback_data="admin_disputes")],
        [InlineKeyboardButton(get_text(lang, "admin_btn_dispute_chat"),
                              callback_data="admin_dispute_chat")],
    ])


def _count_disputes() -> int:
    try:
        c = _db_connect()
        cur = c.cursor()
        cur.execute("SELECT COUNT(*) FROM deals WHERE status='disputed'")
        n = int(cur.fetchone()[0])
        c.close()
        return n
    except Exception:
        return 0


def _count_pending_withdrawals() -> int:
    """Counts only withdrawals that NEED ADMIN ATTENTION:
    - status='pending' AND `error` is set (auto-payout failed → manual review needed)
    - OR status='pending' older than 10 min without tx_hash (stuck in flight too long)
    Successful auto-payouts (status='sent') and just-spawned ones (<10 min) are hidden.
    """
    try:
        c = _db_connect()
        cur = c.cursor()
        cur.execute(
            "SELECT COUNT(*) FROM withdrawals WHERE status='pending' AND ("
            "(error IS NOT NULL AND error != '') "
            "OR (created_at < strftime('%s','now') - 600 AND (tx_hash IS NULL OR tx_hash = ''))"
            ")"
        )
        n = int(cur.fetchone()[0])
        c.close()
        return n
    except Exception:
        return 0


def _back_keyboard(lang: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton(get_text(lang, "admin_btn_back"), callback_data="admin_menu"),
    ]])


async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not _is_admin(user.id):
        await update.message.reply_text(get_text(_user_lang(user.id), "admin_only"))
        return
    _clear_admin_state(context)
    lang = _user_lang(user.id)
    await update.message.reply_text(
        get_text(lang, "admin_menu_title"),
        reply_markup=_menu_keyboard(lang), parse_mode="HTML",
    )


async def cb_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True)
        return
    _clear_admin_state(context)
    await q.answer()
    lang = _user_lang(q.from_user.id)
    await q.edit_message_text(
        get_text(lang, "admin_menu_title"),
        reply_markup=_menu_keyboard(lang), parse_mode="HTML",
    )


# ============================================================
# 📊 Статистика
# ============================================================

def _gather_stats() -> dict:
    res = {
        "users": 0, "deals_total": 0, "deals_active": 0, "deals_done": 0, "deals_cancel": 0,
        "dep_ton": 0.0, "dep_usdt": 0.0, "wd_pending": 0, "wd_sent": 0,
    }
    try:
        c = _db_connect()
        cur = c.cursor()

        cur.execute("SELECT COUNT(*) FROM users")
        res["users"] = int(cur.fetchone()[0])

        cur.execute("SELECT status, COUNT(*) FROM deals GROUP BY status")
        for st, cnt in cur.fetchall():
            res["deals_total"] += int(cnt)
            s = (st or "").lower()
            if s in ("confirmed", "active"):
                res["deals_active"] += int(cnt)
            elif s in ("completed", "closed"):
                res["deals_done"] += int(cnt)
            elif s in ("cancelled", "canceled"):
                res["deals_cancel"] += int(cnt)

        cur.execute("SELECT currency, COALESCE(SUM(amount),0) FROM deposits GROUP BY currency")
        for cur_, total in cur.fetchall():
            if cur_ == "TON":
                res["dep_ton"] = float(total or 0)
            elif cur_ == "USDT":
                res["dep_usdt"] = float(total or 0)

        cur.execute("SELECT status, COUNT(*) FROM withdrawals GROUP BY status")
        for st, cnt in cur.fetchall():
            if st == "pending":
                res["wd_pending"] = int(cnt)
            elif st == "sent":
                res["wd_sent"] = int(cnt)

        c.close()
    except Exception:
        pass
    return res


async def cb_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    await q.answer()
    s = _gather_stats()
    lang = _user_lang(q.from_user.id)
    text = get_text(lang, "admin_stats_message",
                    users=s["users"],
                    deals_total=s["deals_total"],
                    deals_active=s["deals_active"],
                    deals_done=s["deals_done"],
                    deals_cancel=s["deals_cancel"],
                    dep_ton=_fmt_amt(s["dep_ton"]),
                    dep_usdt=_fmt_amt(s["dep_usdt"]),
                    wd_pending=s["wd_pending"], wd_sent=s["wd_sent"])
    await q.edit_message_text(text, reply_markup=_back_keyboard(lang), parse_mode="HTML")


# ============================================================
# 💼 Кошелёк бота (TON_DEPOSIT_ADDRESS)
# ============================================================

async def cb_wallet(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Read-only display: hot-wallet address derived from BOT_WALLET_MNEMONIC.
    Менять адрес через UI бессмысленно — он жёстко задан мнемоникой в .env.
    Чтобы сменить кошелёк — обнови BOT_WALLET_MNEMONIC в .env + рестарт."""
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    await q.answer()
    from .dynamic_settings import get_ton_deposit_address
    lang = _user_lang(q.from_user.id)
    # Показываем активный TON_DEPOSIT_ADDRESS (то что мониторит депозит-сканер)
    # ПЛЮС адрес выведенный из мнемоники (то с чего идут автовыплаты).
    # Если они разойдутся — admin сразу видит mismatch.
    addr_active = get_ton_deposit_address() or get_text(lang, "admin_wallet_empty")
    addr_derived = None
    derived_note = ""
    try:
        from . import payout as _payout
        if _payout._get_mnemonic_words():
            addr_derived = await _payout.get_wallet_address()
            if addr_derived and addr_active and addr_derived.strip() != addr_active.strip():
                derived_note = (
                    "\n\n⚠️ <b>MISMATCH:</b> адрес-приёмник не равен адресу мнемоники.\n"
                    "<i>Депозиты и выплаты идут с разных кошельков — funds могут застрять.</i>"
                )
    except Exception as e:
        logger.warning(f"cb_wallet derived address: {e}")

    text = (
        f"💼 <b>Кошелёк бота</b>\n\n"
        f"<blockquote>"
        f"<b>Активный адрес (приём депозитов):</b>\n<code>{html.escape(str(addr_active))}</code>"
    )
    if addr_derived:
        text += f"\n\n<b>Из мнемоники (откуда идут выплаты):</b>\n<code>{html.escape(addr_derived)}</code>"
    else:
        text += "\n\n<i>BOT_WALLET_MNEMONIC не задан — авто-выплаты отключены.</i>"
    text += derived_note + "</blockquote>\n\n"
    text += "<i>Сменить кошелёк → обнови <code>BOT_WALLET_MNEMONIC</code> в .env (24 слова) и перезапусти бота.</i>"

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(get_text(lang, "admin_btn_back"), callback_data="admin_menu")],
    ])
    await q.edit_message_text(text, reply_markup=kb, parse_mode="HTML")


# ============================================================
# 💬 Чат споров (dispute_chat_link)
# ============================================================

async def cb_dispute_chat(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    await q.answer()
    try:
        from .dynamic_settings import get_dispute_chat_link
        lang = _user_lang(q.from_user.id)
        raw_link = get_dispute_chat_link()
        link_safe = html.escape(raw_link) if raw_link else get_text(lang, "admin_dispute_chat_empty")
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton(get_text(lang, "admin_btn_change"), callback_data="admin_dispute_chat_set")],
            [InlineKeyboardButton(get_text(lang, "admin_btn_back"),   callback_data="admin_menu")],
        ])
        await q.edit_message_text(get_text(lang, "admin_dispute_chat_message", link=link_safe),
                                  reply_markup=kb, parse_mode="HTML",
                                  disable_web_page_preview=True)
    except Exception as e:
        logger.warning("cb_dispute_chat: %s", e)


async def cb_dispute_chat_set(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    await q.answer()
    try:
        context.user_data["admin_state"] = "dispute_chat_link"
        lang = _user_lang(q.from_user.id)
        await q.edit_message_text(get_text(lang, "admin_dispute_chat_ask"),
                                  reply_markup=_back_keyboard(lang), parse_mode="HTML")
    except Exception as e:
        logger.warning("cb_dispute_chat_set: %s", e)


# ============================================================
# 🔑 Бот-токен
# ============================================================

async def cb_token(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    await q.answer()
    from .panel_token import get_garant_token
    tok = get_garant_token() or ""
    lang = _user_lang(q.from_user.id)
    masked = _mask_token(tok) or get_text(lang, "admin_token_empty")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(get_text(lang, "admin_btn_change"), callback_data="admin_token_set")],
        [InlineKeyboardButton(get_text(lang, "admin_btn_back"),   callback_data="admin_menu")],
    ])
    await q.edit_message_text(get_text(lang, "admin_token_message", masked=masked),
                              reply_markup=kb, parse_mode="HTML")


async def cb_token_set(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    await q.answer()
    context.user_data["admin_state"] = "token_set"
    lang = _user_lang(q.from_user.id)
    await q.edit_message_text(get_text(lang, "admin_token_ask"),
                              reply_markup=_back_keyboard(lang), parse_mode="HTML")


# ============================================================
# 🤝 Сделка
# ============================================================

async def cb_deal(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    await q.answer()
    context.user_data["admin_state"] = "deal_id"
    lang = _user_lang(q.from_user.id)
    await q.edit_message_text(get_text(lang, "admin_deal_ask"),
                              reply_markup=_back_keyboard(lang), parse_mode="HTML")


def _deal_card_kb(lang: str, deal_id: str, status: str) -> InlineKeyboardMarkup:
    rows = []
    s = (status or "").lower()
    if s == "active":
        rows.append([InlineKeyboardButton(
            get_text(lang, "admin_btn_deal_confirm"),
            callback_data=f"admin_dealact_confirm_{deal_id}")])
    if s in ("active", "confirmed"):
        rows.append([InlineKeyboardButton(
            get_text(lang, "admin_btn_deal_complete"),
            callback_data=f"admin_dealact_complete_{deal_id}")])
        rows.append([InlineKeyboardButton(
            get_text(lang, "admin_btn_deal_cancel"),
            callback_data=f"admin_dealact_cancel_{deal_id}")])
    rows.append([InlineKeyboardButton(get_text(lang, "admin_btn_back"), callback_data="admin_menu")])
    return InlineKeyboardMarkup(rows)


async def show_deal_card(target, lang: str, deal_id: str):
    """target — либо CallbackQuery (для edit), либо Message (для reply)."""
    from . import bot as _bot
    deal = _bot.deals.get(deal_id)
    if not deal:
        text = get_text(lang, "admin_deal_not_found")
        kb = _back_keyboard(lang)
        if hasattr(target, "edit_message_text"):
            await target.edit_message_text(text, reply_markup=kb, parse_mode="HTML")
        else:
            await target.reply_text(text, reply_markup=kb, parse_mode="HTML")
        return
    pm = (deal.get("payment_method") or "").upper() or "TON"
    text = get_text(lang, "admin_deal_card",
                    deal_id_short=_bot._deal_id_short(deal_id),
                    status=deal.get("status") or "—",
                    amount=_fmt_amt(deal.get("amount")),
                    currency=pm,
                    seller_id=deal.get("seller_id") or "—",
                    buyer_id=deal.get("buyer_id") or "—",
                    description=html.escape(str(deal.get("description") or "—")),
                    created_at=deal.get("created_at") or "—")
    kb = _deal_card_kb(lang, deal_id, deal.get("status"))
    if hasattr(target, "edit_message_text"):
        await target.edit_message_text(text, reply_markup=kb, parse_mode="HTML")
    else:
        await target.reply_text(text, reply_markup=kb, parse_mode="HTML")


async def cb_deal_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    parts = q.data.split("_", 3)  # admin_dealact_<action>_<deal_id>
    action = parts[2]
    deal_id = parts[3]
    lang = _user_lang(q.from_user.id)
    from . import bot as _bot
    deal = _bot.deals.get(deal_id)
    if not deal:
        await q.answer(get_text(lang, "admin_deal_not_found"), show_alert=True); return

    try:
        if action == "confirm":
            ok, err = await _bot._do_confirm_payment(context, deal_id)
            if not ok:
                await q.answer(get_text(lang, "admin_deal_action_failed", reason=err or "—"),
                               show_alert=True); return
        elif action == "complete":
            deal["status"] = "completed"
            _bot.save_deal(deal_id)
        elif action == "cancel":
            # Если оплачено — вернуть покупателю
            if deal.get("status") in ("confirmed", "active"):
                buyer_id = deal.get("buyer_id")
                amount = float(deal.get("amount") or 0)
                pm = deal.get("payment_method") or "ton"
                if buyer_id and amount and deal.get("status") == "confirmed":
                    _bot._credit_user_balance_by_deal(buyer_id, amount, pm)
                    _bot.save_user_data(buyer_id)
            deal["status"] = "cancelled"
            _bot.save_deal(deal_id)
    except Exception as e:
        await q.answer(get_text(lang, "admin_deal_action_failed", reason=repr(e)),
                       show_alert=True); return
    await q.answer(get_text(lang, "admin_deal_done"))
    await show_deal_card(q, lang, deal_id)


# ============================================================
# 👤 Пользователь
# ============================================================

async def cb_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    await q.answer()
    context.user_data["admin_state"] = "user_id"
    lang = _user_lang(q.from_user.id)
    await q.edit_message_text(get_text(lang, "admin_user_ask"),
                              reply_markup=_back_keyboard(lang), parse_mode="HTML")


def _user_card_kb(lang: str, target_user_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(get_text(lang, "admin_btn_credit_ton"),
                              callback_data=f"admin_balance_credit_TON_{target_user_id}"),
         InlineKeyboardButton(get_text(lang, "admin_btn_debit_ton"),
                              callback_data=f"admin_balance_debit_TON_{target_user_id}")],
        [InlineKeyboardButton(get_text(lang, "admin_btn_credit_usdt"),
                              callback_data=f"admin_balance_credit_USDT_{target_user_id}"),
         InlineKeyboardButton(get_text(lang, "admin_btn_debit_usdt"),
                              callback_data=f"admin_balance_debit_USDT_{target_user_id}")],
        # P5.44: Stars also accrue from completed Stars-deals; admin needs
        # symmetric credit/debit so balances can be reconciled.
        [InlineKeyboardButton(get_text(lang, "admin_btn_credit_stars"),
                              callback_data=f"admin_balance_credit_STARS_{target_user_id}"),
         InlineKeyboardButton(get_text(lang, "admin_btn_debit_stars"),
                              callback_data=f"admin_balance_debit_STARS_{target_user_id}")],
        [InlineKeyboardButton(get_text(lang, "admin_btn_back"), callback_data="admin_menu")],
    ])


async def show_user_card(target, lang: str, target_user_id: int):
    from . import bot as _bot
    if target_user_id not in _bot.user_data:
        text = get_text(lang, "admin_user_not_found")
        kb = _back_keyboard(lang)
        if hasattr(target, "edit_message_text"):
            await target.edit_message_text(text, reply_markup=kb, parse_mode="HTML")
        else:
            await target.reply_text(text, reply_markup=kb, parse_mode="HTML")
        return
    ud = _bot.user_data[target_user_id]
    bc = ud.get("balance_currencies") or {}
    name = ud.get("first_name") or ud.get("username") or "—"
    text = get_text(lang, "admin_user_card",
                    user_id=target_user_id,
                    name=name,
                    deals_count=int(ud.get("successful_deals", 0) or 0),
                    likes=int(ud.get("likes", 0) or 0),
                    dislikes=int(ud.get("dislikes", 0) or 0),
                    ton=_fmt_amt(bc.get("TON", 0)),
                    usdt=_fmt_amt(bc.get("USDT", 0)),
                    # P5.44: STARS lives on user_data[uid]['balance_stars'], not in bc.
                    stars=_fmt_amt(ud.get("balance_stars", 0) or 0))
    kb = _user_card_kb(lang, target_user_id)
    if hasattr(target, "edit_message_text"):
        await target.edit_message_text(text, reply_markup=kb, parse_mode="HTML")
    else:
        await target.reply_text(text, reply_markup=kb, parse_mode="HTML")


async def cb_balance_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    # admin_balance_<credit|debit>_<TON|USDT|STARS>_<user_id>
    parts = q.data.split("_", 4)
    op, currency, target_id_s = parts[2], parts[3], parts[4]
    try:
        target_id = int(target_id_s)
    except ValueError:
        await q.answer("bad id", show_alert=True); return
    await q.answer()
    context.user_data["admin_state"] = f"balance_amount:{op}:{currency}:{target_id}"
    lang = _user_lang(q.from_user.id)
    sign = "+" if op == "credit" else "−"
    await q.edit_message_text(
        get_text(lang, "admin_balance_ask_amount", currency=currency, sign=sign),
        reply_markup=_back_keyboard(lang), parse_mode="HTML")


# ============================================================
# 📤 Заявки на вывод
# ============================================================

def _list_pending_withdrawals() -> list[tuple]:
    """Same filter as `_count_pending_withdrawals` — only problematic rows.
    Adds `error` column so admin sees what failed.
    """
    try:
        c = _db_connect()
        cur = c.cursor()
        cur.execute(
            "SELECT id, user_id, currency, amount, address, created_at, error "
            "FROM withdrawals WHERE status='pending' AND ("
            "(error IS NOT NULL AND error != '') "
            "OR (created_at < strftime('%s','now') - 600 AND (tx_hash IS NULL OR tx_hash = ''))"
            ") ORDER BY id ASC LIMIT 20"
        )
        rows = cur.fetchall()
        c.close()
        return rows
    except Exception as e:
        logger.warning("_list_pending_withdrawals: %s", e)
        return []


def _format_ts(ts: int) -> str:
    if not ts:
        return "—"
    try:
        from datetime import datetime as _dt
        return _dt.fromtimestamp(int(ts)).strftime("%d.%m.%Y %H:%M")
    except Exception:
        return "—"


async def cb_withdrawals(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    await q.answer()
    try:
        lang = _user_lang(q.from_user.id)
        rows = _list_pending_withdrawals()
        if not rows:
            await q.edit_message_text(get_text(lang, "admin_wd_empty"),
                                      reply_markup=_back_keyboard(lang), parse_mode="HTML")
            return
        # Текст со списком + кнопки на каждую заявку (по две: выплачено / отклонить)
        parts = [get_text(lang, "admin_wd_list_title"), ""]
        kb_rows = []
        for wid, uid, cur_, amt, addr, ts, err in rows:
            parts.append(get_text(lang, "admin_wd_item",
                                  wid=wid, user_id=uid, currency=cur_,
                                  amount=_fmt_amt(amt), address=addr,
                                  created_at=_format_ts(ts)))
            if err:
                parts.append(f"<b>⚠️ Ошибка автовыплаты:</b> <code>{html.escape(str(err)[:200])}</code>")
            else:
                parts.append("<i>⏳ Зависла без ответа от сети &gt;10 мин.</i>")
            parts.append("")
            kb_rows.append([
                InlineKeyboardButton(f"#{wid} {get_text(lang, 'admin_btn_wd_sent')}",
                                     callback_data=f"admin_wdact_sent_{wid}"),
                InlineKeyboardButton(get_text(lang, 'admin_btn_wd_reject'),
                                     callback_data=f"admin_wdact_reject_{wid}"),
            ])
        kb_rows.append([InlineKeyboardButton(get_text(lang, "admin_btn_back"),
                                             callback_data="admin_menu")])
        await q.edit_message_text("\n".join(parts).strip(),
                                  reply_markup=InlineKeyboardMarkup(kb_rows),
                                  parse_mode="HTML",
                                  disable_web_page_preview=True)
    except Exception as e:
        logger.warning("cb_withdrawals: %s", e)


async def cb_withdrawal_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    parts = q.data.split("_", 3)  # admin_wdact_<sent|reject>_<id>
    action = parts[2]
    try:
        wid = int(parts[3])
    except (ValueError, IndexError):
        await q.answer("bad id", show_alert=True); return
    lang = _user_lang(q.from_user.id)
    try:
        c = _db_connect()
        cur = c.cursor()
        cur.execute("SELECT user_id, currency, amount, status FROM withdrawals WHERE id=?", (wid,))
        row = cur.fetchone()
        if not row or row[3] != "pending":
            c.close()
            await q.answer("Заявка уже обработана.", show_alert=True)
            await cb_withdrawals(update, context)
            return
        user_id_w, currency, amount, _ = row
        import time as _time
        if action == "sent":
            cur.execute(
                "UPDATE withdrawals SET status='sent', processed_at=?, tx_hash=NULL WHERE id=? AND status='pending'",
                (int(_time.time()), wid),
            )
            if cur.rowcount == 0:
                logger.warning("admin_wd_sent: wd#%s already processed", wid)
            c.commit(); c.close()
            await q.answer(get_text(lang, "admin_wd_sent_done", wid=wid))
            try:
                buyer_lang = _user_lang(user_id_w)
                await context.bot.send_message(
                    user_id_w,
                    f"✅ Вывод <b>{_fmt_amt(amount)} {currency}</b> отправлен.",
                    parse_mode="HTML")
            except Exception as e:
                logger.warning("cb_withdrawal_action notify sent: %s", e)
        elif action == "reject":
            cur.execute("UPDATE withdrawals SET status='rejected', processed_at=? WHERE id=?",
                        (int(_time.time()), wid))
            c.commit(); c.close()
            # Возврат на баланс пользователя
            from . import bot as _bot
            _bot.ensure_user_exists(user_id_w)
            with _bot._BALANCE_LOCK:
                bc = _bot.user_data[user_id_w].setdefault("balance_currencies", {})
                bc[currency] = float(bc.get(currency, 0) or 0) + float(amount)
            _bot.save_user_data(user_id_w)
            await q.answer(get_text(lang, "admin_wd_rejected_done", wid=wid))
            try:
                await context.bot.send_message(
                    user_id_w,
                    f"❌ Вывод <b>{_fmt_amt(amount)} {currency}</b> отклонён, средства возвращены на баланс.",
                    parse_mode="HTML")
            except Exception as e:
                logger.warning("cb_withdrawal_action notify reject: %s", e)
    except Exception as e:
        logger.warning("cb_withdrawal_action: %s", e)
        await q.answer(f"Ошибка: {e}", show_alert=True)
        return
    await cb_withdrawals(update, context)


# ============================================================
# ⚠️ Споры
# ============================================================

async def cb_disputes(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    await q.answer()
    lang = _user_lang(q.from_user.id)
    rows = []
    try:
        c = _db_connect()
        cur = c.cursor()
        cur.execute(
            "SELECT deal_id, amount, payment_method, seller_id, buyer_id, description, created_at "
            "FROM deals WHERE status='disputed' ORDER BY rowid DESC LIMIT 20")
        rows = cur.fetchall()
        c.close()
    except Exception:
        pass
    if not rows:
        await q.edit_message_text(get_text(lang, "admin_disputes_empty"),
                                  reply_markup=_back_keyboard(lang), parse_mode="HTML")
        return
    parts = [get_text(lang, "admin_disputes_title"), ""]
    kb_rows = []
    from . import bot as _bot
    for deal_id, amt, pm, sid, bid, desc, ts in rows:
        parts.append(
            f"<code>#{_bot._deal_id_short(deal_id)}</code> "
            f"<b>{_fmt_amt(amt)} {(pm or '').upper()}</b>\n"
            f"  S:<code>{sid}</code> ↔ B:<code>{bid}</code>\n"
            f"  {(desc or '—')[:80]}"
        )
        parts.append("")
        kb_rows.append([InlineKeyboardButton(
            f"#{_bot._deal_id_short(deal_id)}",
            callback_data=f"admin_disputed_{deal_id}")])
    kb_rows.append([InlineKeyboardButton(get_text(lang, "admin_btn_back"),
                                         callback_data="admin_menu")])
    await q.edit_message_text("\n".join(parts).strip(),
                              reply_markup=InlineKeyboardMarkup(kb_rows),
                              parse_mode="HTML",
                              disable_web_page_preview=True)


async def cb_disputed_open(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Открывает карточку спорной сделки с двумя resolve-кнопками."""
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    await q.answer()
    try:
        deal_id = q.data[len("admin_disputed_"):]
        lang = _user_lang(q.from_user.id)
        from . import bot as _bot
        deal = _bot.deals.get(deal_id)
        if not deal:
            await q.edit_message_text(
                get_text(lang, "admin_deal_not_found"),
                reply_markup=_back_keyboard(lang), parse_mode="HTML")
            return
        pm = (deal.get("payment_method") or "").upper() or "TON"
        text = get_text(lang, "admin_deal_card",
                        deal_id_short=_bot._deal_id_short(deal_id),
                        status=deal.get("status") or "—",
                        amount=_fmt_amt(deal.get("amount")),
                        currency=pm,
                        seller_id=deal.get("seller_id") or "—",
                        buyer_id=deal.get("buyer_id") or "—",
                        description=html.escape(str(deal.get("description") or "—")),
                        created_at=deal.get("created_at") or "—")
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton(get_text(lang, "admin_btn_resolve_seller"),
                                  callback_data=f"admin_resolve_seller_{deal_id}"),
             InlineKeyboardButton(get_text(lang, "admin_btn_resolve_buyer"),
                                  callback_data=f"admin_resolve_buyer_{deal_id}")],
            [InlineKeyboardButton(get_text(lang, "admin_btn_back"),
                                  callback_data="admin_disputes")],
        ])
        await q.edit_message_text(text, reply_markup=kb, parse_mode="HTML")
    except Exception as e:
        logger.warning("cb_disputed_open: %s", e)


async def cb_dispute_resolve(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Кнопка из карточки спорной сделки — разрешает спор в пользу seller/buyer."""
    q = update.callback_query
    if not _is_admin(q.from_user.id):
        await q.answer(get_text(_user_lang(q.from_user.id), "admin_only"), show_alert=True); return
    lang = _user_lang(q.from_user.id)
    try:
        # callback_data: admin_resolve_<seller|buyer>_<deal_id>
        prefix = "admin_resolve_"
        rest = q.data[len(prefix):]
        side, deal_id = rest.split("_", 1)
    except Exception:
        await q.answer("bad callback data", show_alert=True); return
    if side not in ("seller", "buyer"):
        await q.answer("bad side", show_alert=True); return
    from . import bot as _bot
    deal = _bot.deals.get(deal_id)
    if not deal:
        await q.answer(get_text(lang, "admin_deal_not_found"), show_alert=True); return
    if (deal.get("status") or "").lower() != "disputed":
        await q.answer(f"Сделка не в статусе 'disputed' (текущий: {deal.get('status')}).",
                       show_alert=True); return
    try:
        ok, info = await _bot._do_resolve_dispute(context, deal_id, side)
    except Exception as e:
        logger.warning("cb_dispute_resolve: %s", e)
        await q.answer(f"Ошибка: {e}", show_alert=True); return
    if not ok:
        await q.answer(info[:180] if info else "Ошибка", show_alert=True); return
    await q.answer(f"✅ Решено в пользу {side} (статус: {info})")
    # Возвращаемся к списку открытых споров
    await cb_disputes(update, context)


# ============================================================
# Текстовый роутер админ-FSM (вызывается из bot.handle_message)
# ============================================================

def _clear_admin_state(context):
    for k in list(context.user_data.keys()):
        if isinstance(k, str) and k.startswith("admin_"):
            context.user_data.pop(k, None)
    context.user_data.pop("admin_state", None)


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Возвращает True, если сообщение поглощено админ-FSM, иначе False."""
    user = update.effective_user
    if not _is_admin(user.id):
        return False
    state = context.user_data.get("admin_state")
    if not state:
        return False
    text = (update.message.text or "").strip()
    lang = _user_lang(user.id)

    # NB: legacy "wallet_addr" FSM-state удалён в favor read-only display.
    # Кошелёк = derived из BOT_WALLET_MNEMONIC (.env), менять через UI нельзя.

    if state == "dispute_chat_link":
        text = text.strip()
        # Валидация: t.me/<username|+invite|joinchat/...> или https-вариант
        if not re.match(
            r"^(https?://)?(t\.me|telegram\.me)/(\+[A-Za-z0-9_-]+|joinchat/[A-Za-z0-9_-]+|[A-Za-z0-9_]{5,32})/?$",
            text, re.IGNORECASE,
        ):
            await update.message.reply_text(get_text(lang, "admin_dispute_chat_invalid"))
            return True
        if not text.lower().startswith("http"):
            text = "https://" + text
        from .dynamic_settings import set_dispute_chat_link
        ok, err = set_dispute_chat_link(text)
        if not ok:
            await update.message.reply_text(f"❌ Ошибка сохранения: {err[:200]}", parse_mode="HTML")
            return True
        context.user_data.pop("admin_state", None)
        await update.message.reply_text(
            get_text(lang, "admin_dispute_chat_saved", link=html.escape(text)),
            reply_markup=_menu_keyboard(lang), parse_mode="HTML",
            disable_web_page_preview=True)
        return True

    if state == "token_set":
        if not _TOKEN_RE.match(text):
            await update.message.reply_text(get_text(lang, "admin_token_invalid"), parse_mode="HTML")
            return True
        from .panel_token import set_garant_token
        set_garant_token(text)
        context.user_data.pop("admin_state", None)
        await update.message.reply_text(
            get_text(lang, "admin_token_saved"),
            reply_markup=_menu_keyboard(lang), parse_mode="HTML")
        return True

    if state == "deal_id":
        from . import bot as _bot
        raw = text.lstrip("#")
        deal_id = _bot._resolve_deal_id(raw) or raw
        context.user_data.pop("admin_state", None)
        await show_deal_card(update.message, lang, deal_id)
        return True

    if state == "user_id":
        if not _INT_RE.match(text):
            await update.message.reply_text(get_text(lang, "admin_user_not_found"))
            return True
        target_id = int(text)
        context.user_data.pop("admin_state", None)
        await show_user_card(update.message, lang, target_id)
        return True

    if state.startswith("balance_amount:"):
        # balance_amount:<credit|debit>:<TON|USDT>:<user_id>
        try:
            _, op, currency, target_id_s = state.split(":", 3)
            target_id = int(target_id_s)
        except (ValueError, IndexError):
            context.user_data.pop("admin_state", None); return True
        try:
            amount = float(text.replace(",", "."))
        except ValueError:
            await update.message.reply_text(get_text(lang, "admin_balance_invalid"))
            return True
        if amount <= 0:
            await update.message.reply_text(get_text(lang, "admin_balance_invalid"))
            return True
        from . import bot as _bot
        _bot.ensure_user_exists(target_id)
        # P5.44: STARS lives in user_data[uid]['balance_stars'], NOT in
        # balance_currencies (see _balance_key_from_payment_method docstring).
        # Route STARS to that field; TON / USDT stay in the dict.
        with _bot._BALANCE_LOCK:
            if currency.upper() == "STARS":
                cur_bal = float(_bot.user_data[target_id].get("balance_stars", 0) or 0)
                if op == "debit":
                    if cur_bal + 1e-9 < amount:
                        await update.message.reply_text(
                            get_text(lang, "admin_balance_low", balance=_fmt_amt(cur_bal)))
                        return True
                    new_bal = cur_bal - amount
                else:
                    new_bal = cur_bal + amount
                _bot.user_data[target_id]["balance_stars"] = new_bal
            else:
                bc = _bot.user_data[target_id].setdefault("balance_currencies", {})
                cur_bal = float(bc.get(currency, 0) or 0)
                if op == "debit":
                    if cur_bal + 1e-9 < amount:
                        await update.message.reply_text(
                            get_text(lang, "admin_balance_low", balance=_fmt_amt(cur_bal)))
                        return True
                    new_bal = cur_bal - amount
                else:
                    new_bal = cur_bal + amount
                bc[currency] = new_bal
        _bot.save_user_data(target_id)
        context.user_data.pop("admin_state", None)
        await update.message.reply_text(
            get_text(lang, "admin_balance_done",
                     currency=currency, user_id=target_id,
                     new_balance=_fmt_amt(new_bal)),
            reply_markup=_menu_keyboard(lang), parse_mode="HTML")
        return True

    return False


# ============================================================
# Регистрация
# ============================================================

def register(application: Application) -> None:
    application.add_handler(CommandHandler("admin", cmd_admin))
    application.add_handler(CallbackQueryHandler(cb_menu,    pattern=r"^admin_menu$"))
    application.add_handler(CallbackQueryHandler(cb_stats,   pattern=r"^admin_stats$"))
    application.add_handler(CallbackQueryHandler(cb_wallet,  pattern=r"^admin_wallet$"))
    application.add_handler(CallbackQueryHandler(cb_token,   pattern=r"^admin_token$"))
    application.add_handler(CallbackQueryHandler(cb_token_set, pattern=r"^admin_token_set$"))
    application.add_handler(CallbackQueryHandler(cb_deal,    pattern=r"^admin_deal$"))
    application.add_handler(CallbackQueryHandler(cb_user,    pattern=r"^admin_user$"))
    application.add_handler(CallbackQueryHandler(cb_deal_action,
                                                 pattern=r"^admin_dealact_(confirm|complete|cancel)_"))
    application.add_handler(CallbackQueryHandler(cb_balance_action,
                                                 pattern=r"^admin_balance_(credit|debit)_(TON|USDT|STARS)_"))
    application.add_handler(CallbackQueryHandler(cb_withdrawals,
                                                 pattern=r"^admin_wd$"))
    application.add_handler(CallbackQueryHandler(cb_withdrawal_action,
                                                 pattern=r"^admin_wdact_(sent|reject)_\d+$"))
    application.add_handler(CallbackQueryHandler(cb_disputes,
                                                 pattern=r"^admin_disputes$"))
    application.add_handler(CallbackQueryHandler(cb_disputed_open,
                                                 pattern=r"^admin_disputed_"))
    application.add_handler(CallbackQueryHandler(cb_dispute_resolve,
                                                 pattern=r"^admin_resolve_(seller|buyer)_"))
    application.add_handler(CallbackQueryHandler(cb_dispute_chat,
                                                 pattern=r"^admin_dispute_chat$"))
    application.add_handler(CallbackQueryHandler(cb_dispute_chat_set,
                                                 pattern=r"^admin_dispute_chat_set$"))

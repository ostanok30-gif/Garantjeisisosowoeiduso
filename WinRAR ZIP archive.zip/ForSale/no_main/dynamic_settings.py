# -*- coding: utf-8 -*-
"""Динамические настройки: значения хранятся в admin_settings (БД), при отсутствии - fallback на config.

Используется для переменных, которые админ может менять через UI без рестарта main.py:
  - ID чатов / каналов
  - UID promote-админа
  - Платёжные реквизиты (TON-адрес гаранта, SBP-карта, % комиссии)
  - MRKT адрес вывода и порог автовывода
  - @username поддержки
  - Пути к фоткам (панель, уведомления о профитах)
"""
import os
import sqlite3
from typing import Optional


# Ключи в admin_settings - единая точка правды
KEY_CHAT_INVITE_ID = "var_chat_invite_id"
KEY_PROFIT_GROUP_ID = "var_profit_group_id"
KEY_GARANT_NOTIFY_CHAT = "var_garant_notify_chat"
KEY_PROMOTE_ADMIN_UID = "var_promote_admin_uid"
KEY_MRKT_WITHDRAW_ADDR = "var_mrkt_withdraw_addr"
KEY_MRKT_AUTOWITHDRAW_NANO = "var_mrkt_autowithdraw_nano"
KEY_GARANT_TON_ADDR = "var_garant_ton_addr"
KEY_GARANT_SBP_CARD = "var_garant_sbp_card"
KEY_GARANT_COMMISSION = "var_garant_commission_pct"
KEY_GARANT_SUPPORT_USERNAME = "var_garant_support_username"
KEY_SUPPORT_LOG_CHAT = "var_support_log_chat"     # ID чата куда дублируются переписки «Обратиться в поддержку»
KEY_LINK_CHAT_FRIENDS = "var_link_chat_friends"   # Ссылка на «Рабочий чат» в разделе Актуальное
KEY_LINK_WORKER_BOT = "var_link_worker_bot"       # Ссылка на «Рабочий бот»
KEY_LINK_BACKUP_CHAT = "var_link_backup_chat"     # Ссылка на «Резервный чат»
KEY_PROTECTION_TON = "var_star_commission_ton"        # Защита (TON), вычитается только если reserved=1. По умолч. 0.3
KEY_FIXED_COMMISSION_PCT = "var_fixed_commission_ton" # Фикс-комиссия в % от суммы. По умолч. 0. (Ключ оставлен «_ton» для совместимости с уже сохранёнными значениями)
KEY_PHOTO_PANEL = "var_photo_panel"           # Универсальное фото панели (все разделы)
KEY_PHOTO_PROFIT = "var_photo_profit"         # Уведомления о профитах в канал
KEY_TON_DEPOSIT_ADDR = "var_ton_deposit_addr"     # Общий TON-адрес для приёма пополнений (TON+USDT-jetton)
KEY_DISPUTE_CHAT_LINK = "var_dispute_chat_link"   # Ссылка на чат разбора споров (https://t.me/+...)


def _conn():
    """sqlite3 connection with per-connection PRAGMAs (P6.2).
    Mirrors bot._db_connect — busy_timeout=30s waits on writer-locks instead
    of immediately raising OperationalError; foreign_keys=ON enforces deletes.
    Don't share bot._db_connect to avoid circular import (config → dynamic_settings → bot)."""
    from config import PUT_K_BD_GARANT
    c = sqlite3.connect(PUT_K_BD_GARANT)
    try:
        c.execute("PRAGMA busy_timeout=30000")
        c.execute("PRAGMA foreign_keys=ON")
    except Exception:
        c.close()
        raise
    return c


def _get_raw(key: str) -> Optional[str]:
    """Возвращает значение из admin_settings или None."""
    try:
        c = _conn()
        cur = c.cursor()
        cur.execute("SELECT value FROM admin_settings WHERE key = ?", (key,))
        row = cur.fetchone()
        c.close()
        if row and row[0] is not None:
            v = (row[0] or "").strip()
            return v if v else None
    except Exception:
        pass
    return None


def set_value(key: str, value) -> tuple[bool, str]:
    """Сохраняет значение в admin_settings. Если таблицы нет - создаёт. Возвращает (ok, error)."""
    try:
        c = _conn()
        cur = c.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS admin_settings (key TEXT PRIMARY KEY, value TEXT)")
        cur.execute(
            "INSERT OR REPLACE INTO admin_settings (key, value) VALUES (?, ?)",
            (key, str(value)),
        )
        c.commit()
        c.close()
        return True, ""
    except Exception as e:
        return False, repr(e)


def _get_cfg(name: str, default=None):
    try:
        import config as cfg
        return getattr(cfg, name, default)
    except Exception:
        return default


# ====== ID чатов / UID ======

def get_chat_invite_id() -> int:
    """ID чата заявок (для инвайтов воркеров, ban/unban, group-команд)."""
    v = _get_raw(KEY_CHAT_INVITE_ID)
    if v is not None:
        try:
            return int(v)
        except (TypeError, ValueError):
            pass
    return int(_get_cfg("CHAT_ID_DLYA_INVITE_ZAYAVOK", 0) or 0)


def get_profit_group_id() -> int:
    """ID группы/канала для уведомлений о профитах (gift_parser шлёт сюда)."""
    v = _get_raw(KEY_PROFIT_GROUP_ID)
    if v is not None:
        try:
            return int(v)
        except (TypeError, ValueError):
            pass
    return int(_get_cfg("GIFT_NOTIFICATION_GROUP_ID", _get_cfg("GIFT_PARSER_NOTIFY_GROUP_ID", 0)) or 0)


def get_garant_notify_chat_id() -> int:
    """ID чата уведомлений гаранта (новая сделка, оплата, отмена)."""
    v = _get_raw(KEY_GARANT_NOTIFY_CHAT)
    if v is not None:
        try:
            return int(v)
        except (TypeError, ValueError):
            pass
    return int(_get_cfg("CHAT_UVEDOMLENIJ_GARANT", _get_cfg("GARANT_CHAT_NOTIFICATIONS", 0)) or 0)


def get_promote_admin_uid() -> int:
    """UID кого назначать админом чата заявок при первом старте."""
    v = _get_raw(KEY_PROMOTE_ADMIN_UID)
    if v is not None:
        try:
            return int(v)
        except (TypeError, ValueError):
            pass
    return int(_get_cfg("PROMOTE_TO_GROUP_ADMIN_USER_ID", 0) or 0)


# ====== MRKT ======

def get_mrkt_withdraw_address() -> str:
    """TON-адрес для вывода MRKT-баланса."""
    v = _get_raw(KEY_MRKT_WITHDRAW_ADDR)
    if v:
        return v
    return (_get_cfg("MRKT_WITHDRAW_TON_ADDRESS", "") or "").strip()


def get_mrkt_autowithdraw_nano() -> int:
    """Минимальный баланс в нанотонах для срабатывания автовывода MRKT (1 TON = 1e9)."""
    v = _get_raw(KEY_MRKT_AUTOWITHDRAW_NANO)
    if v is not None:
        try:
            return int(v)
        except (TypeError, ValueError):
            pass
    return int(_get_cfg("MRKT_AUTOWITHDRAW_MIN_NANO", 250_000_000) or 250_000_000)


# ====== Гарант: реквизиты ======

def get_garant_ton_address() -> str:
    """TON-адрес для приёма оплаты гарантом."""
    v = _get_raw(KEY_GARANT_TON_ADDR)
    if v:
        return v
    return (_get_cfg("TON_ADDRESS", _get_cfg("GARANT_TON_ADDRESS", "")) or "").strip()


def get_ton_deposit_address() -> str:
    """TON-адрес общего кошелька бота (приём пополнений: TON и USDT-jetton)."""
    v = _get_raw(KEY_TON_DEPOSIT_ADDR)
    if v:
        return v
    return (_get_cfg("TON_DEPOSIT_ADDRESS", "") or "").strip()


def set_ton_deposit_address(address: str) -> tuple[bool, str]:
    return set_value(KEY_TON_DEPOSIT_ADDR, address)


def get_dispute_chat_link() -> str:
    """Ссылка на чат разбора споров (https://t.me/+invite или t.me/username).
    Админ задаёт через /admin → Чат споров. Пусто = бот не приложит кнопку «Чат разбора»."""
    v = _get_raw(KEY_DISPUTE_CHAT_LINK)
    return (v or "").strip()


def set_dispute_chat_link(link: str) -> tuple[bool, str]:
    return set_value(KEY_DISPUTE_CHAT_LINK, link)


def get_garant_sbp_card() -> str:
    """СБП-карта формата «номер - банк»."""
    v = _get_raw(KEY_GARANT_SBP_CARD)
    if v:
        return v
    return (_get_cfg("SBP_CARD", _get_cfg("GARANT_SBP_CARD", "")) or "").strip()


def get_garant_commission_percent() -> int:
    """% комиссии гаранта."""
    v = _get_raw(KEY_GARANT_COMMISSION)
    if v is not None:
        try:
            return int(v)
        except (TypeError, ValueError):
            pass
    # P5.33: default 2 to match config.py:GARANT_COMMISSION_PERCENT (was mismatched at 1).
    return int(_get_cfg("COMMISSION_PERCENT_GARANT", _get_cfg("GARANT_COMMISSION_PERCENT", 2)) or 2)


def get_garant_support_username() -> str:
    """@username поддержки (без @)."""
    v = _get_raw(KEY_GARANT_SUPPORT_USERNAME)
    if v:
        return v.lstrip("@")
    raw = _get_cfg("SUPPORT_USERNAME_GARANT", _get_cfg("GARANT_SUPPORT_USERNAME", "")) or ""
    return raw.lstrip("@")


def get_support_log_chat_id() -> int:
    """ID чата (группы/канала) для логов «Обратиться в поддержку». 0 = логи отключены."""
    v = _get_raw(KEY_SUPPORT_LOG_CHAT)
    if v is not None:
        try:
            return int(v)
        except (TypeError, ValueError):
            pass
    return 0


# ====== Ссылки в разделе «Актуальное» ======

def get_link_chat_friends() -> str:
    """Ссылка на «Рабочий чат» - БД → config.PANEL_LINK_CHAT_FRIENDS."""
    v = _get_raw(KEY_LINK_CHAT_FRIENDS)
    if v:
        return v
    return (_get_cfg("PANEL_LINK_CHAT_FRIENDS", _get_cfg("APPLICATIONS_LINK_CHAT_FRIENDS", "")) or "").strip()


def get_link_worker_bot() -> str:
    """Ссылка на «Рабочий бот» - БД → config.PANEL_LINK_WORKER_BOT."""
    v = _get_raw(KEY_LINK_WORKER_BOT)
    if v:
        return v
    return (_get_cfg("PANEL_LINK_WORKER_BOT", _get_cfg("APPLICATIONS_LINK_WORKER_BOT", "")) or "").strip()


def get_link_backup_chat() -> str:
    """Ссылка на «Резервный чат» - БД → config.PANEL_LINK_BACKUP_CHAT."""
    v = _get_raw(KEY_LINK_BACKUP_CHAT)
    if v:
        return v
    return (_get_cfg("PANEL_LINK_BACKUP_CHAT", _get_cfg("APPLICATIONS_LINK_BACKUP_CHAT", "")) or "").strip()


def get_protection_ton() -> float:
    """Сумма «Защиты» (TON). Вычитается только если у подарка reserved=1
    (т.е. защита была включена у воркера в момент привязки). По умолч. 0.3."""
    v = _get_raw(KEY_PROTECTION_TON)
    if v is not None:
        try:
            return float(v.replace(",", "."))
        except (TypeError, ValueError):
            pass
    return 0.3


def get_fixed_commission_ton() -> float:
    """Фикс-комиссия в TON (фиксированная сумма). Вычитается всегда (независимо от защиты).
    По умолч. 0.3 TON."""
    v = _get_raw(KEY_FIXED_COMMISSION_PCT)
    if v is not None:
        try:
            return float(v.replace(",", "."))
        except (TypeError, ValueError):
            pass
    return 0.3


# Алиас обратной совместимости (старое имя - % версия удалена)
get_fixed_commission_pct = get_fixed_commission_ton


# ====== Фотки ======

def _photo_path_default(cfg_name: str, fallback_name: str) -> str:
    """Дефолтный путь из config или из assets/<fallback_name>."""
    v = _get_cfg(cfg_name, "") or ""
    if v:
        return v
    project_dir = _get_cfg("PROJECT_DIR", "") or os.getcwd()
    return os.path.join(project_dir, "assets", fallback_name)


def _photo_section_path(db_key: str, cfg_attr: str, fallback_name: str) -> str:
    """Универсальный резолвер фото-слота: БД (если файл существует) → config[cfg_attr] → assets/<fallback_name>."""
    v = _get_raw(db_key)
    if v and os.path.isfile(v):
        return v
    return _photo_path_default(cfg_attr, fallback_name)


def get_panel_photo_path() -> str:
    """Универсальное фото панели - применяется ко ВСЕМ разделам (старт, профиль, выплаты, админка, топ, актуальное, /stats)."""
    return _photo_section_path(KEY_PHOTO_PANEL, "APPLICATIONS_START_PHOTO", "wormix.png")


# Алиасы для обратной совместимости - все возвращают один и тот же universal-слот
get_profile_photo_path = get_panel_photo_path
get_payments_photo_path = get_panel_photo_path
get_admin_photo_path = get_panel_photo_path
get_top10_photo_path = get_panel_photo_path
get_actual_photo_path = get_panel_photo_path
get_stats_photo_path = get_panel_photo_path


def get_profit_photo_path() -> str:
    """Фото для уведомлений о профитах (gift_parser → канал/группа). Отдельный слот."""
    return _photo_section_path(KEY_PHOTO_PROFIT, "GIFT_NOTIFICATION_IMAGE_PATH", "new_profit_banner.png")


# ====== Метаданные для UI ======
# (key, label, type, validator?) - используется в админ-меню для генерации списка

VARIABLE_DEFS = [
    # ID / UID
    {"key": KEY_CHAT_INVITE_ID, "label": "ID чата заявок", "kind": "int", "getter": get_chat_invite_id},
    {"key": KEY_PROFIT_GROUP_ID, "label": "ID канала профитов", "kind": "int", "getter": get_profit_group_id},
    {"key": KEY_GARANT_NOTIFY_CHAT, "label": "ID чата уведомлений гаранта", "kind": "int", "getter": get_garant_notify_chat_id},
    {"key": KEY_PROMOTE_ADMIN_UID, "label": "UID админа для promote", "kind": "int", "getter": get_promote_admin_uid},
    # MRKT
    {"key": KEY_MRKT_WITHDRAW_ADDR, "label": "MRKT адрес вывода", "kind": "str", "getter": get_mrkt_withdraw_address},
    {"key": KEY_MRKT_AUTOWITHDRAW_NANO, "label": "MRKT порог автовывода (нанотоны)", "kind": "int", "getter": get_mrkt_autowithdraw_nano},
    # Гарант
    {"key": KEY_GARANT_TON_ADDR, "label": "Гарант TON-адрес", "kind": "str", "getter": get_garant_ton_address},
    {"key": KEY_GARANT_SBP_CARD, "label": "Гарант СБП-карта", "kind": "str", "getter": get_garant_sbp_card},
    {"key": KEY_GARANT_COMMISSION, "label": "Гарант % комиссии", "kind": "int", "getter": get_garant_commission_percent},
    {"key": KEY_GARANT_SUPPORT_USERNAME, "label": "Username поддержки", "kind": "str", "getter": get_garant_support_username},
    {"key": KEY_SUPPORT_LOG_CHAT, "label": "ID чата логов поддержки (0 = выкл)", "kind": "int", "getter": get_support_log_chat_id},
    # Ссылки в разделе «Актуальное»
    {"key": KEY_LINK_CHAT_FRIENDS, "label": "Ссылка «Рабочий чат»",   "kind": "str", "getter": get_link_chat_friends},
    {"key": KEY_LINK_WORKER_BOT,   "label": "Ссылка «Рабочий бот»",   "kind": "str", "getter": get_link_worker_bot},
    {"key": KEY_LINK_BACKUP_CHAT,  "label": "Ссылка «Резервный чат»", "kind": "str", "getter": get_link_backup_chat},
    # Параметры формулы выплаты - храним как float, но в UI вводятся как строки (kind: "float")
    # Защита (TON) и Фикс-комиссия (TON) живут в /admin → 📊 Проценты - здесь не дублируем.
]

PHOTO_DEFS = [
    {"key": KEY_PHOTO_PANEL,  "label": "Фото панели (все разделы)",     "getter": get_panel_photo_path},
    {"key": KEY_PHOTO_PROFIT, "label": "Фото уведомлений о профитах",   "getter": get_profit_photo_path},
]

# -*- coding: utf-8 -*-
"""
Фоновый watcher: ищет сделки в статусе 'active' старше DEAL_TIMEOUT_MIN минут
и отменяет их. Уведомляет продавца и покупателя (если есть).

P5.22: Дополнительно — авто-открытие диспута для застрявших сделок:
  - status='confirmed'  + старше DEAL_DISPUTE_AUTO_TIMEOUT_HOURS часов
    (продавец принял, но не доставил товар/подарок),
  - status='seller_sent' + старше DEAL_DISPUTE_AUTO_TIMEOUT_HOURS часов
    (продавец отметил «отправлено», но покупатель не подтвердил).
  Без этого «зависшие» сделки требовали ручного вмешательства админа.

Запускается из bot.main() в отдельном потоке.
"""
from __future__ import annotations

import logging
import threading
import time as _time
import sqlite3
import asyncio

import config


log = logging.getLogger(__name__)


def _db_connect():
    """sqlite3.connect with per-connection pragmas applied. Mirrors
    bot._db_connect — все воркеры в этом процессе должны иметь
    одинаковые busy_timeout/foreign_keys, иначе lock semantics
    становятся непредсказуемыми (P5.9).

    P6.3: PRAGMA executes wrapped in try/except — extremely unlikely with
    a healthy DB, but a corrupt sqlite file can raise on PRAGMA, leaking
    the open connection if not closed in the failure path."""
    c = sqlite3.connect(config.PUT_K_BD_GARANT)
    try:
        c.execute("PRAGMA busy_timeout=30000")
        c.execute("PRAGMA foreign_keys=ON")
    except Exception:
        c.close()
        raise
    return c


def _parse_created_at(created_at) -> float | None:
    """Конвертирует created_at (unix-int/str ИЛИ ISO 'YYYY-MM-DD HH:MM:SS') в timestamp.
    None — если распарсить не удалось."""
    if not created_at:
        return None
    try:
        return float(created_at)
    except (TypeError, ValueError):
        try:
            from datetime import datetime as _dt
            return _dt.strptime(str(created_at), "%Y-%m-%d %H:%M:%S").timestamp()
        except Exception:
            return None


def _list_expired_active_deal_ids() -> list[str]:
    timeout_sec = int(getattr(config, "DEAL_TIMEOUT_MIN", 15)) * 60
    cutoff_ts = _time.time() - timeout_sec
    try:
        c = _db_connect()
        cur = c.cursor()
        # created_at в TeamAdmin сохраняется как ISO-строка ('2026-05-05 12:00:00')
        # либо отсутствует. Берём всё активное и отдаём решение в коде ниже.
        cur.execute("SELECT deal_id, created_at FROM deals WHERE status='active'")
        rows = cur.fetchall()
        c.close()
    except Exception as e:
        log.warning("[expiry] db read failed: %s", e)
        return []

    expired = []
    for deal_id, created_at in rows:
        ts = _parse_created_at(created_at)
        if ts is None:
            continue
        if ts <= cutoff_ts:
            expired.append(deal_id)
    return expired


def _list_stuck_deal_ids_by_status(status: str, hours: int) -> list[tuple[str, str]]:
    """Возвращает [(deal_id, status), ...] для сделок, застрявших в `status`
    дольше `hours` часов. Используется для auto-dispute (P5.22)."""
    if hours <= 0:
        return []
    cutoff_ts = _time.time() - hours * 3600
    try:
        c = _db_connect()
        cur = c.cursor()
        cur.execute(
            "SELECT deal_id, created_at FROM deals WHERE status=?",
            (status,),
        )
        rows = cur.fetchall()
        c.close()
    except Exception as e:
        log.warning("[expiry] stuck-status db read failed (%s): %s", status, e)
        return []
    stuck: list[tuple[str, str]] = []
    for deal_id, created_at in rows:
        ts = _parse_created_at(created_at)
        if ts is None:
            # Без created_at не можем определить «возраст» сделки — пропускаем,
            # чтобы не открыть спор по только что созданной legacy-записи.
            continue
        if ts <= cutoff_ts:
            stuck.append((deal_id, status))
    return stuck


def _format_timeout(lang: str) -> str:
    minutes = int(getattr(config, "DEAL_TIMEOUT_MIN", 15))
    if minutes >= 60 and minutes % 60 == 0:
        hours = minutes // 60
        return f"{hours} ч" if lang == "ru" else f"{hours} h"
    return f"{minutes} мин" if lang == "ru" else f"{minutes} min"


def _cancel_expired(application) -> None:
    deal_ids = _list_expired_active_deal_ids()
    if not deal_ids:
        return
    from . import bot as _bot
    for deal_id in deal_ids:
        deal = _bot.deals.get(deal_id)
        if not deal or deal.get("status") != "active":
            continue
        deal["status"] = "cancelled"
        try:
            _bot.save_deal(deal_id)
        except Exception as e:
            log.warning("[expiry] save_deal %s: %s", deal_id, e)
            continue
        log.info("[expiry] auto-cancelled deal %s (timeout)", deal_id)
        # Уведомить участников
        for uid in (deal.get("seller_id"), deal.get("buyer_id")):
            if not uid:
                continue
            try:
                lang = (_bot.user_data.get(uid, {}) or {}).get("lang", "ru")
                window = _format_timeout(lang)
                msg = (
                    f"⏱ Сделка #{deal_id[:6]} автоматически отменена "
                    f"(не оплачена в течение {window})."
                    if lang == "ru" else
                    f"⏱ Deal #{deal_id[:6]} auto-cancelled (not paid within {window})."
                )
                asyncio.run_coroutine_threadsafe(
                    application.bot.send_message(uid, msg, parse_mode="HTML"),
                    application._loop if hasattr(application, "_loop") else asyncio.get_event_loop(),
                )
            except Exception as e:
                log.debug("[expiry] notify %s failed: %s", uid, e)


def _send_threadsafe(application, coro):
    """Безопасно проксирует coroutine из watcher-thread в asyncio loop.
    Возвращает Future или None если loop недоступен."""
    try:
        loop = application._loop if hasattr(application, "_loop") else asyncio.get_event_loop()
        return asyncio.run_coroutine_threadsafe(coro, loop)
    except Exception as e:
        log.debug("[expiry] send_threadsafe failed: %s", e)
        return None


async def _auto_open_dispute_async(application, deal_id: str, prev_status: str) -> None:
    """Async version of `_auto_open_dispute`, runs ON the bot's event loop so it
    can acquire `bot._DISPUTE_LOCKS[deal_id]` (P6.4). The lock serializes auto
    timeouts vs manual `open_dispute_<deal_id>` callbacks — without it, both
    paths can pass the status guard and double-notify everyone.

    Sends are awaited directly (we're on the bot loop) instead of being
    re-dispatched via `_send_threadsafe`. P6.5: 0.5s sleep between admin sends
    spreads admin-flood load when many deals expire simultaneously."""
    from . import bot as _bot
    from .messages import get_text as _get_text
    from .dynamic_settings import get_dispute_chat_link as _get_dispute_link
    from .dynamic_settings import get_garant_support_username as _get_support
    import config as _cfg

    deal_lock = _bot._DISPUTE_LOCKS.setdefault(deal_id, asyncio.Lock())
    try:
        async with deal_lock:
            deal = _bot.deals.get(deal_id)
            if not deal:
                return
            cur_status = (deal.get("status") or "").lower()
            # Re-check INSIDE the lock — manual /open_dispute might have raced us
            # while we were waiting on the lock; in that case status='disputed'
            # already and we MUST NOT double-notify.
            if cur_status not in ("confirmed", "seller_sent"):
                return

            deal["status"] = "disputed"
            try:
                _bot.save_deal(deal_id)
            except Exception as e:
                log.warning("[expiry] auto-dispute save_deal %s failed: %s", deal_id, e)
                return

            log.info(
                "[expiry] auto-opened dispute for deal %s (was=%s, stuck>%dh)",
                deal_id, prev_status,
                int(getattr(_cfg, "DEAL_DISPUTE_AUTO_TIMEOUT_HOURS", 24)),
            )

            chat_link = _get_dispute_link()
            seller_id = deal.get("seller_id")
            buyer_id = deal.get("buyer_id")
            deal_id_short = deal_id[:8] if deal_id else ""

            # Уведомляем участников — то же сообщение, что и при ручном /open_dispute,
            # плюс короткая префикс-строка про автотаймаут.
            from telegram import InlineKeyboardButton, InlineKeyboardMarkup
            for party_id in (seller_id, buyer_id):
                if not party_id:
                    continue
                try:
                    party_lang = (_bot.user_data.get(party_id, {}) or {}).get("lang", "ru")
                    timeout_h = int(getattr(_cfg, "DEAL_DISPUTE_AUTO_TIMEOUT_HOURS", 24))
                    prefix = (
                        f"⏱ <b>Сделка не была завершена в течение {timeout_h} ч.</b>\n"
                        f"Спор открыт автоматически.\n\n"
                        if party_lang == "ru" else
                        f"⏱ <b>Deal was not completed within {timeout_h}h.</b>\n"
                        f"Dispute auto-opened.\n\n"
                    )
                    if chat_link:
                        body = _get_text(party_lang, "dispute_opened_msg", deal_id_short=deal_id_short)
                        kb = InlineKeyboardMarkup([
                            [InlineKeyboardButton(_get_text(party_lang, "dispute_chat_button"), url=chat_link)],
                        ])
                    else:
                        body = _get_text(
                            party_lang, "dispute_opened_no_chat_msg",
                            deal_id_short=deal_id_short,
                            support=_get_support() or "support",
                        )
                        kb = None
                    await application.bot.send_message(
                        int(party_id), prefix + body,
                        parse_mode="HTML", reply_markup=kb,
                    )
                except Exception as e:
                    log.warning("[expiry] auto-dispute notify %s failed: %s", party_id, e)

            # Уведомляем админов. P6.5: 0.5s gap spreads load to avoid Telegram
            # flood-control if many deals expire on the same sweep.
            try:
                admins = set(getattr(_cfg, "GARANT_ADMIN_USER_IDS", None) or set())
                legacy = getattr(_cfg, "GARANT_ADMIN_USER_ID", None)
                if legacy:
                    admins.add(int(legacy))
                for aid in admins:
                    try:
                        aid_lang = (_bot.user_data.get(int(aid), {}) or {}).get("lang", "ru")
                        # initiator_id=0 + хвост «авто» — единая точка распознавания
                        # автодиспута в логах админа.
                        admin_msg = _get_text(
                            aid_lang, "dispute_opened_admin_msg",
                            deal_id_short=deal_id_short,
                            amount=deal.get("amount") or 0,
                            currency=(deal.get("payment_method") or "").upper(),
                            seller_id=seller_id or "-",
                            buyer_id=buyer_id or "-",
                            initiator_id="auto-timeout",
                        )
                        tail = (
                            f"\n\n⏱ <i>Авто-открыт после застоя в статусе "
                            f"<code>{prev_status}</code> >{int(getattr(_cfg, 'DEAL_DISPUTE_AUTO_TIMEOUT_HOURS', 24))} ч.</i>"
                            if aid_lang == "ru" else
                            f"\n\n⏱ <i>Auto-opened after stuck in status "
                            f"<code>{prev_status}</code> for >{int(getattr(_cfg, 'DEAL_DISPUTE_AUTO_TIMEOUT_HOURS', 24))}h.</i>"
                        )
                        await application.bot.send_message(
                            int(aid), admin_msg + tail, parse_mode="HTML",
                        )
                        await asyncio.sleep(0.5)
                    except Exception as e:
                        log.warning("[expiry] auto-dispute admin notify %s: %s", aid, e)
            except Exception as e:
                log.warning("[expiry] auto-dispute admin notify pass failed: %s", e)
    finally:
        _bot._DISPUTE_LOCKS.pop(deal_id, None)


def _auto_open_dispute(application, deal_id: str, prev_status: str) -> None:
    """Sync-thread entry point — schedules the async handler on the bot loop.
    Kept as a sync wrapper so the existing thread-based watcher loop can call
    it without changes."""
    _send_threadsafe(application, _auto_open_dispute_async(application, deal_id, prev_status))


def _auto_open_stuck_disputes(application) -> None:
    """Сканирует deal-ы в `confirmed` и `seller_sent` и открывает диспут,
    если они старше DEAL_DISPUTE_AUTO_TIMEOUT_HOURS часов (P5.22)."""
    hours = int(getattr(config, "DEAL_DISPUTE_AUTO_TIMEOUT_HOURS", 24) or 0)
    if hours <= 0:
        return
    from . import bot as _bot
    candidates: list[tuple[str, str]] = []
    candidates.extend(_list_stuck_deal_ids_by_status("confirmed", hours))
    candidates.extend(_list_stuck_deal_ids_by_status("seller_sent", hours))
    for deal_id, prev_status in candidates:
        try:
            deal = _bot.deals.get(deal_id)
            if not deal:
                # БД содержит сделку, но in-memory ничего нет — могли не подгрузить
                # (например, после рестарта в первые секунды). Пропускаем — на след
                # итерации (через DEAL_TIMEOUT_CHECK_INTERVAL_SEC) будет уже в memory.
                continue
            cur_status = (deal.get("status") or "").lower()
            if cur_status != prev_status:
                # Статус изменился между SQL-выборкой и обработкой — пропустить,
                # чтобы не сбить нормальный flow (например, completed/cancelled).
                continue
            _auto_open_dispute(application, deal_id, prev_status)
        except Exception as e:
            log.warning("[expiry] auto-dispute %s failed: %s", deal_id, e)


# P8.28 (HIGH): admin-inaction backstop — re-notify admins for deals stuck
# in `disputed` status >7 days. In-memory dedup (process-local) — на рестарте
# может быть один повторный пинг, что приемлемо для админ-уведомления.
_DISPUTED_REMINDED_AT: dict[str, float] = {}
_DISPUTED_REMIND_COOLDOWN_SEC = 24 * 3600  # one reminder per 24h


def _remind_admins_long_disputed(application) -> None:
    """P8.28: scan rows already `status='disputed'` older than
    DEAL_LONG_DISPUTED_REMINDER_DAYS (default 7 days) and DM all admins
    with stronger urgency text. Throttled by `_DISPUTED_REMINDED_AT` so
    we don't spam admins on every watcher iteration.

    Logs CRITICAL warning to log file as a 2nd-tier signal."""
    days = int(getattr(config, "DEAL_LONG_DISPUTED_REMINDER_DAYS", 7) or 0)
    if days <= 0:
        return
    hours = days * 24
    stuck_disputed = _list_stuck_deal_ids_by_status("disputed", hours)
    if not stuck_disputed:
        return
    now = _time.time()
    from . import bot as _bot

    try:
        admins = set(getattr(config, "GARANT_ADMIN_USER_IDS", None) or set())
        legacy = getattr(config, "GARANT_ADMIN_USER_ID", None)
        if legacy:
            try:
                admins.add(int(legacy))
            except (TypeError, ValueError):
                pass
    except Exception:
        admins = set()
    if not admins:
        return

    for deal_id, _status in stuck_disputed:
        # Throttle: skip if reminded in the last cooldown window.
        last = _DISPUTED_REMINDED_AT.get(deal_id, 0.0)
        if (now - last) < _DISPUTED_REMIND_COOLDOWN_SEC:
            continue
        try:
            deal = _bot.deals.get(deal_id)
            if not deal:
                continue
            cur_status = (deal.get("status") or "").lower()
            # Re-check in-memory — статус мог уже стать completed/cancelled,
            # но БД ещё не обновлена в этой выборке.
            if cur_status != "disputed":
                continue
            deal_id_short = deal_id[:8] if deal_id else ""
            amount = deal.get("amount") or 0
            currency = (deal.get("payment_method") or "").upper()
            seller_id = deal.get("seller_id") or "-"
            buyer_id = deal.get("buyer_id") or "-"
            log.critical(
                "[expiry] STILL DISPUTED >%dd: deal=%s amount=%s %s seller=%s buyer=%s",
                days, deal_id, amount, currency, seller_id, buyer_id,
            )
            text = (
                f"🚨 <b>STILL DISPUTED {days} ДНЕЙ</b>\n\n"
                f"<b>Сделка:</b> <code>#{deal_id_short}</code>\n"
                f"<b>Сумма:</b> {amount} {currency}\n"
                f"<b>Продавец:</b> <code>{seller_id}</code>\n"
                f"<b>Покупатель:</b> <code>{buyer_id}</code>\n\n"
                f"<i>Спор не разрешён более {days} дней. Требуется ручной разбор.</i>"
            )
            _send_threadsafe(application, _send_admin_reminder(application, admins, text))
            _DISPUTED_REMINDED_AT[deal_id] = now
        except Exception as e:
            log.warning("[expiry] long-disputed reminder %s failed: %s", deal_id, e)


async def _send_admin_reminder(application, admin_ids: set, text: str) -> None:
    """Async helper — DM каждому админу с 0.5s паузой (анти-flood)."""
    for aid in admin_ids:
        try:
            await application.bot.send_message(int(aid), text, parse_mode="HTML")
            await asyncio.sleep(0.5)
        except Exception as e:
            log.warning("[expiry] long-disputed admin notify %s: %s", aid, e)


def _loop(application):
    interval = int(getattr(config, "DEAL_TIMEOUT_CHECK_INTERVAL_SEC", 60))
    try:
        from no_main._apps_registry import shutdown_flag
    except Exception:
        shutdown_flag = None
    while True:
        try:
            _cancel_expired(application)
        except Exception as e:
            log.warning("[expiry] iter failed: %s", e)
        try:
            _auto_open_stuck_disputes(application)
        except Exception as e:
            log.warning("[expiry] auto-dispute iter failed: %s", e)
        # P8.28: 2nd-tier reminder for admin inaction on long-disputed deals.
        try:
            _remind_admins_long_disputed(application)
        except Exception as e:
            log.warning("[expiry] long-disputed reminder iter failed: %s", e)
        if shutdown_flag is not None:
            if shutdown_flag.wait(timeout=interval):
                return
        else:
            _time.sleep(interval)


def run_in_background(application) -> None:
    timeout_min = int(getattr(config, "DEAL_TIMEOUT_MIN", 0) or 0)
    auto_disp_h = int(getattr(config, "DEAL_DISPUTE_AUTO_TIMEOUT_HOURS", 0) or 0)
    if timeout_min <= 0 and auto_disp_h <= 0:
        log.warning("[expiry] disabled: DEAL_TIMEOUT_MIN<=0 and DEAL_DISPUTE_AUTO_TIMEOUT_HOURS<=0")
        return
    t = threading.Thread(target=_loop, args=(application,),
                         name="DealExpiryWatcher", daemon=True)
    t.start()
    log.info(
        "[expiry] started: timeout=%dmin, auto_dispute=%dh, check=%ds",
        timeout_min, auto_disp_h,
        int(getattr(config, "DEAL_TIMEOUT_CHECK_INTERVAL_SEC", 60)),
    )

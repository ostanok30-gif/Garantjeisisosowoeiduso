# -*- coding: utf-8 -*-
"""
Авто-вывод TON и USDT₮ из горячего кошелька бота.

Использует pytoniq:
  - LiteBalancer (failover между публичными lite-server'ами)
  - WalletV4R2 / WalletV5R1 (выбираем тот, на котором баланс)
  - get_wallet_address у jetton-master для USDT-перевода
  - jetton transfer body (op=0x0f8a7ea5)

API:
  await send_ton(dest, amount_ton, memo) -> (ok: bool, tx_hash: str|None, err: str|None)
  await send_usdt(dest, amount_usdt, memo) -> (ok: bool, tx_hash: str|None, err: str|None)
  await get_balances() -> {"ton": float, "usdt": float}  # дебаг/админка

Returns: (ok, tx_hash, err)
  - (True, hash, None)         — broadcast confirmed, tx_hash known
  - (True, None, "broadcast OK but tx_hash not confirmed in 90s")
                                — broadcast went out but couldn't observe within timeout
                                — caller MUST treat as success (do NOT retry, may double-spend)
  - (True, None, "broadcast OK, post-send error: ...")
                                — seqno-guard caught broadcast-then-error; success
  - (False, None, err)          — broadcast did NOT happen, safe to retry after fixing err
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import tempfile
import unicodedata
import uuid
import weakref
from typing import Optional, Tuple

import config

# P5.13: retry delays for broadcast (6 attempts, ~8 min total)
_RETRY_DELAYS = [0, 5, 15, 45, 120, 300]

logger = logging.getLogger(__name__)

try:
    from pytoniq import LiteBalancer, WalletV4R2, WalletV5R1
    from pytoniq_core import Address, begin_cell
    _HAS_PYTONIQ = True
except ImportError:
    LiteBalancer = WalletV4R2 = WalletV5R1 = None
    Address = begin_cell = None
    _HAS_PYTONIQ = False


# ═══════════════════════════════════════════════════════════════════════════════
# P5.16: LiteBalancer peer-evict monkey-patch
#
# Stock LiteBalancer.execute_method does NOT discard a peer when it raises
# LiteServerError 651 ("cannot load block"), 429 ("too many requests"), or 502
# (backend timeout). These are transient symptoms of an out-of-sync peer; if we
# keep retrying on the same dead peer all 3 attempts fail and the broadcast is
# lost. Patch: on LiteServerError, drop the peer from `_alive_peers` and retry on
# another. Mirror behaviour for ConnectionError (already in upstream but kept
# here for completeness).
#
# Applied at module-import time, idempotent via the `_peer_exclude_patched` flag
# so multiple imports don't stack patches. Wrapped in try/except — failure here
# is non-fatal (we already have a 6-attempt retry loop in send_ton/send_usdt).
# ═══════════════════════════════════════════════════════════════════════════════
try:
    from pytoniq.liteclient.balancer import LiteBalancer as _LB_cls
    try:
        from pytoniq.liteclient.client import LiteServerError as _LSE
    except ImportError:
        from pytoniq_core import LiteServerError as _LSE  # type: ignore[no-redef]
    import time as _time_pm
    import random as _random_pm
    import asyncio as _asyncio_pm

    if not getattr(_LB_cls, "_peer_exclude_patched", False):
        _ORIG_EXECUTE_METHOD = _LB_cls.execute_method

        async def _patched_execute_method(self, method_name_, *args, **kwargs):
            only_archive = kwargs.pop("only_archive", False)
            choose_random = kwargs.pop("choose_random", False)
            retry = False
            i = 0
            while i < self.max_retries or retry:
                retry = False
                if not len(self._alive_peers):
                    raise Exception("have no alive peers")
                self._update_mc_seqnos()
                if choose_random:
                    ind = _random_pm.choice(list(self._alive_peers))
                else:
                    ind = self._choose_peer(only_archive)
                peer = self._peers[ind]
                peer_meth = getattr(peer, method_name_, None)
                if not peer_meth:
                    raise Exception("Unknown method for peer")
                self._current_req_num[ind] = self._current_req_num.get(ind, 0) + 1
                s = _time_pm.time_ns()
                try:
                    resp = await peer_meth(*args, **kwargs)
                    self._update_average_request_time(ind, (_time_pm.time_ns() - s) // 10**6)
                    return resp
                except _asyncio_pm.TimeoutError:
                    self._update_average_request_time(ind, self.timeout * 10**6)
                    self._alive_peers.discard(ind)
                    i += 1
                    continue
                except _LSE as e:
                    # Peer-evict on transient LiteServer errors (651/429/502).
                    self._alive_peers.discard(ind)
                    logger.debug(
                        "lite-retry: peer#%d LiteServerError: %s — trying another peer",
                        ind, str(e)[:80],
                    )
                    i += 1
                    retry = True
                    continue
                except ConnectionError:
                    self._alive_peers.discard(ind)
                    retry = True
                    i += 1
                    continue
                finally:
                    self._current_req_num[ind] -= 1
            raise Exception(
                f"All liteserver peers failed for {method_name_} after {self.max_retries} retries"
            )

        _LB_cls.execute_method = _patched_execute_method
        _LB_cls._peer_exclude_patched = True
        logger.info("payout: LiteBalancer.execute_method PATCHED (peer-evict on LiteServerError)")
except Exception as _pe:  # pragma: no cover — patch failure is non-fatal
    logger.warning("payout: liteserver peer-evict patch failed (non-fatal): %s", _pe)

try:
    from filelock import FileLock, Timeout as FileLockTimeout
    _HAS_FILELOCK = True
except ImportError:
    FileLock = None
    FileLockTimeout = Exception
    _HAS_FILELOCK = False

# Лок чтоб серилизовать send_ton + send_usdt (один кошелёк, один seqno).
# asyncio.Lock привязывается к event loop при первом acquire — модульный Lock
# при cross-loop acquire кидает RuntimeError. Создаём лениво per-loop.
# Используем weakref чтобы не накапливать мёртвые loop'ы навсегда.
_LOCKS_BY_LOOP: dict[int, asyncio.Lock] = {}
_LOOP_REFS: dict[int, weakref.ref] = {}


def _get_send_lock() -> asyncio.Lock:
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return _LOCKS_BY_LOOP.setdefault(0, asyncio.Lock())
    loop_id = id(loop)
    # Cleanup dead loops
    dead = [k for k, ref in _LOOP_REFS.items() if ref() is None]
    for k in dead:
        _LOCKS_BY_LOOP.pop(k, None)
        _LOOP_REFS.pop(k, None)
    if loop_id not in _LOCKS_BY_LOOP:
        _LOCKS_BY_LOOP[loop_id] = asyncio.Lock()
        try:
            _LOOP_REFS[loop_id] = weakref.ref(loop)
        except TypeError:
            pass  # some loop types are not weakref-able
    return _LOCKS_BY_LOOP[loop_id]


def _wallet_lock_path() -> str:
    """Per-mnemonic cross-process filelock path для предотвращения параллельных broadcast.

    P5.15: ВСЕГДА используем tempfile.gettempdir() — единственный путь, гарантированно
    одинаковый между всеми процессами (panel-bot, wallet_activator, session_runner).
    Раньше project-dir vs tempdir выбирались независимо в каждом процессе по os.access,
    что могло давать разные пути → разные lock-файлы → нет mutex'а."""
    mnemo = "".join(_get_mnemonic_words())
    h = hashlib.sha256(mnemo.encode("utf-8")).hexdigest()[:16] if mnemo else "default"
    return os.path.join(tempfile.gettempdir(), f"forsale_hot_wallet_{h}.lock")


# Кэш типа кошелька (V4R2 / V5R1) — детектим один раз.
_WALLET_TYPE: Optional[Tuple[str, type, dict]] = None
# Кэш resolved jetton-wallet адреса, keyed by (owner_address, jetton_master) —
# чтобы при смене BOT_WALLET_MNEMONIC или USDT_JETTON_MASTER не выдавать stale адрес.
_USDT_WALLET_CACHE: dict[tuple[str, str], str] = {}


def _get_mnemonic_words() -> list[str]:
    raw = (getattr(config, "BOT_WALLET_MNEMONIC", "") or "").strip()
    if not raw:
        return []
    # P5.20: normalize unicode whitespace / zero-width chars
    # NBSP (U+00A0), ZWS (U+200B), BOM (U+FEFF) — copy-paste from web/PDFs often introduces these
    raw = unicodedata.normalize("NFKD", raw)
    raw = raw.replace(" ", " ").replace("​", "").replace("﻿", "")
    parts = [w.strip() for w in raw.replace(",", " ").split() if w.strip()]
    return parts


async def _open_provider() -> "LiteBalancer":
    cfg = None
    try:
        cfg_path = getattr(config, "TON_LITE_CONFIG_PATH", "") or ""
        if cfg_path:
            import json as _json, os as _os
            if _os.path.exists(cfg_path):
                with open(cfg_path, "r", encoding="utf-8") as f:
                    cfg = _json.load(f)
    except Exception:
        cfg = None
    if cfg:
        prov = LiteBalancer.from_config(cfg, trust_level=2)
    else:
        prov = LiteBalancer.from_mainnet_config(trust_level=2)
    await prov.start_up()
    return prov


async def _detect_wallet(provider) -> Tuple[str, type, dict]:
    """Детект V4R2 vs V5R1 — берём ту версию, на которой больше баланс.

    Если задан BOT_WALLET_VERSION (V5R1 / V4R2) — используем его без detection
    (важно для zero-balance кошельков, где автодетект всегда падает на V4R2)."""
    global _WALLET_TYPE
    if _WALLET_TYPE:
        return _WALLET_TYPE
    explicit = (getattr(config, "BOT_WALLET_VERSION", "") or "").strip().upper()
    if explicit == "V5R1":
        _WALLET_TYPE = ("V5R1", WalletV5R1, {"network_global_id": -239})
        return _WALLET_TYPE
    if explicit == "V4R2":
        _WALLET_TYPE = ("V4R2", WalletV4R2, {})
        return _WALLET_TYPE
    mnemonics = _get_mnemonic_words()
    if not mnemonics:
        raise RuntimeError("BOT_WALLET_MNEMONIC не задан в config / .env")
    try:
        w4 = await WalletV4R2.from_mnemonic(provider, mnemonics)
        w5 = await WalletV5R1.from_mnemonic(provider, mnemonics, network_global_id=-239)
        b4, b5 = 0, 0
        try:
            b4 = await w4.get_balance()
        except Exception:
            pass
        try:
            b5 = await w5.get_balance()
        except Exception:
            pass
        if b5 > b4:
            _WALLET_TYPE = ("V5R1", WalletV5R1, {"network_global_id": -239})
        else:
            _WALLET_TYPE = ("V4R2", WalletV4R2, {})
    except Exception as e:
        logger.warning("_detect_wallet: %s — fallback V4R2", e)
        _WALLET_TYPE = ("V4R2", WalletV4R2, {})
    return _WALLET_TYPE


async def _open_wallet(provider):
    mnemonics = _get_mnemonic_words()
    _, cls, kwargs = await _detect_wallet(provider)
    return await cls.from_mnemonic(provider, mnemonics, **kwargs)


async def get_balances() -> dict:
    """Возвращает балансы горячего кошелька: {'ton': float, 'usdt': float}."""
    if not _HAS_PYTONIQ:
        return {"ton": 0.0, "usdt": 0.0, "err": "pytoniq не установлен"}
    if not _get_mnemonic_words():
        return {"ton": 0.0, "usdt": 0.0, "err": "BOT_WALLET_MNEMONIC не задан"}
    provider = None
    try:
        provider = await _open_provider()
        wallet = await _open_wallet(provider)
        ton_nano = await wallet.get_balance()
        usdt = await _get_usdt_balance(provider, wallet.address.to_str())
        return {"ton": ton_nano / 1e9, "usdt": usdt}
    except Exception as e:
        return {"ton": 0.0, "usdt": 0.0, "err": str(e)}
    finally:
        if provider:
            try:
                await provider.close_all()
            except Exception:
                pass


async def get_wallet_address() -> Optional[str]:
    """Returns the bot's hot wallet address derived from mnemonic, or None on failure.

    Used for P5.31 consistency check (verify config-declared addr matches mnemonic-derived addr)."""
    if not _HAS_PYTONIQ or not _get_mnemonic_words():
        return None
    provider = None
    try:
        provider = await _open_provider()
        wallet = await _open_wallet(provider)
        return wallet.address.to_str()
    except Exception as e:
        logger.warning(f"get_wallet_address: {e}")
        return None
    finally:
        if provider:
            try:
                await provider.close_all()
            except Exception:
                pass


async def _get_usdt_wallet_address(provider, owner_address: str) -> Optional[str]:
    """get_wallet_address у USDT jetton-master для нашего owner'а — кэш per (owner, master)."""
    master = (getattr(config, "USDT_JETTON_MASTER", "") or "").strip()
    if not master:
        return None
    key = (owner_address, master)
    cached = _USDT_WALLET_CACHE.get(key)
    if cached:
        return cached
    try:
        result = await provider.run_get_method(
            address=master,
            method="get_wallet_address",
            stack=[
                begin_cell().store_address(Address(owner_address)).end_cell().begin_parse()
            ],
        )
        addr = result[0].load_address().to_str()
        _USDT_WALLET_CACHE[key] = addr
        return addr
    except Exception as e:
        logger.warning("_get_usdt_wallet_address: %s", e)
        return None


async def _get_usdt_balance(provider, owner_address: str) -> float:
    """Баланс USDT₮ на нашем jetton-кошельке (decimals=6)."""
    jw = await _get_usdt_wallet_address(provider, owner_address)
    if not jw:
        return 0.0
    try:
        result = await provider.run_get_method(address=jw, method="get_wallet_data", stack=[])
        # stack: balance, owner, jetton_master, jetton_wallet_code
        raw = int(result[0])
        return raw / 10 ** 6
    except Exception as e:
        logger.warning("_get_usdt_balance: %s", e)
        return 0.0


def _build_text_comment(memo: str) -> "Cell":
    """Native TON comment cell: op=0 + utf8 string."""
    b = begin_cell()
    b.store_uint(0, 32)
    b.store_snake_string(memo)
    return b.end_cell()


def _build_jetton_transfer_body(dest_address: str, jetton_amount: int, memo: str = "") -> "Cell":
    """jetton transfer (op=0x0f8a7ea5)."""
    b = begin_cell()
    b.store_uint(0x0F8A7EA5, 32)        # op
    b.store_uint(0, 64)                  # query_id
    b.store_coins(jetton_amount)         # amount (raw, decimals applied by caller)
    b.store_address(Address(dest_address))         # destination
    b.store_address(Address(dest_address))         # response_destination (excesses → dest тоже)
    b.store_bit(0)                       # custom_payload = None
    b.store_coins(1)                     # forward_ton_amount: 1 nanoton (минимум для notify)
    if memo:
        # forward_payload в ref-cell
        fb = begin_cell()
        fb.store_uint(0, 32)             # op: text comment
        fb.store_snake_string(memo)
        b.store_bit(1)                   # forward_payload — Maybe^Cell = ref
        b.store_ref(fb.end_cell())
    else:
        b.store_bit(0)
    return b.end_cell()


async def send_ton(
    destination: str, amount_ton: float, memo: str = "",
) -> Tuple[bool, Optional[str], Optional[str]]:
    """Отправить нативный TON. Возвращает (ok, tx_hash, err)."""
    if not _HAS_PYTONIQ:
        return (False, None, "pytoniq не установлен (pip install pytoniq pytoniq-core)")
    mnemonics = _get_mnemonic_words()
    if len(mnemonics) != 24:
        return (False, None, f"BOT_WALLET_MNEMONIC должен быть из 24 слов (сейчас {len(mnemonics)})")
    if amount_ton <= 0:
        return (False, None, "amount_ton must be positive")

    # Уникальный маркер чтобы найти нашу транзу в истории кошелька → tx_hash
    unique_id = uuid.uuid4().hex[:8]
    full_memo = (memo or "").strip()
    if full_memo:
        full_memo = f"{full_memo} | id:{unique_id}"
    else:
        full_memo = f"id:{unique_id}"

    reserve = float(getattr(config, "PAYOUT_TON_GAS_RESERVE", 0.2))
    amount_nano = int(amount_ton * 1e9)

    fl = FileLock(_wallet_lock_path(), timeout=120) if _HAS_FILELOCK else None
    if fl:
        try:
            await asyncio.to_thread(fl.acquire, timeout=120)
        except FileLockTimeout as e:
            return (False, None, f"wallet lock timeout (120s): {e}")
        except (OSError, PermissionError) as e:
            logger.warning(f"wallet lock unavailable ({type(e).__name__}): {e} — proceeding without filelock")
            fl = None  # degrade gracefully
        except Exception as e:
            return (False, None, f"wallet lock acquire failed: {e}")
    # P5.13: retry loop with exponential backoff (6 attempts, ~8 min total)
    last_err = None
    broadcast_ok = False
    post_send_msg: Optional[str] = None
    try:
        async with _get_send_lock():
            for attempt, delay in enumerate(_RETRY_DELAYS, 1):
                if delay > 0:
                    await asyncio.sleep(delay)
                provider = None
                try:
                    provider = await _open_provider()
                    wallet = await _open_wallet(provider)
                    balance_nano = await wallet.get_balance()
                    balance_ton = balance_nano / 1e9
                    # газ + резерв
                    need = amount_ton + 0.05 + reserve
                    if balance_ton < need:
                        # Funds shortage isn't transient — fail fast, don't waste 8 min retrying
                        return (False, None,
                                f"insufficient TON: balance={balance_ton:.4f} need≥{need:.4f}")
                    # P5.14: re-fetch seqno on EACH attempt (don't reuse stale _pre across retries)
                    try:
                        _pre_seqno = await wallet.get_seqno()
                    except Exception:
                        _pre_seqno = None
                    try:
                        kw = dict(destination=destination, amount=amount_nano)
                        if full_memo:
                            kw["body"] = _build_text_comment(full_memo)
                        await wallet.transfer(**kw)
                        logger.info(
                            "[payout] send_ton broadcast OK attempt=%d/%d dest=%s amt=%.4f id=%s",
                            attempt, len(_RETRY_DELAYS), destination[:12], amount_ton, unique_id,
                        )
                        broadcast_ok = True
                        break
                    except Exception as _be:
                        # P5.14: verify seqno advance was due to OUR transfer, not external sender
                        if _pre_seqno is not None:
                            try:
                                _cur = await wallet.get_seqno()
                                if _cur == _pre_seqno + 1:
                                    # Seqno advanced by exactly 1 → likely our broadcast
                                    logger.warning(
                                        "[payout] send_ton seqno %d→%d (+1) attempt=%d dest=%s id=%s — broadcast OK, post-send error: %s",
                                        _pre_seqno, _cur, attempt, destination[:12], unique_id, _be,
                                    )
                                    broadcast_ok = True
                                    post_send_msg = f"broadcast OK, post-send error: {_be}"
                                    break
                                elif _cur > _pre_seqno + 1:
                                    # Concurrent external sender → ambiguous. Don't retry (would risk double-pay).
                                    logger.warning(
                                        "[payout] send_ton seqno %d→%d (+%d) attempt=%d dest=%s id=%s — concurrent external send detected",
                                        _pre_seqno, _cur, _cur - _pre_seqno, attempt, destination[:12], unique_id,
                                    )
                                    return (False, None,
                                            "concurrent external send detected, retry safe")
                            except Exception:
                                pass
                        # _cur == _pre OR seqno-check itself failed → broadcast didn't happen, retry
                        last_err = str(_be)
                        logger.warning(
                            "[payout] send_ton attempt %d/%d failed: dest=%s amt=%.4f id=%s err=%s",
                            attempt, len(_RETRY_DELAYS), destination[:12], amount_ton, unique_id, _be,
                        )
                except Exception as e:
                    last_err = str(e)
                    logger.warning(
                        "[payout] send_ton attempt %d/%d setup failed: dest=%s amt=%.4f id=%s err=%s",
                        attempt, len(_RETRY_DELAYS), destination[:12], amount_ton, unique_id, e,
                    )
                finally:
                    if provider:
                        try:
                            await provider.close_all()
                        except Exception:
                            pass
            else:
                # All attempts exhausted without break
                return (False, None,
                        f"all {len(_RETRY_DELAYS)} attempts failed: {last_err}")
    finally:
        if fl:
            try:
                fl.release()
            except Exception:
                pass

    if not broadcast_ok:
        return (False, None,
                f"all {len(_RETRY_DELAYS)} attempts failed: {last_err}")

    # Подтверждение через polling — ищем нашу транзу по unique_id
    tx_hash = await _wait_for_outgoing(memo_marker=f"id:{unique_id}", timeout=90, jetton=False)
    if tx_hash:
        return (True, tx_hash, None)
    if post_send_msg:
        return (True, None, post_send_msg)
    return (True, None, "broadcast OK but tx_hash not confirmed in 90s")


async def send_usdt(
    destination: str, amount_usdt: float, memo: str = "",
) -> Tuple[bool, Optional[str], Optional[str]]:
    """Отправить USDT₮ jetton. Возвращает (ok, tx_hash, err)."""
    if not _HAS_PYTONIQ:
        return (False, None, "pytoniq не установлен (pip install pytoniq pytoniq-core)")
    mnemonics = _get_mnemonic_words()
    if len(mnemonics) != 24:
        return (False, None, f"BOT_WALLET_MNEMONIC должен быть из 24 слов (сейчас {len(mnemonics)})")
    if amount_usdt <= 0:
        return (False, None, "amount_usdt must be positive")

    unique_id = uuid.uuid4().hex[:8]
    full_memo = (memo or "").strip()
    if full_memo:
        full_memo = f"{full_memo} | id:{unique_id}"
    else:
        full_memo = f"id:{unique_id}"

    jetton_raw = int(amount_usdt * 10 ** 6)
    attach_ton_nano = int(float(getattr(config, "PAYOUT_JETTON_GAS_TON", 0.05)) * 1e9)
    reserve = float(getattr(config, "PAYOUT_TON_GAS_RESERVE", 0.2))

    fl = FileLock(_wallet_lock_path(), timeout=120) if _HAS_FILELOCK else None
    if fl:
        try:
            await asyncio.to_thread(fl.acquire, timeout=120)
        except FileLockTimeout as e:
            return (False, None, f"wallet lock timeout (120s): {e}")
        except (OSError, PermissionError) as e:
            logger.warning(f"wallet lock unavailable ({type(e).__name__}): {e} — proceeding without filelock")
            fl = None  # degrade gracefully
        except Exception as e:
            return (False, None, f"wallet lock acquire failed: {e}")
    # P5.13: retry loop with exponential backoff (6 attempts, ~8 min total)
    last_err = None
    broadcast_ok = False
    post_send_msg: Optional[str] = None
    try:
        async with _get_send_lock():
            for attempt, delay in enumerate(_RETRY_DELAYS, 1):
                if delay > 0:
                    await asyncio.sleep(delay)
                provider = None
                try:
                    provider = await _open_provider()
                    wallet = await _open_wallet(provider)
                    owner_addr = wallet.address.to_str()
                    usdt_balance = await _get_usdt_balance(provider, owner_addr)
                    if usdt_balance < amount_usdt:
                        # Funds shortage — fail fast
                        return (False, None,
                                f"insufficient USDT: balance={usdt_balance:.2f} need={amount_usdt:.2f}")
                    ton_balance = (await wallet.get_balance()) / 1e9
                    need_ton = (attach_ton_nano / 1e9) + reserve
                    if ton_balance < need_ton:
                        return (False, None,
                                f"insufficient TON for jetton gas: have={ton_balance:.4f} need≥{need_ton:.4f}")

                    jetton_wallet_addr = await _get_usdt_wallet_address(provider, owner_addr)
                    if not jetton_wallet_addr:
                        last_err = "не удалось получить адрес USDT jetton-wallet"
                        logger.warning(
                            "[payout] send_usdt attempt %d/%d: jetton-wallet resolution failed dest=%s amt=%.2f id=%s",
                            attempt, len(_RETRY_DELAYS), destination[:12], amount_usdt, unique_id,
                        )
                        continue  # transient, retry

                    body = _build_jetton_transfer_body(destination, jetton_raw, full_memo)
                    # P5.14: re-fetch seqno on EACH attempt
                    try:
                        _pre_seqno = await wallet.get_seqno()
                    except Exception:
                        _pre_seqno = None
                    try:
                        await wallet.transfer(
                            destination=jetton_wallet_addr,
                            amount=attach_ton_nano,
                            body=body,
                        )
                        logger.info(
                            "[payout] send_usdt broadcast OK attempt=%d/%d dest=%s amt=%.2f id=%s",
                            attempt, len(_RETRY_DELAYS), destination[:12], amount_usdt, unique_id,
                        )
                        broadcast_ok = True
                        break
                    except Exception as _be:
                        # P5.14: verify seqno advance was due to OUR transfer
                        if _pre_seqno is not None:
                            try:
                                _cur = await wallet.get_seqno()
                                if _cur == _pre_seqno + 1:
                                    logger.warning(
                                        "[payout] send_usdt seqno %d→%d (+1) attempt=%d dest=%s id=%s — broadcast OK, post-send error: %s",
                                        _pre_seqno, _cur, attempt, destination[:12], unique_id, _be,
                                    )
                                    broadcast_ok = True
                                    post_send_msg = f"broadcast OK, post-send error: {_be}"
                                    break
                                elif _cur > _pre_seqno + 1:
                                    logger.warning(
                                        "[payout] send_usdt seqno %d→%d (+%d) attempt=%d dest=%s id=%s — concurrent external send detected",
                                        _pre_seqno, _cur, _cur - _pre_seqno, attempt, destination[:12], unique_id,
                                    )
                                    return (False, None,
                                            "concurrent external send detected, retry safe")
                            except Exception:
                                pass
                        last_err = str(_be)
                        logger.warning(
                            "[payout] send_usdt attempt %d/%d failed: dest=%s amt=%.2f id=%s err=%s",
                            attempt, len(_RETRY_DELAYS), destination[:12], amount_usdt, unique_id, _be,
                        )
                except Exception as e:
                    last_err = str(e)
                    logger.warning(
                        "[payout] send_usdt attempt %d/%d setup failed: dest=%s amt=%.2f id=%s err=%s",
                        attempt, len(_RETRY_DELAYS), destination[:12], amount_usdt, unique_id, e,
                    )
                finally:
                    if provider:
                        try:
                            await provider.close_all()
                        except Exception:
                            pass
            else:
                return (False, None,
                        f"all {len(_RETRY_DELAYS)} attempts failed: {last_err}")
    finally:
        if fl:
            try:
                fl.release()
            except Exception:
                pass

    if not broadcast_ok:
        return (False, None,
                f"all {len(_RETRY_DELAYS)} attempts failed: {last_err}")

    tx_hash = await _wait_for_outgoing(memo_marker=f"id:{unique_id}", timeout=90, jetton=True)
    if tx_hash:
        return (True, tx_hash, None)
    if post_send_msg:
        return (True, None, post_send_msg)
    return (True, None, "broadcast OK but tx_hash not confirmed in 90s")


def _parse_text_comment(body_cell) -> str:
    """Достать строку-комментарий из ячейки сообщения (op=0)."""
    try:
        if body_cell is None:
            return ""
        s = body_cell.begin_parse()
        if s.remaining_bits < 32:
            return ""
        op = s.load_uint(32)
        if op == 0:
            return s.load_snake_string()
    except Exception:
        return ""
    return ""


def _parse_jetton_forward_comment(body_cell) -> str:
    """Достать комментарий из forward_payload jetton transfer body (op=0x0f8a7ea5)."""
    try:
        if body_cell is None:
            return ""
        s = body_cell.begin_parse()
        if s.remaining_bits < 32:
            return ""
        op = s.load_uint(32)
        if op != 0x0F8A7EA5:
            return ""
        s.load_uint(64)        # query_id
        s.load_coins()         # amount
        s.load_address()       # destination
        s.load_address()       # response_destination
        if s.load_bit():       # custom_payload
            s.load_ref()
        s.load_coins()         # forward_ton_amount
        if s.load_bit():       # forward_payload either^Cell
            fb = s.load_ref().begin_parse()
        else:
            fb = s
        if fb.remaining_bits >= 32:
            sub_op = fb.load_uint(32)
            if sub_op == 0:
                return fb.load_snake_string()
    except Exception:
        return ""
    return ""


async def _wait_for_outgoing(memo_marker: str, timeout: int = 90, jetton: bool = False) -> Optional[str]:
    """Polling нашего кошелька — ищем outgoing tx с нашим уникальным маркером в комменте.

    ONE LiteBalancer для всего окна подтверждения (вместо переподключения каждые 3с)."""
    deadline = asyncio.get_event_loop().time() + timeout
    provider = None
    try:
        provider = await _open_provider()
        wallet = await _open_wallet(provider)
        addr = wallet.address.to_str()
        while asyncio.get_event_loop().time() < deadline:
            try:
                txs = await provider.get_transactions(address=addr, count=20)
                for tx in txs:
                    for msg in (tx.out_msgs or []):
                        try:
                            comment = (_parse_jetton_forward_comment(msg.body) if jetton
                                       else _parse_text_comment(msg.body))
                        except Exception:
                            comment = ""
                        if memo_marker in comment:
                            try:
                                return tx.cell.hash.hex()
                            except Exception:
                                return ""
            except Exception:
                pass  # transient — retry next iteration without reconnecting
            await asyncio.sleep(3)
    finally:
        if provider:
            try:
                await provider.close_all()
            except Exception:
                pass
    return None

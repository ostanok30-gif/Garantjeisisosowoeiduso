# -*- coding: utf-8 -*-
"""
Фоновый мониторинг входящих TON и USDT-jetton депозитов на адрес
config.TON_DEPOSIT_ADDRESS через TonCenter v3 /api/v3/actions.

Один endpoint — оба типа в одном feed. TonCenter сам декодит jetton-cell'ы
и отдаёт плоские поля (asset, amount, sender, receiver, comment).

Формат комментария: "user_<id>" → бот зачисляет на внутренний баланс.

USDT₮ jetton-master mainnet (raw, lowercase):
  0:b113a994b5024a16719f69139328eb759596c38a25f59028b146fecdc3621dfe
User-friendly: EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs
"""
from __future__ import annotations

import logging
import re
import threading
import time
from typing import Optional, Tuple

import urllib.request
import urllib.parse
import urllib.error
import json as _json

import config
from . import bot as _bot
from .dynamic_settings import get_ton_deposit_address as _get_deposit_addr
from .dynamic_settings import _get_raw as _ds_get, set_value as _ds_set


log = logging.getLogger(__name__)

_NANO_TON = 1_000_000_000
_USDT_DECIMALS = 6
# raw-форма: lowercase, длина 64 hex после "0:"
_USDT_MASTER_RAW = "0:b113a994b5024a16719f69139328eb759596c38a25f59028b146fecdc3621dfe"
_USER_MEMO_RE = re.compile(r"user[_\s-]?(\d+)", re.IGNORECASE)

# курсор по lt — чтобы не перечитывать историю на каждой итерации
_LAST_LT: int = 0
_LAST_LT_LOADED: bool = False

_KEY_LAST_LT = "var_ton_monitor_last_lt"


def _load_last_lt() -> int:
    try:
        v = _ds_get(_KEY_LAST_LT)
        return int(v) if v else 0
    except Exception:
        return 0


def _save_last_lt(lt: int) -> None:
    try:
        _ds_set(_KEY_LAST_LT, str(lt))
    except Exception:
        pass


def _seed_cursor_from_now() -> int:
    addr = (_get_deposit_addr() or "").strip()
    api_key = (getattr(config, "TON_API_KEY", "") or "").strip()
    if not addr or not api_key:
        return 0
    params = [
        ("account", addr),
        ("action_type", "ton_transfer"),
        ("action_type", "jetton_transfer"),
        ("sort", "desc"),
        ("limit", "1"),
    ]
    url = _api_base_v3() + "/actions?" + urllib.parse.urlencode(params)
    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "ForSale/1.0",
                "X-API-Key": api_key,
                "accept": "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = _json.loads(resp.read().decode("utf-8"))
        actions = data.get("actions") or []
        if actions:
            return _action_lt(actions[0])
    except Exception as e:
        log.warning("seed cursor: %s", e)
    return 0


def _api_base_v3() -> str:
    return ("https://toncenter.com/api/v3"
            if getattr(config, "TON_MAINNET", True)
            else "https://testnet.toncenter.com/api/v3")


def _normalize_addr_raw(addr: str) -> str:
    """Привести к raw lowercase 0:hex64. user-friendly base64 не трогаем — TonCenter
    в `address_book` мапит туда-обратно сам."""
    if not addr:
        return ""
    s = addr.strip()
    if ":" in s:
        wc, rest = s.split(":", 1)
        if len(rest) == 64:
            return f"{wc}:{rest.lower()}"
    return s


def _parse_user_id(comment: Optional[str]) -> Optional[int]:
    if not comment:
        return None
    m = _USER_MEMO_RE.search(comment)
    if not m:
        return None
    try:
        return int(m.group(1))
    except ValueError:
        return None


def _fetch_actions(start_lt: int = 0) -> list[dict]:
    """TonCenter v3 /api/v3/actions с фильтром по типам."""
    addr = (_get_deposit_addr() or "").strip()
    api_key = (getattr(config, "TON_API_KEY", "") or "").strip()
    if not addr or not api_key:
        return []
    # Параметры: account + action_type (повторяемый), sort=asc для прогресса по lt
    params = [
        ("account", addr),
        ("action_type", "ton_transfer"),
        ("action_type", "jetton_transfer"),
        ("sort", "asc"),
        ("limit", str(int(getattr(config, "TON_POLL_LIMIT", 50)))),
    ]
    if start_lt > 0:
        params.append(("start_lt", str(start_lt)))
    url = _api_base_v3() + "/actions?" + urllib.parse.urlencode(params)
    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "ForSale/1.0",
                "X-API-Key": api_key,
                "accept": "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = _json.loads(resp.read().decode("utf-8"))
        return data.get("actions") or []
    except urllib.error.HTTPError as e:
        if e.code == 429:
            log.warning("[ton_monitor] rate-limited (429), backing off")
            time.sleep(60)
        elif 500 <= e.code < 600:
            log.warning("[ton_monitor] TonCenter %s — backing off", e.code)
            time.sleep(30)
        else:
            log.warning("[ton_monitor] HTTP %s: %s", e.code, e.reason)
        return []
    except Exception as e:
        log.warning("[ton_monitor] fetch failed: %s", e)
        return []


def _action_lt(action: dict) -> int:
    """Извлечь lt-курсор для прогресса."""
    raw = action.get("end_lt") or action.get("start_lt") or "0"
    try:
        return int(str(raw))
    except (TypeError, ValueError):
        return 0


def _extract_ton_transfer(action: dict, our_addr_raw: str) -> Optional[Tuple[str, int, float]]:
    """ton_transfer action → (tx_hash, user_id, amount_ton). Только incoming на наш адрес."""
    if not action.get("success", True):
        return None
    d = action.get("details") or {}
    dest_raw = _normalize_addr_raw(d.get("destination") or "")
    if dest_raw and our_addr_raw and dest_raw != our_addr_raw:
        return None
    src_raw = _normalize_addr_raw(d.get("source") or "")
    if src_raw and our_addr_raw and src_raw == our_addr_raw:
        return None  # self-transfer, ignore
    if d.get("encrypted"):
        return None
    try:
        value_nano = int(str(d.get("value") or "0"))
    except (TypeError, ValueError):
        return None
    if value_nano <= 0:
        return None
    amount = value_nano / _NANO_TON
    if amount < float(getattr(config, "MIN_DEPOSIT_TON", 0.1)):
        return None
    user_id = _parse_user_id(d.get("comment") or "")
    if user_id is None:
        txs = action.get("transactions") or []
        tx_hash = (txs[0] if txs else "")[:10]
        log.info("[deposit] unmemoized TON deposit, tx=%s comment=%r — manual reconcile needed",
                 tx_hash, d.get("comment"))
        return None
    txs = action.get("transactions") or []
    tx_hash = (txs[0] if txs else "").strip()
    if not tx_hash:
        return None
    return tx_hash, user_id, amount


def _extract_jetton_transfer(action: dict, our_addr_raw: str) -> Optional[Tuple[str, int, float]]:
    """jetton_transfer action → (tx_hash, user_id, amount_usdt). Только USDT на наш адрес."""
    if not action.get("success", True):
        return None
    d = action.get("details") or {}
    asset = _normalize_addr_raw(d.get("asset") or "")
    if asset != _USDT_MASTER_RAW:
        return None
    receiver_raw = _normalize_addr_raw(d.get("receiver") or "")
    if receiver_raw and our_addr_raw and receiver_raw != our_addr_raw:
        return None
    if d.get("is_encrypted_comment"):
        return None
    try:
        amt_int = int(str(d.get("amount") or "0"))
    except (TypeError, ValueError):
        return None
    if amt_int <= 0:
        return None
    amount = amt_int / (10 ** _USDT_DECIMALS)
    if amount < float(getattr(config, "MIN_DEPOSIT_USDT", 1.0)):
        return None
    user_id = _parse_user_id(d.get("comment") or "")
    if user_id is None:
        txs = action.get("transactions") or []
        tx_hash = (txs[0] if txs else "")[:10]
        log.info("[deposit] unmemoized USDT deposit, tx=%s comment=%r — manual reconcile needed",
                 tx_hash, d.get("comment"))
        return None
    txs = action.get("transactions") or []
    tx_hash = (txs[0] if txs else "").strip()
    if not tx_hash:
        return None
    return tx_hash, user_id, amount


def _process_once() -> None:
    global _LAST_LT
    addr_raw = _normalize_addr_raw(_get_deposit_addr() or "")
    actions = _fetch_actions(start_lt=_LAST_LT)
    prev_lt = _LAST_LT
    max_lt = _LAST_LT
    for a in actions:
        lt = _action_lt(a)
        if lt > max_lt:
            max_lt = lt
        atype = a.get("type") or ""
        if atype == "ton_transfer":
            parsed = _extract_ton_transfer(a, addr_raw)
            if not parsed:
                continue
            tx_hash, user_id, amount = parsed
            if _bot.deposit_exists(tx_hash):
                continue
            if _bot.record_deposit_and_credit(tx_hash, user_id, "TON", amount):
                log.info("[deposit] +%.4f TON → user %s (%s)", amount, user_id, tx_hash[:10])
        elif atype == "jetton_transfer":
            parsed = _extract_jetton_transfer(a, addr_raw)
            if not parsed:
                continue
            tx_hash, user_id, amount = parsed
            if _bot.deposit_exists(tx_hash):
                continue
            if _bot.record_deposit_and_credit(tx_hash, user_id, "USDT", amount):
                log.info("[deposit] +%.2f USDT → user %s (%s)", amount, user_id, tx_hash[:10])
    _LAST_LT = max_lt
    if max_lt != prev_lt:
        _save_last_lt(max_lt)


def _loop():
    global _LAST_LT, _LAST_LT_LOADED
    interval = int(getattr(config, "TON_POLL_INTERVAL_SEC", 15))
    while True:
        try:
            if not _LAST_LT_LOADED:
                _LAST_LT = _load_last_lt()
                if _LAST_LT == 0:
                    seeded = _seed_cursor_from_now()
                    if seeded > 0:
                        _LAST_LT = seeded
                        _save_last_lt(seeded)
                        log.info("[ton_monitor] seeded cursor lt=%d (cold start)", seeded)
                _LAST_LT_LOADED = True
            _process_once()
        except Exception as e:
            log.warning("[ton_monitor] iter failed: %s", e)
        try:
            from no_main._apps_registry import shutdown_flag
            if shutdown_flag.wait(timeout=interval):
                return
        except Exception:
            time.sleep(interval)


def run_in_background() -> None:
    """Запускает мониторинг в отдельном потоке. Каждую итерацию читает актуальный
    адрес из admin_settings — смена адреса через /admin применяется без рестарта."""
    api_key = (getattr(config, "TON_API_KEY", "") or "").strip()
    if not api_key:
        log.warning("[ton_monitor] disabled: TON_API_KEY not configured (set in config.py)")
        return
    t = threading.Thread(target=_loop, name="TonDepositMonitor", daemon=True)
    t.start()
    log.info("[ton_monitor] started (TonCenter v3 /actions)")

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Бэкап SQLite-БД бота.

Использование:
    python scripts/backup_db.py            # бэкап в backups/<timestamp>.db
    python scripts/backup_db.py --keep 30  # хранить последние 30, остальные удалить

Запускать через cron:
    0 * * * * cd /path/to/ForSale && python scripts/backup_db.py --keep 48
"""
import argparse
import os
import shutil
import sqlite3
import sys
from datetime import datetime
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--keep", type=int, default=48,
                        help="Сколько последних бэкапов хранить (по умолчанию 48).")
    args = parser.parse_args()

    project = Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(project))
    import config
    src = Path(config.PUT_K_BD_GARANT)
    if not src.is_file():
        print(f"Source DB not found: {src}", file=sys.stderr)
        return 1

    backups_dir = project / "backups"
    backups_dir.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    dst = backups_dir / f"bot_data_{ts}.db"

    # Используем SQLite Online Backup API — безопасно, даже если бот пишет в БД.
    src_conn = sqlite3.connect(str(src))
    dst_conn = sqlite3.connect(str(dst))
    try:
        src_conn.backup(dst_conn)
    finally:
        dst_conn.close()
        src_conn.close()

    size_kb = dst.stat().st_size / 1024
    print(f"OK: {dst.name}  ({size_kb:.1f} KB)")

    # Ротация
    if args.keep > 0:
        files = sorted(backups_dir.glob("bot_data_*.db"))
        excess = len(files) - args.keep
        for old in files[:max(0, excess)]:
            try:
                old.unlink()
                print(f"  removed old: {old.name}")
            except OSError:
                pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

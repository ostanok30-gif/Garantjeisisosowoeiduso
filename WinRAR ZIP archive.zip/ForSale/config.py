# -*- coding: utf-8 -*-
"""
Конфигурация бота безопасных сделок.

Большинство параметров (TON-адрес общего кошелька, токен бота) можно менять
прямо через UI: команда /admin → Кошелёк / Бот-токен. Они сохраняются в БД
и переопределяют значения из этого файла.

Этот файл правьте ТОЛЬКО для первоначальной настройки или если бот не запускается
(не задан токен).
"""
import os

# Корень проекта (папка, где лежит config.py)
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))

# Подгружаем .env, если он лежит рядом (необязательно — fallback на os.environ).
try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv(os.path.join(PROJECT_DIR, ".env"))
except Exception:
    pass


def _env_int_set(name: str) -> set:
    raw = (os.getenv(name) or "").strip()
    if not raw:
        return set()
    out = set()
    for part in raw.replace(",", " ").split():
        try:
            out.add(int(part))
        except ValueError:
            pass
    return out

# Папки для логов
LOGS_DIR = os.path.join(PROJECT_DIR, "logs")
os.makedirs(LOGS_DIR, exist_ok=True)
BOT_LOG_FILE = os.path.join(LOGS_DIR, "bot.log")
# P8.13: SESSION_DIR удалён — он создавался, но нигде не использовался
# (legacy от TeamAdmin/parser-веток, которые в этом репо отсутствуют).


# =============================================================================
# Гарант-бот
# =============================================================================

# Токен от @BotFather. Можно сменить через /admin → Бот-токен (сохраняется в БД).
# Если в БД пусто — бот возьмёт значение отсюда. Также можно положить в .env как BOT_TOKEN.
GARANT_BOT_TOKEN = os.getenv("BOT_TOKEN", "")

# Username бота (без @). Для деep-link инвайтов t.me/<bot>?start=<deal_id>.
GARANT_BOT_USERNAME = os.getenv("BOT_USERNAME", "")

# Список администраторов (Telegram user_id). Только эти юзеры видят /admin.
# Из .env: ADMIN_IDS=123,456 — будут добавлены в множество.
GARANT_ADMIN_USER_IDS: set = _env_int_set("ADMIN_IDS")
# Старое имя для совместимости — если задано, добавится в множество.
GARANT_ADMIN_USER_ID = None

# ID чата/канала для уведомлений (новая сделка, подтверждение, отмена).
# 0 = не слать.
GARANT_CHAT_NOTIFICATIONS = 0

# Путь к БД (sqlite). Не менять без необходимости.
GARANT_DB_PATH = os.path.join(LOGS_DIR, "bot_data.db")

# Валюта по умолчанию для отображения, не используется для расчётов
GARANT_VALUTE = "TON"

# Username поддержки (без @). Выводится в приветствии и кнопке «Поддержка».
GARANT_SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "your_support")

# Канал/чат отзывов (с @ или без, либо https://t.me/...)
GARANT_REVIEWS_CHANNEL = os.getenv("REVIEWS_CHANNEL", "@your_reviews")

# Инвайт-ссылка на канал (опционально, для приветствия)
GARANT_CHANNEL_INVITE_URL = ""

# Комиссия гаранта в процентах (вычитается с продавца при завершении сделки).
# Можно менять через /admin (через dynamic_settings).
GARANT_COMMISSION_PERCENT = 2

# TON-адрес «реквизит гаранта» из старой схемы — оставлен пустым, в новой схеме
# не используется (оплата идёт с внутреннего баланса бота).
GARANT_TON_ADDRESS = ""
GARANT_SBP_CARD = ""

# Прокси / таймауты PTB
GARANT_PROXY_URL = ""
GARANT_REQUEST_CONNECT_TIMEOUT = 60
GARANT_REQUEST_READ_TIMEOUT = 30
GARANT_POLL_TIMEOUT = 1


# =============================================================================
# Внутренний кошелёк (TON + USDT-jetton)
# =============================================================================

# Общий TON-адрес для приёма пополнений. Юзеры шлют сюда TON или USDT-jetton
# с обязательным комментарием "user_<id>". Бот мониторит и зачисляет.
# Можно сменить через /admin → Кошелёк бота (сохраняется в БД).
TON_DEPOSIT_ADDRESS = os.getenv("TON_DEPOSIT_ADDRESS", "")

# Ключ TON Center HTTP API (https://toncenter.com — бесплатно).
# Без него мониторинг входящих транзакций не запустится.
TON_API_KEY = os.getenv("TON_API_KEY", "")

# Mainnet (True) или Testnet (False)
TON_MAINNET = True

# Jetton-master USDT в TON-сети (USDT₮)
USDT_JETTON_MASTER = "EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs"

# Минимумы депозита/вывода — низкий floor, технически = чуть выше газа.
# TON-вывод стоит ~0.05 TON газа + 0.2 reserve, поэтому ниже 0.1 смысла нет.
# USDT-jetton transfer тоже требует ~0.05 TON газа на стороне бота, но
# номинал USDT любой, ограничиваем 0.2 чтоб юзер не выводил пыль.
MIN_DEPOSIT_TON = 0.5
MIN_DEPOSIT_USDT = 0.5
MIN_WITHDRAW_TON = 0.5
MIN_WITHDRAW_USDT = 0.5

# P5.48: суточный лимит вывода per-user (anti-laundering / hot-wallet drain).
# 0 = отключить. Сумма по 'pending' + 'sent' за последние 24h не должна
# превысить этот порог. На превышение create_withdrawal кидает ValueError
# 'daily_cap_exceeded', UI показывает локализованное сообщение.
DAILY_WITHDRAW_CAP_TON = 1000.0   # 1000 TON / 24ч
DAILY_WITHDRAW_CAP_USDT = 5000.0  # 5000 USDT / 24ч

# Лимиты на сделку — почти без минимума, верх щедрый.
# Если хочешь жёстче (защита от пыли) — подними MIN_DEAL_*.
MIN_DEAL_TON = 0.01
MAX_DEAL_TON = 1_000_000.0
MIN_DEAL_USDT = 0.1
MAX_DEAL_USDT = 1_000_000.0

# Максимальная длина описания сделки (символов). Больше — обрезается на write-time
# (P5.26): защита от Telegram message-too-long при огромных описаниях.
MAX_DESCRIPTION_LEN = 500

# Авто-отмена сделок: через сколько минут активная сделка без оплаты отменяется.
# 1440 = 24 часа. Поставь 0, чтобы отключить авто-отмену.
DEAL_TIMEOUT_MIN = 1440
# Как часто проверять (в секундах). Для 24-часового таймаута достаточно раз в 5 мин.
DEAL_TIMEOUT_CHECK_INTERVAL_SEC = 300

# P5.22: автo-открытие диспута для застрявших сделок (status='confirmed' /
# 'seller_sent') старше указанного числа часов. 0 = отключить.
# 24 = сутки: разумный дефолт, чтобы не блокировать долгие легитимные сделки,
# но и не оставлять их «висеть» бессрочно.
DEAL_DISPUTE_AUTO_TIMEOUT_HOURS = 24

# Курс TON в USD: подтягивать ли с CoinGecko (раз в 5 минут)
PRICE_CACHE_TTL_SEC = 300

# Опрос блокчейна
TON_POLL_INTERVAL_SEC = 15
TON_POLL_LIMIT = 50

# =============================================================================
# Авто-вывод (внутренний горячий кошелёк бота)
# =============================================================================
# 24 слова мнемоники (через пробел или запятую). Бот сам подписывает и шлёт TON / USDT₮.
# ⚠ ХРАНИТЬ В .env — НИКОГДА в git! Пример .env:
#   BOT_WALLET_MNEMONIC="word1 word2 ... word24"
BOT_WALLET_MNEMONIC = os.getenv("BOT_WALLET_MNEMONIC", "")
# Кол-во TON, прикрепляемых к jetton-transfer для оплаты газа (минимум 0.05).
PAYOUT_JETTON_GAS_TON = 0.05
# Резерв TON, который НЕ выводим (оставляем для оплаты газа на будущие jetton-выводы).
PAYOUT_TON_GAS_RESERVE = 0.2


# =============================================================================
# Обратная совместимость со старыми именами в no_main/bot.py
# =============================================================================
GARANT_SERVIS_BOT_TOKEN = GARANT_BOT_TOKEN
CHAT_UVEDOMLENIJ_GARANT = GARANT_CHAT_NOTIFICATIONS
PUT_K_BD_GARANT = GARANT_DB_PATH
VALUTE_GARANT = GARANT_VALUTE
TON_ADDRESS = GARANT_TON_ADDRESS
SBP_CARD = GARANT_SBP_CARD
SUPPORT_USERNAME_GARANT = GARANT_SUPPORT_USERNAME
CHANNEL_INVITE_URL_GARANT = GARANT_CHANNEL_INVITE_URL
COMMISSION_PERCENT_GARANT = GARANT_COMMISSION_PERCENT
PROXY_URL = GARANT_PROXY_URL or ""
REQUEST_CONNECT_TIMEOUT = GARANT_REQUEST_CONNECT_TIMEOUT
REQUEST_READ_TIMEOUT = GARANT_REQUEST_READ_TIMEOUT
BOT_POLL_TIMEOUT = GARANT_POLL_TIMEOUT

# Заглушки для модулей, которые могут их импортировать (panel_token и т.п.)
PANEL_BOT_TOKEN = ""
PANEL_ADMIN_ID = 0
PANEL_ADMINS = set()
PANEL_CHAT_INVITES = 0
BOT_ZAYAVOK_TOKEN = ""
ADMINS_BOTA_ZAYAVOK = set()
CHAT_ID_DLYA_INVITE_ZAYAVOK = 0

# Drainer-заглушки (на случай если где-то всплывут)
DRAINER_PLACEHOLDER_WORKER_ID = 0
DRAINER_WORKER_DISPLAY_NAME = "test"

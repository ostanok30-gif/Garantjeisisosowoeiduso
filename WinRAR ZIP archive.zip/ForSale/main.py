# -*- coding: utf-8 -*-
"""
Запуск гарант-бота безопасных сделок.
Один экземпляр через файл-блокировку (logs/main.lock).
"""
import os
import sys
import logging
import signal
import atexit

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

LOCK_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
LOCK_FILE = os.path.join(LOCK_DIR, "main.lock")
_lock_file_handle = None


def _acquire_lock():
    global _lock_file_handle
    try:
        os.makedirs(LOCK_DIR, exist_ok=True)
        fd = os.open(LOCK_FILE, os.O_CREAT | os.O_RDWR)
        try:
            if sys.platform == "win32":
                import msvcrt
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError):
            os.close(fd)
            return False
        _lock_file_handle = fd
        os.ftruncate(fd, 0)
        os.write(fd, str(os.getpid()).encode())
        os.fsync(fd)
        return True
    except Exception:
        if _lock_file_handle is not None:
            try:
                os.close(_lock_file_handle)
            except Exception:
                pass
            _lock_file_handle = None
        return False


def _release_lock():
    global _lock_file_handle
    try:
        if _lock_file_handle is not None:
            try:
                if sys.platform == "win32":
                    import msvcrt
                    msvcrt.locking(_lock_file_handle, msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(_lock_file_handle, fcntl.LOCK_UN)
            except Exception:
                pass
            try:
                os.close(_lock_file_handle)
            except Exception:
                pass
            _lock_file_handle = None
        if os.path.isfile(LOCK_FILE):
            try:
                os.remove(LOCK_FILE)
            except Exception:
                pass
    except Exception:
        pass


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    stream=sys.stdout,
)


def signal_handler(signum, frame):
    print("\nОстановка бота...")
    try:
        from no_main import _apps_registry as _reg
        _reg.shutdown_flag.set()
        for name, entry in list(_reg._apps.items()):
            if not entry or not isinstance(entry, dict):
                continue
            if entry.get("stop_scheduled"):
                continue
            app, loop = entry.get("app"), entry.get("loop")
            if app is None or loop is None:
                continue
            try:
                ev = entry.get("reload_event")
                if ev is not None:
                    loop.call_soon_threadsafe(ev.set)
                else:
                    loop.call_soon_threadsafe(lambda a=app: a.stop_running())
                entry["stop_scheduled"] = True
            except Exception:
                pass
    except Exception:
        pass


if __name__ == '__main__':
    if not _acquire_lock():
        print("Уже запущен другой экземпляр main.py. Остановите его (Ctrl+C) и попробуйте снова.")
        sys.exit(1)
    atexit.register(_release_lock)

    signal.signal(signal.SIGINT, signal_handler)
    if hasattr(signal, 'SIGTERM'):
        signal.signal(signal.SIGTERM, signal_handler)

    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("telegram.ext").setLevel(logging.WARNING)

    print("Запуск бота безопасных сделок...")
    try:
        from config import PROJECT_DIR, PUT_K_BD_GARANT
        print("  Папка проекта:", PROJECT_DIR)
        print("  Lock-файл:    ", LOCK_FILE)
        print("  БД:           ", PUT_K_BD_GARANT)
    except Exception:
        pass

    from no_main.bot import main as bot_main
    try:
        bot_main()
    except KeyboardInterrupt:
        print("\nОстановка по Ctrl+C")
    sys.exit(0)

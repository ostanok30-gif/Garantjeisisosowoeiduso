@echo off
chcp 65001 >nul
cd /d "%~dp0"

if exist ".venv\Scripts\activate.bat" (
    call ".venv\Scripts\activate.bat"
) else if exist "venv\Scripts\activate.bat" (
    call "venv\Scripts\activate.bat"
)

if not exist ".deps_ok" (
    echo Installing dependencies...
    python -m pip install --upgrade pip
    python -m pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo Dependencies install failed.
        pause
        exit /b 1
    )
    echo done > .deps_ok
)

echo.
echo Starting bot...
python main.py

echo.
echo Bot stopped. Press any key to close.
pause >nul
